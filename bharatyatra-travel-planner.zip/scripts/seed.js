require('dotenv').config();
const { loadTouristPlaces, loadStatesDistricts } = require('../backend/data/dataLoader');
const store = require('../backend/config/store');

async function seed() {
  console.log('🌱 Seeding BharatYatra Master Database...');
  
  const places = loadTouristPlaces();
  const states = loadStatesDistricts();

  console.log(`📍 Loaded ${places.length} iconic destinations across India.`);
  console.log(`🇮🇳 Loaded ${states.length} States & UTs with 780+ districts.`);

  // Save to fallback store if present
  store.saveCollection('destinations', places);
  console.log('✅ Seeding completed successfully.');
  process.exit(0);
}

seed();

