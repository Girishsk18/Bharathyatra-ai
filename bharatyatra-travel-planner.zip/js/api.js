/**
 * BharatYatra AI - Frontend API Client (js/api.js)
 * Connects the UI seamlessly to the Node.js + Express + MongoDB backend
 */

const API_BASE = window.location.origin.includes('localhost') || window.location.origin.includes('127.0.0.1')
  ? `${window.location.origin}/api`
  : '/api';

const TOKEN_KEY = 'bharatyatra_token';

async function request(endpoint, options = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...(options.headers || {})
  };

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.message || `Request failed with status ${res.status}`);
    }
    return data;
  } catch (err) {
    console.warn(`[API] ${endpoint} warning:`, err.message);
    throw err;
  }
}

const API = {
  // Authentication
  auth: {
    async register(name, email, password) {
      const data = await request('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password })
      });
      if (data.token) localStorage.setItem(TOKEN_KEY, data.token);
      return data;
    },

    async login(email, password) {
      const data = await request('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      if (data.token) localStorage.setItem(TOKEN_KEY, data.token);
      return data;
    },

    async getMe() {
      return await request('/auth/me');
    },

    async updateProfile(updates) {
      return await request('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(updates)
      });
    },

    logout() {
      localStorage.removeItem(TOKEN_KEY);
    }
  },

  // Destinations & Simple Travel
  destinations: {
    async search(params = {}) {
      const qs = new URLSearchParams(params).toString();
      return await request(`/destinations${qs ? '?' + qs : ''}`);
    },

    async getById(id) {
      return await request(`/destinations/${id}`);
    },

    async getPopular() {
      return await request('/destinations/popular');
    },

    async getStatesDistricts() {
      return await request('/destinations/states-districts');
    }
  },

  // Trip Management
  trips: {
    async getAll() {
      return await request('/trips');
    },

    async getById(id) {
      return await request(`/trips/${id}`);
    },

    async create(tripData) {
      return await request('/trips', {
        method: 'POST',
        body: JSON.stringify(tripData)
      });
    },

    async update(id, updates) {
      return await request(`/trips/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
      });
    },

    async delete(id) {
      return await request(`/trips/${id}`, {
        method: 'DELETE'
      });
    },

    async share(id) {
      return await request(`/trips/${id}/share`, {
        method: 'POST'
      });
    },

    async getShared(shareId) {
      return await request(`/trips/shared/${shareId}`);
    }
  },

  // AI Itinerary Engine
  ai: {
    async generateItinerary(params) {
      return await request('/ai/generate-itinerary', {
        method: 'POST',
        body: JSON.stringify(params)
      });
    }
  },

  // Budget & Expenses
  budget: {
    async getTripBudget(tripId) {
      return await request(`/trips/${tripId}/budget`);
    },

    async addExpense(tripId, expense) {
      return await request(`/trips/${tripId}/expenses`, {
        method: 'POST',
        body: JSON.stringify(expense)
      });
    },

    async deleteExpense(tripId, expenseId) {
      return await request(`/trips/${tripId}/expenses/${expenseId}`, {
        method: 'DELETE'
      });
    }
  },

  // Weather
  weather: {
    async get(destination) {
      return await request(`/weather?destination=${encodeURIComponent(destination)}`);
    }
  },

  // Maps & Routes
  maps: {
    async getRoute(origin, destination) {
      return await request(`/maps/route?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}`);
    }
  },

  // Favourites & Wishlist
  favourites: {
    async getAll() {
      return await request('/favourites');
    },

    async toggle(itemId, itemType = 'destination') {
      return await request('/favourites/toggle', {
        method: 'POST',
        body: JSON.stringify({ itemId, itemType })
      });
    },

    async getRecent() {
      return await request('/favourites/recent');
    }
  }
};

window.API = API;

