/**
 * BharatYatra AI - Authentication & Dashboard Chooser Logic (auth.js)
 * Handles login/signup, user session, and dashboard selection
 * Phase 1: localStorage-based auth (Phase 2: MongoDB + Express backend)
 */

const AUTH_STORAGE_KEY = 'bharatyatra_users';
const SESSION_KEY = 'bharatyatra_session';
const DASHBOARD_KEY = 'bharatyatra_active_dashboard';

// Auth state
const authState = {
  currentUser: null,
  activeDashboard: null, // 'simple-travel' | 'trip-planner'
  authTab: 'login' // 'login' | 'signup'
};

/* --------------------------------------------------------------------------
   Initialization
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  checkExistingSession();
});

function checkExistingSession() {
  const session = JSON.parse(localStorage.getItem(SESSION_KEY));
  if (session && session.email) {
    authState.currentUser = session;
    const savedDashboard = localStorage.getItem(DASHBOARD_KEY);
    if (savedDashboard) {
      authState.activeDashboard = savedDashboard;
      enterApp(savedDashboard);
    } else {
      hideAuthScreen();
      showDashboardChooser();
    }
  } else {
    showAuthScreen();
  }
}

/* --------------------------------------------------------------------------
   Auth Tab Switching
   -------------------------------------------------------------------------- */
function switchAuthTab(tab) {
  authState.authTab = tab;
  
  document.querySelectorAll('.auth-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tab);
  });

  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  
  if (loginForm) loginForm.classList.toggle('hidden', tab !== 'login');
  if (signupForm) signupForm.classList.toggle('hidden', tab !== 'signup');

  // Clear errors
  hideAuthError();
}

/* --------------------------------------------------------------------------
   Sign Up
   -------------------------------------------------------------------------- */
async function handleSignup(e) {
  e.preventDefault();
  hideAuthError();

  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const password = document.getElementById('signupPassword').value;

  // Validation
  if (!name || name.length < 2) {
    showAuthError('Please enter your full name.');
    return;
  }
  if (!email || !isValidEmail(email)) {
    showAuthError('Please enter a valid email address.');
    return;
  }
  if (!password || password.length < 6) {
    showAuthError('Password must be at least 6 characters.');
    return;
  }

  // Try Backend API first
  if (window.API?.auth?.register) {
    try {
      const res = await window.API.auth.register(name, email, password);
      if (res && res.user) {
        loginUser({
          id: res.user._id || res.user.id,
          name: res.user.name,
          email: res.user.email,
          avatar: res.user.avatar || name.charAt(0).toUpperCase()
        });
        showToast('🎉 Welcome to BharatYatra AI, ' + name + '!', 'success');
        return;
      }
    } catch (err) {
      console.warn('Backend signup error, checking message:', err.message);
      if (err.message && err.message.includes('already exists')) {
        showAuthError('An account with this email already exists. Please login.');
        return;
      }
      // If server unreachable, proceed with localStorage fallback
    }
  }

  // Check if user exists in localStorage
  const users = getStoredUsers();
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    showAuthError('An account with this email already exists. Please login.');
    return;
  }

  // Create user
  const newUser = {
    id: generateUserId(),
    name: name,
    email: email.toLowerCase(),
    password: btoa(password),
    createdAt: new Date().toISOString(),
    avatar: name.charAt(0).toUpperCase()
  };

  users.push(newUser);
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(users));

  // Auto-login after signup
  loginUser(newUser);
  showToast('🎉 Welcome to BharatYatra AI, ' + name + '!', 'success');
}

/* --------------------------------------------------------------------------
   Login
   -------------------------------------------------------------------------- */
async function handleLogin(e) {
  e.preventDefault();
  hideAuthError();

  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!email || !isValidEmail(email)) {
    showAuthError('Please enter a valid email address.');
    return;
  }
  if (!password) {
    showAuthError('Please enter your password.');
    return;
  }

  // Try Backend API first
  if (window.API?.auth?.login) {
    try {
      const res = await window.API.auth.login(email, password);
      if (res && res.user) {
        loginUser({
          id: res.user._id || res.user.id,
          name: res.user.name,
          email: res.user.email,
          avatar: res.user.avatar || res.user.name.charAt(0).toUpperCase()
        });
        showToast('👋 Welcome back, ' + res.user.name + '!', 'success');
        return;
      }
    } catch (err) {
      if (err.message && (err.message.includes('credentials') || err.message.includes('password') || err.message.includes('not found'))) {
        showAuthError(err.message);
        return;
      }
      // If server offline or unreachable, proceed with localStorage
    }
  }

  const users = getStoredUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user) {
    showAuthError('No account found with this email. Please sign up first.');
    return;
  }

  if (atob(user.password) !== password) {
    showAuthError('Incorrect password. Please try again.');
    return;
  }

  loginUser(user);
  showToast('👋 Welcome back, ' + user.name + '!', 'success');
}

/* --------------------------------------------------------------------------
   Guest Login
   -------------------------------------------------------------------------- */
function handleGuestLogin() {
  const guestUser = {
    id: 'guest_traveller',
    name: 'Guest Traveller',
    email: 'guest@bharatyatra.ai',
    avatar: 'G'
  };
  loginUser(guestUser);
  showToast('👋 Exploring BharatYatra as Guest!', 'info');
}

function loginUser(user) {
  const sessionData = {
    id: user.id || user._id,
    name: user.name,
    email: user.email,
    avatar: user.avatar || user.name.charAt(0).toUpperCase()
  };

  localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
  authState.currentUser = sessionData;

  hideAuthScreen();

  // Check if user has a preferred dashboard
  const savedDashboard = localStorage.getItem(DASHBOARD_KEY);
  if (savedDashboard) {
    enterApp(savedDashboard);
  } else {
    showDashboardChooser();
  }
}

/* --------------------------------------------------------------------------
   Logout
   -------------------------------------------------------------------------- */
function logout() {
  if (window.API?.auth?.logout) {
    window.API.auth.logout();
  }
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(DASHBOARD_KEY);
  authState.currentUser = null;
  authState.activeDashboard = null;

  // Hide app and chooser, show auth
  hideApp();
  hideDashboardChooser();
  showAuthScreen();
  showToast('👋 You have been logged out.', 'info');
}

/* --------------------------------------------------------------------------
   Dashboard Chooser
   -------------------------------------------------------------------------- */
function selectDashboard(dashboardType) {
  authState.activeDashboard = dashboardType;
  localStorage.setItem(DASHBOARD_KEY, dashboardType);
  
  hideDashboardChooser();
  enterApp(dashboardType);
}

function switchDashboard() {
  // Go back to dashboard chooser
  localStorage.removeItem(DASHBOARD_KEY);
  authState.activeDashboard = null;
  
  hideApp();
  showDashboardChooser();
}

/* --------------------------------------------------------------------------
   Screen Show/Hide Helpers
   -------------------------------------------------------------------------- */
function showAuthScreen() {
  const screen = document.getElementById('authScreen');
  if (screen) {
    screen.classList.remove('hidden');
    screen.style.display = 'flex';
  }
}

function hideAuthScreen() {
  const screen = document.getElementById('authScreen');
  if (screen) {
    screen.classList.add('hidden');
    setTimeout(() => { screen.style.display = 'none'; }, 500);
  }
}

function showDashboardChooser() {
  const chooser = document.getElementById('dashboardChooser');
  if (chooser) {
    chooser.style.display = 'flex';
    // Update welcome name
    const nameEl = document.getElementById('chooserUserName');
    if (nameEl && authState.currentUser) {
      nameEl.textContent = authState.currentUser.name;
    }
    requestAnimationFrame(() => {
      chooser.classList.remove('hidden');
    });
  }
}

function hideDashboardChooser() {
  const chooser = document.getElementById('dashboardChooser');
  if (chooser) {
    chooser.classList.add('hidden');
    setTimeout(() => { chooser.style.display = 'none'; }, 500);
  }
}

function enterApp(dashboardType) {
  const appContainer = document.getElementById('mainAppWrapper');
  if (appContainer) {
    appContainer.style.display = 'block';
    requestAnimationFrame(() => {
      appContainer.classList.remove('hidden-app');
    });
  }

  // Update navbar user info
  updateNavbarUser();
  
  // Update active dashboard badge
  updateDashboardBadge(dashboardType);

  // Switch to the correct dashboard view
  if (dashboardType === 'simple-travel') {
    // Show Simple Travel with sub-tabs (States & Tourist Places)
    switchMainView('states-districts');
    showSimpleTravelNav();
  } else if (dashboardType === 'trip-planner') {
    // Show Trip Planner
    switchMainView('planner');
    showTripPlannerNav();
  }
}

function hideApp() {
  const appContainer = document.getElementById('mainAppWrapper');
  if (appContainer) {
    appContainer.classList.add('hidden-app');
    setTimeout(() => { appContainer.style.display = 'none'; }, 400);
  }
}

/* --------------------------------------------------------------------------
   Navbar Updates
   -------------------------------------------------------------------------- */
function updateNavbarUser() {
  const userBtn = document.getElementById('navUserBtn');
  const avatarEl = document.getElementById('navUserAvatar');
  const nameEl = document.getElementById('navUserName');

  if (authState.currentUser) {
    if (avatarEl) avatarEl.textContent = authState.currentUser.avatar;
    if (nameEl) nameEl.textContent = authState.currentUser.name.split(' ')[0];
    if (userBtn) userBtn.style.display = 'inline-flex';
  }
}

function updateDashboardBadge(dashboardType) {
  const badge = document.getElementById('navDashboardBadge');
  if (!badge) return;

  badge.classList.remove('nav-dashboard-badge--travel', 'nav-dashboard-badge--planner');
  
  if (dashboardType === 'simple-travel') {
    badge.innerHTML = '🧭 Simple Travel';
    badge.classList.add('nav-dashboard-badge--travel');
  } else {
    badge.innerHTML = '📋 Trip Planner';
    badge.classList.add('nav-dashboard-badge--planner');
  }
}

function showSimpleTravelNav() {
  // Show the sub-tab navigation for Simple Travel
  const subTabs = document.getElementById('simpleTravelSubtabs');
  const tripPlannerTabs = document.getElementById('tripPlannerNavTabs');
  if (subTabs) subTabs.style.display = 'flex';
  if (tripPlannerTabs) tripPlannerTabs.style.display = 'none';
}

function showTripPlannerNav() {
  const subTabs = document.getElementById('simpleTravelSubtabs');
  const tripPlannerTabs = document.getElementById('tripPlannerNavTabs');
  if (subTabs) subTabs.style.display = 'none';
  if (tripPlannerTabs) tripPlannerTabs.style.display = 'flex';
}

function switchSimpleTravelTab(tabName) {
  // tabName: 'states-districts' or 'tourist-places'
  document.querySelectorAll('.simple-travel-subtab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.subtab === tabName);
  });

  switchMainView(tabName);
}

/* --------------------------------------------------------------------------
   My Trips Management (Enhanced CRUD)
   -------------------------------------------------------------------------- */
async function renderMyTrips() {
  const container = document.getElementById('myTripsGrid');
  const countEl = document.getElementById('myTripsCount');
  if (!container) return;

  let trips = [];
  if (window.API?.trips && localStorage.getItem('bharatyatra_token')) {
    try {
      const res = await window.API.trips.getAll();
      if (res && Array.isArray(res.data)) {
        trips = res.data;
        localStorage.setItem('wanderai_saved_trips', JSON.stringify(trips));
      }
    } catch (err) {
      console.warn('Using local trips:', err.message);
      trips = JSON.parse(localStorage.getItem('wanderai_saved_trips') || '[]');
    }
  } else {
    trips = JSON.parse(localStorage.getItem('wanderai_saved_trips') || '[]');
  }
  
  if (countEl) countEl.textContent = trips.length + ' trip' + (trips.length !== 1 ? 's' : '');

  if (trips.length === 0) {
    container.innerHTML = `
      <div class="my-trips-empty" style="grid-column: 1 / -1;">
        <div class="my-trips-empty-icon">🗺️</div>
        <p>No trips planned yet</p>
        <p style="font-size: 0.8rem; margin-top: 0.35rem; color: var(--text-muted);">
          Start by creating your first Bharat Yatra below!
        </p>
      </div>
    `;
    return;
  }

  container.innerHTML = trips.map((trip, index) => {
    const status = trip.itinerary ? 'planned' : 'draft';
    const statusLabel = status === 'planned' ? '✅ Planned' : '📝 Draft';
    const dest = trip.destination || trip.trip?.destination || 'Unknown';
    const budget = trip.budgetAmount || trip.trip?.budgetAmount || 0;
    const days = trip.durationDays || trip.trip?.durationDays || 0;
    const party = trip.party || trip.trip?.party || '';
    const tripId = trip._id || trip.id || index;

    return `
      <div class="trip-card-item" onclick="loadSavedTrip(${index})">
        <div class="trip-card-actions">
          <button class="trip-card-action-btn" onclick="event.stopPropagation(); deleteTrip(${index}, '${tripId}')" title="Delete trip">🗑️</button>
        </div>
        <div class="trip-card-dest">${dest}</div>
        <div class="trip-card-meta">
          <span>📅 ${days} days</span>
          <span>💰 ₹${budget.toLocaleString('en-IN')}</span>
          ${party ? '<span>👥 ' + party + '</span>' : ''}
        </div>
        <span class="trip-card-status trip-card-status--${status}">${statusLabel}</span>
      </div>
    `;
  }).join('');
}

async function deleteTrip(index, tripId) {
  if (!confirm('Delete this trip?')) return;

  if (tripId && window.API?.trips && localStorage.getItem('bharatyatra_token')) {
    try {
      await window.API.trips.delete(tripId);
    } catch (err) {
      console.warn('Backend delete failed, removing locally:', err.message);
    }
  }

  const trips = JSON.parse(localStorage.getItem('wanderai_saved_trips') || '[]');
  trips.splice(index, 1);
  localStorage.setItem('wanderai_saved_trips', JSON.stringify(trips));

  renderMyTrips();
  // Update saved trips badge
  const badge = document.getElementById('savedTripsBadge');
  if (badge) badge.textContent = trips.length;

  showToast('🗑️ Trip deleted.', 'info');
}

function loadSavedTrip(index) {
  const trips = JSON.parse(localStorage.getItem('wanderai_saved_trips') || '[]');
  const trip = trips[index];
  if (!trip) return;

  // Load into the planner form
  if (typeof loadTripIntoForm === 'function') {
    loadTripIntoForm(trip);
  }

  showToast('📂 Trip loaded into planner!', 'success');
}

/* --------------------------------------------------------------------------
   Utility Functions
   -------------------------------------------------------------------------- */
function getStoredUsers() {
  return JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY) || '[]');
}

function generateUserId() {
  return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showAuthError(msg) {
  const el = document.getElementById('authErrorMsg');
  if (el) {
    el.textContent = msg;
    el.classList.add('visible');
  }
}

function hideAuthError() {
  const el = document.getElementById('authErrorMsg');
  if (el) {
    el.textContent = '';
    el.classList.remove('visible');
  }
}

function togglePasswordVisibility(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = '🙈';
  } else {
    input.type = 'password';
    btn.textContent = '👁️';
  }
}

// Toast helper (uses existing toast system if available)
function showToast(message, type = 'info') {
  if (typeof window.showToastNotification === 'function') {
    window.showToastNotification(message, type);
    return;
  }
  
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast-notification toast-' + type;
  toast.innerHTML = `<span>${message}</span>`;
  toast.style.cssText = `
    padding: 0.85rem 1.25rem;
    border-radius: 12px;
    font-size: 0.875rem;
    font-weight: 600;
    color: white;
    background: ${type === 'success' ? 'rgba(16, 185, 129, 0.9)' : type === 'error' ? 'rgba(244, 63, 94, 0.9)' : 'rgba(59, 130, 246, 0.9)'};
    backdrop-filter: blur(12px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.3);
    animation: toastSlideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) both;
    margin-bottom: 0.5rem;
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100px)';
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}
