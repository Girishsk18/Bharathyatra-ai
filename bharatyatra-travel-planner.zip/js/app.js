/**
 * WanderAI - Core Application Logic (app.js)
 * Phase 1: Trip Input Form & Responsive UI Engine
 * Custom-built exclusively for Indian Tourism Destinations (Bharat Yatra)
 */

// Application State
const state = {
  currentStep: 1,
  totalSteps: 4,
  viewMode: 'wizard', // 'wizard' or 'all-in-one'
  theme: localStorage.getItem('wanderai_theme') || 'dark',
  currency: 'INR',
  trip: {
    destination: 'Jaipur, Rajasthan',
    destinationKey: 'jaipur',
    origin: localStorage.getItem('bharatyatra_user_origin') || '',
    startDate: '',
    endDate: '',
    durationDays: 4,
    party: 'couple',
    adults: 2,
    children: 0,
    budgetTier: 'luxury',
    budgetAmount: 48000,
    pace: 'balanced',
    vibes: ['heritage', 'food', 'photography', 'culture', 'shopping'],
    accommodation: 'haveli',
    transport: 'cab',
    dietary: ['vegetarian'],
    accessibility: [],
    customNotes: 'Sunset view from Nahargarh Fort, authentic Rajasthani Dal Baati Churma at Chokhi Dhani, visit Hawa Mahal at sunrise.'
  },
  savedTrips: [],
  currentItinerary: null,
  transportFilter: {
    mode: 'all',
    maxBudget: null,
    maxHours: null,
    priority: 'none'
  },
  selectedTransport: 'train_vb_20978'
};

// Popular Destinations for Autocomplete (All Indian)
const POPULAR_DESTINATIONS = [
  { name: 'Jaipur, Rajasthan', key: 'jaipur', state: 'Rajasthan', icon: '🏰', img: 'assets/images/jaipur.jpg' },
  { name: 'Alleppey & Munnar, Kerala', key: 'kerala', state: 'Kerala', icon: '🛶', img: 'assets/images/kerala.jpg' },
  { name: 'Manali & Solang, Himachal', key: 'manali', state: 'Himachal Pradesh', icon: '🏔️', img: 'assets/images/manali.jpg' },
  { name: 'Goa (North & South)', key: 'goa', state: 'Goa', icon: '🏖️', img: 'assets/images/goa.jpg' },
  { name: 'Varanasi, Uttar Pradesh', key: 'varanasi', state: 'Uttar Pradesh', icon: '🛕', img: 'assets/images/jaipur.jpg' },
  { name: 'Leh-Ladakh', key: 'ladakh', state: 'Ladakh', icon: '🏍️', img: 'assets/images/manali.jpg' },
  { name: 'Udaipur, Rajasthan', key: 'udaipur', state: 'Rajasthan', icon: '👑', img: 'assets/images/jaipur.jpg' },
  { name: 'Rishikesh, Uttarakhand', key: 'rishikesh', state: 'Uttarakhand', icon: '🧘', img: 'assets/images/manali.jpg' },
  { name: 'Darjeeling & Gangtok', key: 'darjeeling', state: 'Sikkim & West Bengal', icon: '🫖', img: 'assets/images/kerala.jpg' },
  { name: 'Andaman & Nicobar Islands', key: 'andaman', state: 'Andaman Islands', icon: '🤿', img: 'assets/images/goa.jpg' },
  { name: 'Hampi & Gokarna, Karnataka', key: 'hampi', state: 'Karnataka', icon: '🗿', img: 'assets/images/jaipur.jpg' },
  { name: 'Ooty & Coonoor, Tamil Nadu', key: 'ooty', state: 'Tamil Nadu', icon: '🚂', img: 'assets/images/kerala.jpg' }
];

// Document Ready Initialization
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initDates();
  initEventListeners();
  loadSavedTrips();
  triggerDetectLiveLocation(); // Auto-detect nearest district from live location
  updateLiveBlueprint();
  updateWizardSteps();
  renderTransportCards();
});

/* --------------------------------------------------------------------------
   Theme & Preferences
   -------------------------------------------------------------------------- */
function initTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  updateThemeIcon();
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', state.theme);
  localStorage.setItem('wanderai_theme', state.theme);
  updateThemeIcon();
  showToast(`Switched to ${state.theme} mode`, 'info');
}

function updateThemeIcon() {
  const btn = document.getElementById('themeToggleBtn');
  if (btn) {
    btn.innerHTML = state.theme === 'dark' 
      ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>`
      : `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
  }
}

/* --------------------------------------------------------------------------
   Date & Duration Handling
   -------------------------------------------------------------------------- */
function initDates() {
  const startEl = document.getElementById('startDate');
  const endEl = document.getElementById('endDate');

  const today = new Date();
  const depart = new Date(today);
  depart.setDate(today.getDate() + 10);

  const ret = new Date(depart);
  ret.setDate(depart.getDate() + 4);

  const formatDate = (d) => d.toISOString().split('T')[0];

  state.trip.startDate = formatDate(depart);
  state.trip.endDate = formatDate(ret);

  if (startEl) {
    startEl.min = formatDate(today);
    startEl.value = state.trip.startDate;
  }
  if (endEl) {
    endEl.min = state.trip.startDate;
    endEl.value = state.trip.endDate;
  }

  calcDuration();
}

function calcDuration() {
  const start = new Date(state.trip.startDate);
  const end = new Date(state.trip.endDate);
  
  if (start && end && end >= start) {
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    state.trip.durationDays = diffDays > 0 ? diffDays : 1;
  } else {
    state.trip.durationDays = 1;
  }

  const durationPill = document.getElementById('durationPill');
  if (durationPill) {
    const nights = Math.max(0, state.trip.durationDays - 1);
    durationPill.innerHTML = `<span>🗓️ ${state.trip.durationDays} Days / ${nights} Nights</span>`;
  }

  updateLiveBlueprint();
}

function setQuickDuration(days) {
  state.trip.durationDays = days;
  const start = new Date(state.trip.startDate);
  const newEnd = new Date(start);
  newEnd.setDate(start.getDate() + days);
  state.trip.endDate = newEnd.toISOString().split('T')[0];

  const endEl = document.getElementById('endDate');
  if (endEl) endEl.value = state.trip.endDate;

  // Sync the custom days input field
  const customDaysEl = document.getElementById('customDaysInput');
  if (customDaysEl) customDaysEl.value = days;

  document.querySelectorAll('.duration-chip').forEach(chip => {
    chip.classList.toggle('active', parseInt(chip.dataset.days) === days);
  });

  calcDuration();
}

/* --------------------------------------------------------------------------
   Custom Days Input & Adjustment
   -------------------------------------------------------------------------- */
function handleCustomDaysChange(val) {
  const days = parseInt(val);
  if (isNaN(days) || days < 1) return;
  const clamped = Math.min(60, Math.max(1, days));
  setQuickDuration(clamped);
}

function adjustCustomDays(delta) {
  const current = state.trip.durationDays || 4;
  const next = Math.min(60, Math.max(1, current + delta));
  const customDaysEl = document.getElementById('customDaysInput');
  if (customDaysEl) customDaysEl.value = next;
  setQuickDuration(next);
}

/* --------------------------------------------------------------------------
   Step Wizard & View Modes
   -------------------------------------------------------------------------- */
function setViewMode(mode) {
  state.viewMode = mode;
  const plannerBox = document.getElementById('plannerFormBox');
  const wizardBtn = document.getElementById('viewWizardBtn');
  const allInOneBtn = document.getElementById('viewAllInOneBtn');

  if (mode === 'all-in-one') {
    plannerBox.classList.add('all-in-one-mode');
    wizardBtn.classList.remove('active');
    allInOneBtn.classList.add('active');
  } else {
    plannerBox.classList.remove('all-in-one-mode');
    wizardBtn.classList.add('active');
    allInOneBtn.classList.remove('active');
  }
}

function goToStep(step) {
  if (step < 1 || step > state.totalSteps) return;
  state.currentStep = step;
  updateWizardSteps();
  window.scrollTo({ top: document.getElementById('plannerFormBox').offsetTop - 90, behavior: 'smooth' });
}

function nextStep() {
  if (state.currentStep < state.totalSteps) {
    goToStep(state.currentStep + 1);
  } else {
    triggerGenerateItinerary();
  }
}

function prevStep() {
  if (state.currentStep > 1) {
    goToStep(state.currentStep - 1);
  }
}

function updateWizardSteps() {
  for (let i = 1; i <= state.totalSteps; i++) {
    const content = document.getElementById(`stepContent${i}`);
    const node = document.getElementById(`stepNode${i}`);
    if (content) content.classList.toggle('active', i === state.currentStep);
    if (node) {
      node.classList.remove('active', 'completed');
      if (i === state.currentStep) node.classList.add('active');
      else if (i < state.currentStep) node.classList.add('completed');
    }
  }

  const progressLine = document.getElementById('stepProgressLine');
  if (progressLine) {
    const percent = ((state.currentStep - 1) / (state.totalSteps - 1)) * 100;
    progressLine.style.width = `${percent}%`;
  }

  const prevBtn = document.getElementById('prevStepBtn');
  const nextBtn = document.getElementById('nextStepBtn');

  if (prevBtn) prevBtn.style.visibility = state.currentStep === 1 ? 'hidden' : 'visible';
  if (nextBtn) {
    if (state.currentStep === state.totalSteps) {
      nextBtn.innerHTML = `<span>Generate Yatra Plan ✨</span>`;
    } else {
      nextBtn.innerHTML = `<span>Next Step →</span>`;
    }
  }
}

/* --------------------------------------------------------------------------
   Live Blueprint & Calculation
   -------------------------------------------------------------------------- */
function updateLiveBlueprint() {
  const destText = document.getElementById('bpDestText');
  const imgEl = document.getElementById('bpDestImg');
  const durationText = document.getElementById('bpDurationText');
  const travelersText = document.getElementById('bpTravelersText');
  const totalBudgetText = document.getElementById('bpTotalBudgetText');
  const dailyBudgetText = document.getElementById('bpDailyBudgetText');
  const vibesWrap = document.getElementById('bpVibesWrap');
  const readinessBar = document.getElementById('bpReadinessFill');
  const readinessPct = document.getElementById('bpReadinessPercent');

  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';

  if (destText) destText.textContent = state.trip.destination || 'Select Indian Destination';
  
  // Set preview image
  if (imgEl) {
    const preset = CURATED_PRESETS[state.trip.destinationKey];
    if (preset && preset.image) {
      imgEl.src = preset.image;
    } else {
      imgEl.src = 'assets/images/jaipur.jpg';
    }
  }

  if (durationText) {
    durationText.textContent = `${state.trip.durationDays} Days / ${Math.max(0, state.trip.durationDays - 1)} Nights`;
  }

  if (travelersText) {
    const totalPpl = state.trip.adults + state.trip.children;
    travelersText.textContent = `${totalPpl} (${capitalize(state.trip.party)})`;
  }

  const convertedTotal = Math.round(state.trip.budgetAmount * (CURRENCY_RATES_FROM_INR[state.currency] || 1));
  const totalPpl = Math.max(1, state.trip.adults + state.trip.children);
  const dailyPerPerson = Math.round(convertedTotal / (state.trip.durationDays * totalPpl));

  if (totalBudgetText) totalBudgetText.textContent = `${sym}${formatIndianNumber(convertedTotal)}`;
  if (dailyBudgetText) dailyBudgetText.textContent = `~${sym}${formatIndianNumber(dailyPerPerson)} /day per person`;

  if (vibesWrap) {
    vibesWrap.innerHTML = state.trip.vibes.map(v => 
      `<span class="blueprint-mini-tag">${formatVibeName(v)}</span>`
    ).join('') || `<span class="blueprint-mini-tag">Select vibes</span>`;
  }

  let score = 25;
  if (state.trip.destination) score += 25;
  if (state.trip.durationDays > 0) score += 20;
  if (state.trip.vibes.length >= 2) score += 20;
  if (state.trip.budgetAmount > 0) score += 10;

  if (readinessBar) readinessBar.style.width = `${score}%`;
  if (readinessPct) readinessPct.textContent = `${score}%`;

  // Inter-State Travel Analysis & Display
  if (typeof analyzeInterStateTravel === 'function' && state.trip.origin && state.trip.destination) {
    const analysis = analyzeInterStateTravel(state.trip.origin, state.trip.destination);
    const circuitSidebar = document.getElementById('bpInterstateCircuit');
    const noticeForm = document.getElementById('formInterstateNotice');

    if (analysis && analysis.isInterState) {
      const circuitHTML = `
        <div class="circuit-header">
          <span class="circuit-badge">🛫 Inter-State Circuit</span>
          <span style="font-size: 0.725rem; color: var(--accent-cyan); font-weight: 700;">
            ${analysis.approxDistanceKm ? '~' + analysis.approxDistanceKm + ' km' : 'Cross-State'}
          </span>
        </div>
        <div class="circuit-route-row">
          <span>${state.trip.origin.split(',')[0]}</span>
          <span class="circuit-route-arrow">➔</span>
          <span style="color: var(--accent-cyan);">${state.trip.destination.split(',')[0]}</span>
        </div>
        <div class="circuit-meta-row">
          <div>Journey: <strong>${analysis.originState}</strong> ➔ <strong>${analysis.destState}</strong></div>
          <div style="margin-top: 0.25rem; color: var(--accent-emerald);">🚆 ${analysis.transitAdvice}</div>
        </div>
      `;

      if (circuitSidebar) {
        circuitSidebar.innerHTML = circuitHTML;
        circuitSidebar.style.display = 'block';
        circuitSidebar.classList.remove('intra-state');
      }

      if (noticeForm) {
        noticeForm.innerHTML = `
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 0.65rem;">
              <span style="font-size: 1.4rem;">🛫</span>
              <div>
                <strong style="color: var(--text-main); font-size: 0.9rem;">Inter-State Yatra: ${analysis.originState} ➔ ${analysis.destState}</strong>
                <div style="font-size: 0.775rem; color: var(--text-secondary);">
                  Departure: ${state.trip.origin} • Destination: ${state.trip.destination} 
                  ${analysis.approxDistanceKm ? '(' + analysis.approxDistanceKm + ' km)' : ''}
                </div>
              </div>
            </div>
            <span class="circuit-badge" style="background: rgba(16, 185, 129, 0.2); color: #34d399; border-color: rgba(16, 185, 129, 0.4);">
              ✓ Inter-State Route Active
            </span>
          </div>
        `;
        noticeForm.style.display = 'block';
      }
    } else if (analysis && analysis.originState) {
      // Intra-state journey
      const circuitHTML = `
        <div class="circuit-header">
          <span class="circuit-badge" style="background: rgba(16, 185, 129, 0.2); color: #34d399; border-color: rgba(16, 185, 129, 0.4);">
            🚗 Intra-State Yatra
          </span>
          <span style="font-size: 0.725rem; color: var(--text-muted); font-weight: 600;">Within ${analysis.originState}</span>
        </div>
        <div class="circuit-route-row">
          <span>${state.trip.origin.split(',')[0]}</span>
          <span class="circuit-route-arrow">➔</span>
          <span style="color: var(--accent-cyan);">${state.trip.destination.split(',')[0]}</span>
        </div>
        <div class="circuit-meta-row">
          <div>State Circuit: <strong>${analysis.originState}</strong></div>
          <div style="margin-top: 0.25rem; color: var(--text-secondary);">🚗 Regional Express Road / Rail Circuit</div>
        </div>
      `;

      if (circuitSidebar) {
        circuitSidebar.innerHTML = circuitHTML;
        circuitSidebar.style.display = 'block';
        circuitSidebar.classList.add('intra-state');
      }

      if (noticeForm) {
        noticeForm.style.display = 'none';
      }
    } else {
      if (circuitSidebar) circuitSidebar.style.display = 'none';
      if (noticeForm) noticeForm.style.display = 'none';
    }
  }
}

function formatIndianNumber(x) {
  if (state.currency === 'INR') {
    return x.toLocaleString('en-IN');
  }
  return x.toLocaleString('en-US');
}

function formatVibeName(key) {
  const map = {
    heritage: '🏰 Royal Heritage',
    spiritual: '🛕 Spiritual & Ghats',
    food: '🍛 Street Food & Thalis',
    nature: '🌴 Backwaters & Hills',
    adventure: '🏄 Rafting & Snow',
    photography: '📸 Instagram Spots',
    nightlife: '🍸 Beach Shacks',
    shopping: '🛍️ Bazaars & Silk',
    wellness: '🧘 Yoga & Ayurveda',
    wildlife: '🐅 Jungle Safari',
    hidden_gems: '🔮 Secret Gems'
  };
  return map[key] || key;
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}

/* --------------------------------------------------------------------------
   Form Controls & Events
   -------------------------------------------------------------------------- */
function initEventListeners() {
  const destInput = document.getElementById('destinationInput');
  const acDropdown = document.getElementById('autocompleteDropdown');

  if (destInput && acDropdown) {
    destInput.addEventListener('input', (e) => {
      const q = e.target.value;
      state.trip.destination = e.target.value;
      updateLiveBlueprint();

      if (q.trim().length > 0) {
        const matches = searchAllIndianDestinations(q);
        renderAutocomplete(matches);
        acDropdown.classList.add('active');
      } else {
        renderAutocomplete(searchAllIndianDestinations(''));
        acDropdown.classList.add('active');
      }
    });

    destInput.addEventListener('focus', () => {
      renderAutocomplete(searchAllIndianDestinations(destInput.value || ''));
      acDropdown.classList.add('active');
    });

    document.addEventListener('click', (e) => {
      if (!destInput.contains(e.target) && !acDropdown.contains(e.target)) {
        acDropdown.classList.remove('active');
      }
    });
  }

  const originInput = document.getElementById('originInput');
  if (originInput) {
    if (state.trip.origin) {
      originInput.value = state.trip.origin;
    }
    originInput.addEventListener('input', (e) => {
      state.trip.origin = e.target.value;
      localStorage.setItem('bharatyatra_user_origin', e.target.value);
      updateLiveBlueprint(); // Re-calculate inter-state connections on manual origin edit
      renderTransportCards(); // Re-render tailored transport cards for new origin
    });
  }

  const startEl = document.getElementById('startDate');
  const endEl = document.getElementById('endDate');
  if (startEl) {
    startEl.addEventListener('change', (e) => {
      state.trip.startDate = e.target.value;
      if (endEl) endEl.min = e.target.value;
      calcDuration();
    });
  }
  if (endEl) {
    endEl.addEventListener('change', (e) => {
      state.trip.endDate = e.target.value;
      calcDuration();
    });
  }

  setupStepper('adultsMinus', 'adultsPlus', 'adultsVal', 1, 14, (v) => {
    state.trip.adults = v;
    updateLiveBlueprint();
  });
  setupStepper('kidsMinus', 'kidsPlus', 'kidsVal', 0, 8, (v) => {
    state.trip.children = v;
    updateLiveBlueprint();
  });

  document.querySelectorAll('.party-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.party-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      state.trip.party = card.dataset.party;
      updateLiveBlueprint();
    });
  });

  document.querySelectorAll('.budget-tier-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.budget-tier-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const tier = card.dataset.tier;
      state.trip.budgetTier = tier;

      const amounts = { backpacker: 14000, moderate: 32000, luxury: 58000, royal: 120000 };
      setBudgetAmount(amounts[tier] || 48000);
    });
  });

  const slider = document.getElementById('budgetSlider');
  if (slider) {
    slider.addEventListener('input', (e) => {
      setBudgetAmount(parseInt(e.target.value));
    });
  }

  document.querySelectorAll('.pace-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.pace-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      state.trip.pace = card.dataset.pace;
    });
  });

  document.querySelectorAll('.vibe-tag').forEach(tag => {
    tag.addEventListener('click', () => {
      const vibe = tag.dataset.vibe;
      const index = state.trip.vibes.indexOf(vibe);
      if (index >= 0) {
        state.trip.vibes.splice(index, 1);
        tag.classList.remove('selected');
      } else {
        state.trip.vibes.push(vibe);
        tag.classList.add('selected');
      }
      updateLiveBlueprint();
    });
  });

  setupSingleSelect('.choice-box[data-accom]', (el) => {
    state.trip.accommodation = el.dataset.accom;
  });
  setupSingleSelect('.choice-box[data-transit]', (el) => {
    state.trip.transport = el.dataset.transit;
  });

  document.querySelectorAll('.diet-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const diet = pill.dataset.diet;
      pill.classList.toggle('selected');
      if (diet === 'all') {
        state.trip.dietary = ['all'];
        document.querySelectorAll('.diet-pill:not([data-diet="all"])').forEach(p => p.classList.remove('selected'));
      } else {
        document.querySelector('.diet-pill[data-diet="all"]')?.classList.remove('selected');
        const i = state.trip.dietary.indexOf(diet);
        if (i >= 0) state.trip.dietary.splice(i, 1);
        else state.trip.dietary.push(diet);
      }
    });
  });

  const notesEl = document.getElementById('customNotes');
  if (notesEl) {
    notesEl.addEventListener('input', (e) => {
      state.trip.customNotes = e.target.value;
      updateLiveBlueprint();
    });
  }

  const currSelect = document.getElementById('currencySelector');
  if (currSelect) {
    currSelect.addEventListener('change', (e) => {
      state.currency = e.target.value;
      updateCurrencyLabels();
      updateLiveBlueprint();
    });
  }
}

function setBudgetAmount(amount) {
  state.trip.budgetAmount = amount;
  const slider = document.getElementById('budgetSlider');
  const display = document.getElementById('budgetAmountDisplay');
  const directInput = document.getElementById('budgetDirectInput');
  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';

  if (slider) slider.value = amount;
  if (display) {
    const converted = Math.round(amount * (CURRENCY_RATES_FROM_INR[state.currency] || 1));
    display.textContent = `${sym}${formatIndianNumber(converted)}`;
  }
  // Sync the direct budget input field (only if it doesn't already have focus to avoid cursor jump)
  if (directInput && document.activeElement !== directInput) {
    directInput.value = amount;
  }

  updateLiveBlueprint();
}

function updateCurrencyLabels() {
  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';
  const display = document.getElementById('budgetAmountDisplay');
  if (display) {
    const converted = Math.round(state.trip.budgetAmount * (CURRENCY_RATES_FROM_INR[state.currency] || 1));
    display.textContent = `${sym}${formatIndianNumber(converted)}`;
  }
}

function setupSingleSelect(selector, callback) {
  document.querySelectorAll(selector).forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll(selector).forEach(c => c.classList.remove('selected'));
      item.classList.add('selected');
      callback(item);
    });
  });
}

function setupStepper(minusId, plusId, valId, min, max, callback) {
  const minus = document.getElementById(minusId);
  const plus = document.getElementById(plusId);
  const val = document.getElementById(valId);

  if (minus && plus && val) {
    minus.addEventListener('click', () => {
      let cur = parseInt(val.textContent);
      if (cur > min) {
        cur--;
        val.textContent = cur;
        callback(cur);
      }
    });
    plus.addEventListener('click', () => {
      let cur = parseInt(val.textContent);
      if (cur < max) {
        cur++;
        val.textContent = cur;
        callback(cur);
      }
    });
  }
}

/**
 * Universal Indian Destination Search across all 780+ Districts, 36 Capitals, and Tourist Wonders
 */
function searchAllIndianDestinations(query) {
  const q = (query || '').trim().toLowerCase();
  const results = [];

  // 1. Search Curated Tourist Wonders (from TOURIST_PLACES_DATA)
  if (typeof TOURIST_PLACES_DATA !== 'undefined') {
    TOURIST_PLACES_DATA.forEach(p => {
      if (!q || p.name.toLowerCase().includes(q) || p.state.toLowerCase().includes(q) || p.district.toLowerCase().includes(q)) {
        results.push({
          name: `${p.name}, ${p.state}`,
          district: p.district,
          state: p.state,
          type: 'tourist',
          icon: p.category === 'beach' ? '🏖️' : p.category === 'spiritual' ? '🛕' : p.category === 'hill-station' ? '🏔️' : p.category === 'wildlife' ? '🐅' : p.category === 'adventure' ? '🧗' : '🏛️',
          badge: 'Tourist Place',
          badgeClass: 'ac-badge-tourist',
          highlight: p.tagline,
          image: p.image
        });
      }
    });
  }

  // 2. Search State Capitals (from INDIA_STATES_DATA)
  if (typeof INDIA_STATES_DATA !== 'undefined') {
    INDIA_STATES_DATA.forEach(s => {
      if (!q || s.capital.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)) {
        results.push({
          name: `${s.capital}, ${s.name}`,
          district: s.capital,
          state: s.name,
          type: 'capital',
          icon: '🏛️',
          badge: 'State Capital',
          badgeClass: 'ac-badge-capital',
          highlight: `${s.zone} Zone • ${s.districts.length} Districts Total`,
          image: 'assets/images/jaipur.jpg'
        });
      }
    });
  }

  // 3. Search All 780+ Districts of India (from INDIA_STATES_DATA)
  if (typeof INDIA_STATES_DATA !== 'undefined') {
    INDIA_STATES_DATA.forEach(s => {
      s.districts.forEach(d => {
        if (!q || d.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)) {
          // Avoid duplicate if already added as capital
          if (d.toLowerCase() !== s.capital.toLowerCase()) {
            const hl = s.districtHighlights && s.districtHighlights[d] ? s.districtHighlights[d] : `${s.zone} Zone (${s.type.toUpperCase()})`;
            results.push({
              name: `${d}, ${s.name}`,
              district: d,
              state: s.name,
              type: 'district',
              icon: '📍',
              badge: 'District',
              badgeClass: 'ac-badge-district',
              highlight: hl,
              image: 'assets/images/jaipur.jpg'
            });
          }
        }
      });
    });
  }

  // Deduplicate and cap for crisp performance
  const unique = [];
  const seen = new Set();
  for (const item of results) {
    const key = item.name.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(item);
    }
    if (unique.length >= 24) break;
  }

  return unique;
}

function renderAutocomplete(items) {
  const list = document.getElementById('autocompleteDropdown');
  if (!list) return;

  if (items.length === 0) {
    list.innerHTML = `
      <div class="autocomplete-item" style="cursor: default;">
        <div class="ac-icon">🔍</div>
        <div>
          <div class="ac-title">No matching district or destination found</div>
          <div class="ac-country">Try another keyword or select from the States dashboard</div>
        </div>
      </div>
    `;
    return;
  }

  list.innerHTML = items.map(item => {
    const safeName = item.name.replace(/'/g, "\\'");
    const safeState = item.state.replace(/'/g, "\\'");
    return `
      <div class="autocomplete-item" onclick="selectDestination('${safeName}', '${item.type}', '${safeState}')">
        <div class="ac-icon">${item.icon || '📍'}</div>
        <div style="flex: 1; min-width: 0;">
          <div class="ac-item-header">
            <div class="ac-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.name}</div>
            <span class="ac-type-badge ${item.badgeClass || 'ac-badge-district'}">${item.badge || 'District'}</span>
          </div>
          <div class="ac-country" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${item.highlight ? item.highlight : item.state + ', India'}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function selectDestination(name, key, stateName) {
  const destInput = document.getElementById('destinationInput');
  const acDropdown = document.getElementById('autocompleteDropdown');

  if (destInput) destInput.value = name;
  if (acDropdown) acDropdown.classList.remove('active');

  state.trip.destination = name;
  state.trip.destinationKey = key || 'custom';

  // Check if destination is from another state compared to departure origin
  if (typeof analyzeInterStateTravel === 'function') {
    const analysis = analyzeInterStateTravel(state.trip.origin, name);
    if (analysis && analysis.isInterState) {
      showToast(`🛫 Inter-State Destination Selected: ${name}! Cross-state circuit active.`, 'success');
    } else {
      showToast(`Destination set to ${name}`, 'info');
    }
  } else {
    showToast(`Destination set to ${name}`, 'info');
  }

  updateLiveBlueprint();
  renderTransportCards();
}

/**
 * Trigger Live Location Detection for Departure District
 */
function triggerDetectLiveLocation() {
  const statusEl = document.getElementById('liveLocStatusText');
  const btn = document.getElementById('btnDetectLiveLocation');

  if (statusEl) {
    statusEl.innerHTML = `📍 Acquiring live GPS coordinates & nearest Indian district...`;
  }
  if (btn) btn.disabled = true;

  if (typeof detectUserLiveLocation === 'function') {
    detectUserLiveLocation(
      (nearest) => {
        const originVal = `${nearest.district}, ${nearest.state} (${nearest.hub})`;
        state.trip.origin = originVal;
        localStorage.setItem('bharatyatra_user_origin', originVal);

        const originInput = document.getElementById('originInput');
        if (originInput) originInput.value = originVal;

        if (statusEl) {
          statusEl.innerHTML = `✅ Live Location Detected: <strong>${nearest.district}, ${nearest.state}</strong> (${nearest.hub})`;
        }
        if (btn) btn.disabled = false;

        showToast(`📍 Departure set to your location: ${nearest.district}, ${nearest.state}!`, 'success');
        updateLiveBlueprint();
        renderTransportCards();
      },
      (errMsg, fallback) => {
        const saved = localStorage.getItem('bharatyatra_user_origin');
        const originVal = saved || (fallback ? `${fallback.district}, ${fallback.state} (${fallback.hub})` : 'Bengaluru (BLR)');
        state.trip.origin = originVal;
        localStorage.setItem('bharatyatra_user_origin', originVal);

        const originInput = document.getElementById('originInput');
        if (originInput) originInput.value = originVal;

        if (statusEl) {
          statusEl.innerHTML = `📍 Departure Origin: <strong>${originVal}</strong>`;
        }
        if (btn) btn.disabled = false;
        updateLiveBlueprint();
        renderTransportCards();
      }
    );
  }
}

/**
 * 1-Click Departure Origin Setter
 */
function setOriginCity(cityName) {
  state.trip.origin = cityName;
  localStorage.setItem('bharatyatra_user_origin', cityName);

  const originInput = document.getElementById('originInput');
  if (originInput) originInput.value = cityName;

  const statusEl = document.getElementById('liveLocStatusText');
  if (statusEl) {
    statusEl.innerHTML = `📍 Departure Origin set to: <strong>${cityName}</strong>`;
  }

  showToast(`📍 Departure origin set to: ${cityName}`, 'info');
  updateLiveBlueprint();
  renderTransportCards();
}

/* --------------------------------------------------------------------------
   Quick Preset Loaders
   -------------------------------------------------------------------------- */
function loadPreset(presetKey) {
  const preset = CURATED_PRESETS[presetKey];
  if (!preset) return;

  state.trip.destination = preset.name;
  state.trip.destinationKey = preset.id;

  // Preserve user's own origin if already set or saved
  const userSavedOrigin = localStorage.getItem('bharatyatra_user_origin') || state.trip.origin;
  if (userSavedOrigin && userSavedOrigin.trim() && userSavedOrigin !== 'New Delhi (DEL)') {
    state.trip.origin = userSavedOrigin;
  } else if (!state.trip.origin) {
    state.trip.origin = preset.origin;
  }

  state.trip.party = preset.party;
  state.trip.adults = preset.adults;
  state.trip.children = preset.children;
  state.trip.budgetTier = preset.budgetTier;
  state.trip.budgetAmount = preset.budgetAmount;
  state.trip.pace = preset.pace;
  state.trip.vibes = [...preset.vibes];
  state.trip.accommodation = preset.accommodation;
  state.trip.transport = preset.transport;
  state.trip.dietary = [...preset.dietary];
  state.trip.customNotes = preset.customNotes;

  const destInput = document.getElementById('destinationInput');
  const originInput = document.getElementById('originInput');
  const notesEl = document.getElementById('customNotes');
  const adultsVal = document.getElementById('adultsVal');
  const kidsVal = document.getElementById('kidsVal');

  if (destInput) destInput.value = preset.name;
  if (originInput && state.trip.origin) originInput.value = state.trip.origin;
  if (notesEl) notesEl.value = preset.customNotes;
  if (adultsVal) adultsVal.textContent = preset.adults;
  if (kidsVal) kidsVal.textContent = preset.children;

  setQuickDuration(preset.durationDays);

  document.querySelectorAll('.party-card').forEach(c => {
    c.classList.toggle('selected', c.dataset.party === preset.party);
  });

  document.querySelectorAll('.budget-tier-card').forEach(c => {
    c.classList.toggle('selected', c.dataset.tier === preset.budgetTier);
  });
  setBudgetAmount(preset.budgetAmount);

  document.querySelectorAll('.pace-card').forEach(c => {
    c.classList.toggle('selected', c.dataset.pace === preset.pace);
  });

  document.querySelectorAll('.vibe-tag').forEach(tag => {
    tag.classList.toggle('selected', preset.vibes.includes(tag.dataset.vibe));
  });

  document.querySelectorAll('.choice-box[data-accom]').forEach(c => {
    c.classList.toggle('selected', c.dataset.accom === preset.accommodation);
  });
  document.querySelectorAll('.choice-box[data-transit]').forEach(c => {
    c.classList.toggle('selected', c.dataset.transit === preset.transport);
  });

  updateLiveBlueprint();
  renderTransportCards();
  showToast(`Loaded ${preset.name} yatra preset!`, 'success');
}

/* --------------------------------------------------------------------------
   Itinerary Generation Simulator
   -------------------------------------------------------------------------- */
function triggerGenerateItinerary() {
  const overlay = document.getElementById('genLoadingOverlay');
  if (!overlay) return;

  overlay.classList.add('active');

  const steps = [
    { title: 'Calling Gemini 2.5 Bharat Engine...', id: 'genStep1' },
    { title: 'Optimizing railway routes & outstation ghat circuits...', id: 'genStep2' },
    { title: 'Curating authentic dhabas, local thalis & heritage guides...', id: 'genStep3' },
    { title: 'Finalizing day-by-day Indian yatra blueprint...', id: 'genStep4' }
  ];

  let current = 0;
  const statusMsg = document.getElementById('genStatusMsg');

  const interval = setInterval(() => {
    if (current < steps.length) {
      if (statusMsg) statusMsg.textContent = steps[current].title;
      
      const el = document.getElementById(steps[current].id);
      if (el) {
        el.classList.add('active');
        if (current > 0) {
          const prevEl = document.getElementById(steps[current - 1].id);
          if (prevEl) {
            prevEl.classList.remove('active');
            prevEl.classList.add('done');
          }
        }
      }
      current++;
    } else {
      clearInterval(interval);
      const lastEl = document.getElementById(steps[steps.length - 1].id);
      if (lastEl) {
        lastEl.classList.remove('active');
        lastEl.classList.add('done');
      }

      setTimeout(() => {
        overlay.classList.remove('active');
        renderItinerary();
      }, 400);
    }
  }, 450);
}

function renderItinerary() {
  const showcase = document.getElementById('itineraryShowcase');
  if (!showcase) return;

  let data = null;
  if (CURATED_PRESETS[state.trip.destinationKey]) {
    data = CURATED_PRESETS[state.trip.destinationKey].itinerary;
  } else {
    data = CURATED_PRESETS.jaipur.itinerary;
  }

  state.currentItinerary = data;

  const bannerImg = document.getElementById('itinBannerBg');
  const bannerTitle = document.getElementById('itinBannerTitle');
  const bannerMeta = document.getElementById('itinBannerMeta');

  const preset = CURATED_PRESETS[state.trip.destinationKey] || CURATED_PRESETS.jaipur;
  if (bannerImg) bannerImg.src = preset.image;
  if (bannerTitle) bannerTitle.textContent = `${state.trip.durationDays}-Day ${state.trip.destination} Yatra Blueprint`;
  
  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';
  const totalCostConverted = Math.round(data.totalEstimatedCost * (CURRENCY_RATES_FROM_INR[state.currency] || 1));

  if (bannerMeta) {
    bannerMeta.innerHTML = `
      <span>📅 ${state.trip.durationDays} Days</span>
      <span>👥 ${state.trip.adults + state.trip.children} Travelers (${capitalize(state.trip.party)})</span>
      <span>💰 Total Estimate: ${sym}${formatIndianNumber(totalCostConverted)}</span>
      <span>⚡ Pace: ${capitalize(state.trip.pace)}</span>
    `;
  }

  const scheduleStack = document.getElementById('daysTimelineStack');
  if (scheduleStack) {
    scheduleStack.innerHTML = data.days.map(d => renderDayCard(d, sym)).join('');
  }

  renderBudgetBreakdown(data.budgetBreakdown, sym);
  renderWeatherForecast(data.weatherForecast);
  renderAdvisorNotes(data.advisorNotes);
  renderItineraryTransportHub();

  showcase.classList.add('active');
  window.scrollTo({ top: showcase.offsetTop - 80, behavior: 'smooth' });
  showToast('Indian Yatra Itinerary ready!', 'success');
}

function renderDayCard(day, sym) {
  return `
    <div class="day-card glass-panel">
      <div class="day-card-header">
        <div class="day-badge-wrap">
          <span class="day-number-tag">Day ${day.dayNumber}</span>
          <h3 class="day-theme-title">${day.theme}</h3>
        </div>
        <span class="day-meta-text">${day.activities.length} curated highlights</span>
      </div>

      <div class="activity-slots-list">
        ${day.activities.map(act => {
          const convertedCost = Math.round(act.cost * (CURRENCY_RATES_FROM_INR[state.currency] || 1));
          return `
            <div class="activity-slot-item">
              <div class="activity-time-block">
                <span class="slot-time">${act.time}</span>
                <span class="slot-period">${act.period}</span>
              </div>
              <div class="activity-main-info">
                <div class="activity-title-row">
                  <h4 class="act-title">${act.title}</h4>
                  <span class="act-category-badge">${act.category}</span>
                </div>
                <p class="act-desc">${act.desc}</p>
                <div class="act-tip-box">
                  <span>💡 Local Yatra Tip: ${act.tip}</span>
                </div>
                <div style="font-size: 0.775rem; color: var(--text-muted); margin-top: 0.25rem;">
                  📍 ${act.location}
                </div>
              </div>
              <div class="activity-cost-badge">
                ${act.cost === 0 ? 'Free' : `${sym}${formatIndianNumber(convertedCost)}`}
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

function renderBudgetBreakdown(breakdown, sym) {
  const container = document.getElementById('budgetBreakdownWrap');
  if (!container || !breakdown) return;

  const total = Object.values(breakdown).reduce((acc, c) => acc + c.amount, 0);
  const convertedTotal = Math.round(total * (CURRENCY_RATES_FROM_INR[state.currency] || 1));

  container.innerHTML = `
    <div class="budget-overview-grid">
      <div class="budget-metric-card">
        <div class="stat-lbl">Estimated Total Yatra Budget</div>
        <div class="budget-metric-val gradient-text">${sym}${formatIndianNumber(convertedTotal)}</div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">For ${state.trip.durationDays} days trip</div>
      </div>
      <div class="budget-metric-card">
        <div class="stat-lbl">Per Person / Day</div>
        <div class="budget-metric-val" style="color: var(--accent-cyan);">
          ${sym}${formatIndianNumber(Math.round(convertedTotal / (state.trip.durationDays * (state.trip.adults + state.trip.children))))}
        </div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">Smart Indian allocation</div>
      </div>
      <div class="budget-metric-card">
        <div class="stat-lbl">Buffer / Souvenirs</div>
        <div class="budget-metric-val" style="color: #34d399;">
          ${sym}${formatIndianNumber(Math.round((breakdown.cushion ? breakdown.cushion.amount : 2500) * (CURRENCY_RATES_FROM_INR[state.currency] || 1)))}
        </div>
        <div style="font-size: 0.8rem; color: var(--text-muted);">Bazaar shopping & emergency cushion</div>
      </div>
    </div>

    <div class="budget-progress-container">
      <h3 style="font-size: 1.15rem; margin-bottom: 0.5rem;">Indian Rupee (₹) Cost Allocation</h3>
      ${Object.entries(breakdown).map(([k, cat]) => {
        const catConverted = Math.round(cat.amount * (CURRENCY_RATES_FROM_INR[state.currency] || 1));
        const colors = {
          accommodation: 'linear-gradient(90deg, #8b5cf6, #c084fc)',
          food: 'linear-gradient(90deg, #ec4899, #f43f5e)',
          transit: 'linear-gradient(90deg, #f59e0b, #fbbf24)',
          activities: 'linear-gradient(90deg, #06b6d4, #38bdf8)',
          cushion: 'linear-gradient(90deg, #10b981, #34d399)'
        };
        return `
          <div class="budget-category-row">
            <div class="cat-head">
              <span>${capitalize(k)} (${cat.label})</span>
              <span>${sym}${formatIndianNumber(catConverted)} • ${cat.percent}%</span>
            </div>
            <div class="cat-bar-track">
              <div class="cat-bar-fill" style="width: ${cat.percent}%; background: ${colors[k] || 'var(--accent-violet)'};"></div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderWeatherForecast(forecast) {
  const container = document.getElementById('weatherForecastWrap');
  if (!container || !forecast) return;

  container.innerHTML = `
    <div class="weather-cards-row">
      ${forecast.map(w => `
        <div class="weather-day-card glass-panel">
          <div style="font-size: 0.85rem; font-weight: 700;">${w.day}</div>
          <div class="weather-icon-lg">${w.icon}</div>
          <div class="weather-temp">${w.temp}</div>
          <div style="font-size: 0.775rem; color: var(--text-muted); margin-top: 0.25rem;">${w.desc}</div>
        </div>
      `).join('')}
    </div>

    <div class="glass-panel" style="padding: 1.5rem; margin-top: 1.5rem;">
      <h4 style="margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem;">
        <span>🎒 Indian Travel Packing & Essentials</span>
      </h4>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; font-size: 0.85rem;">
        <div>
          <strong style="color: var(--accent-cyan);">Clothing & Temples:</strong>
          <p style="margin-top: 0.25rem;">Breathable cottons, modest attire for temples (covering shoulders & knees), slip-on shoes for temple shoe-stands.</p>
        </div>
        <div>
          <strong style="color: var(--accent-violet);">Transit & Money:</strong>
          <p style="margin-top: 0.25rem;">Keep ₹100/₹500 cash for toll gates and street food vendors (UPI QR codes accepted everywhere else).</p>
        </div>
        <div>
          <strong style="color: #34d399;">Health & Hydration:</strong>
          <p style="margin-top: 0.25rem;">Electrolyte ORS sachets, mosquito repellent spray (Odomos), carry personal water bottle for filtered RO refills.</p>
        </div>
      </div>
    </div>
  `;
}

function renderAdvisorNotes(notes) {
  const container = document.getElementById('advisorNotesWrap');
  if (!container || !notes) return;

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 1rem;">
      ${notes.map(n => `
        <div class="glass-panel" style="padding: 1.25rem; display: flex; gap: 1rem; align-items: flex-start;">
          <div style="font-size: 1.75rem; line-height: 1;">${n.icon}</div>
          <div>
            <h4 style="font-size: 1rem; font-weight: 700; margin-bottom: 0.25rem;">${n.title}</h4>
            <p style="font-size: 0.85rem; color: var(--text-secondary);">${n.text}</p>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

function switchItinTab(tabName) {
  document.querySelectorAll('.itin-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });
  document.querySelectorAll('.itin-tab-content').forEach(tab => {
    tab.classList.toggle('active', tab.id === `tabContent_${tabName}`);
  });
}

/* --------------------------------------------------------------------------
   Saved Trips & LocalStorage
   -------------------------------------------------------------------------- */
function loadSavedTrips() {
  const raw = localStorage.getItem('wanderai_saved_trips');
  if (raw) {
    try {
      state.savedTrips = JSON.parse(raw);
    } catch (e) {
      state.savedTrips = [];
    }
  } else {
    state.savedTrips = [
      {
        id: 'saved_jaipur_demo',
        title: '4 Days Royal Jaipur & Amer',
        destination: 'Jaipur, Rajasthan',
        destinationKey: 'jaipur',
        duration: 4,
        budget: 48000,
        currency: 'INR',
        date: 'Oct 2026',
        createdAt: new Date().toISOString()
      }
    ];
    saveTripsToStorage();
  }
  updateSavedBadge();
}

function saveTripsToStorage() {
  localStorage.setItem('wanderai_saved_trips', JSON.stringify(state.savedTrips));
  updateSavedBadge();
}

function updateSavedBadge() {
  const badge = document.getElementById('savedTripsBadge');
  if (badge) badge.textContent = state.savedTrips.length;
}

function saveCurrentTripDraft() {
  const newTrip = {
    id: 'trip_' + Date.now(),
    title: `${state.trip.durationDays} Days in ${state.trip.destination}`,
    destination: state.trip.destination,
    destinationKey: state.trip.destinationKey,
    duration: state.trip.durationDays,
    budget: state.trip.budgetAmount,
    currency: state.currency,
    date: state.trip.startDate,
    fullState: JSON.parse(JSON.stringify(state.trip)),
    createdAt: new Date().toISOString()
  };

  state.savedTrips.unshift(newTrip);
  saveTripsToStorage();
  showToast('Yatra successfully saved to your collection!', 'success');
}

function openSavedTripsModal() {
  const modal = document.getElementById('savedTripsModal');
  const body = document.getElementById('savedTripsListBody');
  if (!modal || !body) return;

  if (state.savedTrips.length === 0) {
    body.innerHTML = `
      <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
        <p>No saved trips yet. Click "Save Draft" in the blueprint or itinerary view!</p>
      </div>
    `;
  } else {
    body.innerHTML = state.savedTrips.map(t => {
      const sym = CURRENCY_SYMBOLS[t.currency] || '₹';
      return `
        <div class="saved-trip-item">
          <div>
            <h4 style="font-size: 1rem; font-weight: 700;">${t.title}</h4>
            <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.2rem;">
              📍 ${t.destination} • ⏱️ ${t.duration} Days • 💰 ${sym}${formatIndianNumber(t.budget)}
            </div>
          </div>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn-secondary" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;" onclick="loadSavedTripById('${t.id}')">
              Load
            </button>
            <button class="btn-ghost" style="padding: 0.4rem 0.6rem; color: var(--accent-rose);" onclick="deleteSavedTrip('${t.id}')">
              ✕
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  modal.classList.add('active');
}

function closeSavedTripsModal() {
  const modal = document.getElementById('savedTripsModal');
  if (modal) modal.classList.remove('active');
}

function loadSavedTripById(id) {
  const found = state.savedTrips.find(t => t.id === id);
  if (found) {
    if (found.destinationKey) {
      loadPreset(found.destinationKey);
    }
    closeSavedTripsModal();
    showToast(`Loaded ${found.title}`, 'info');
  }
}

function deleteSavedTrip(id) {
  state.savedTrips = state.savedTrips.filter(t => t.id !== id);
  saveTripsToStorage();
  openSavedTripsModal();
  showToast('Trip deleted', 'info');
}

/* --------------------------------------------------------------------------
   Export & Share Actions
   -------------------------------------------------------------------------- */
function exportItineraryJSON() {
  const exportData = {
    tripMetadata: state.trip,
    itineraryBlueprint: state.currentItinerary || CURATED_PRESETS.jaipur.itinerary,
    generatedAt: new Date().toISOString(),
    generator: 'WanderAI Bharat Engine v1.0'
  };

  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportData, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `bharat-yatra-${state.trip.destinationKey || 'trip'}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();

  showToast('Yatra JSON exported successfully!', 'success');
}

function printItinerary() {
  window.print();
}

function copyShareLink() {
  const dummyLink = `${window.location.origin}${window.location.pathname}?dest=${encodeURIComponent(state.trip.destination)}&days=${state.trip.durationDays}`;
  navigator.clipboard.writeText(dummyLink).then(() => {
    showToast('Yatra link copied to clipboard!', 'success');
  }).catch(() => {
    showToast('Failed to copy link', 'info');
  });
}

function scrollToForm() {
  window.scrollTo({ top: document.getElementById('plannerFormBox').offsetTop - 80, behavior: 'smooth' });
}

function resetForm() {
  loadPreset('jaipur');
  goToStep(1);
  const showcase = document.getElementById('itineraryShowcase');
  if (showcase) showcase.classList.remove('active');
  showToast('Form reset to Jaipur defaults', 'info');
}

/* --------------------------------------------------------------------------
   Floating Toast System
   -------------------------------------------------------------------------- */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : 'ℹ'}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

/* --------------------------------------------------------------------------
   Transport Hub & Time Management Logic (Plains, Trains, Buses, Own Vehicle)
   -------------------------------------------------------------------------- */
function renderTransportCards() {
  const result = getFilteredTransportOptions(
    state.trip.destinationKey,
    state.transportFilter.mode,
    state.transportFilter.maxBudget,
    state.transportFilter.maxHours,
    state.transportFilter.priority,
    state.trip.origin,
    state.trip.destination
  );

  const destTitle = document.getElementById('transDestTitle');
  const routeBadge = document.getElementById('transRouteBadge');
  const container = document.getElementById('transportCardsContainer');

  if (destTitle) destTitle.textContent = state.trip.destination || 'Selected Destination';
  if (routeBadge) {
    const originCity = state.trip.origin || result.origin;
    routeBadge.innerHTML = `<span>📍 ~${result.distanceKm.toLocaleString('en-IN')} km from ${originCity}</span>`;
  }

  updateFilterStatusStrip(result);

  if (!container) return;

  if (result.options.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 2.5rem 1rem; color: var(--text-muted); background: var(--bg-card); border-radius: var(--radius-md);">
        <div style="font-size: 2rem; margin-bottom: 0.5rem;">🔍</div>
        <p style="font-weight: 700; color: var(--text-main);">No transport options matching current filters</p>
        <p style="font-size: 0.8rem; margin-top: 0.35rem;">Try increasing your max fare or selecting "All Modes" to see available flights, trains, and buses.</p>
        <button type="button" class="btn-secondary" style="margin-top: 1rem; font-size: 0.8rem;" onclick="resetTransportFilters()">Reset Transport Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = result.options.map(opt => renderSingleTransportCard(opt)).join('');
}

function renderSingleTransportCard(opt) {
  const isSelected = state.selectedTransport === opt.id;
  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';
  const priceFormatted = opt.mode === 'car' ? `~${sym}${formatIndianNumber(opt.price)} (total)` : `${sym}${formatIndianNumber(opt.price)}`;

  return `
    <div class="transport-card ${isSelected ? 'selected-for-trip' : ''}" id="card_${opt.id}">
      <div class="trans-card-top">
        <div class="trans-carrier-info">
          <div class="trans-mode-icon">${opt.modeIcon}</div>
          <div>
            <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
              <h4 class="trans-title">${opt.title}</h4>
              <span class="phase-pill" style="font-size: 0.675rem;">${opt.badge}</span>
            </div>
            <div class="trans-operator">${opt.operator} • ${opt.frequency}</div>
          </div>
        </div>

        <div class="trans-price-box">
          <div class="trans-price-val">${priceFormatted}</div>
          <div class="trans-price-sub">${opt.mode === 'car' ? 'Fuel + FASTag Toll' : 'Base Fare per person'}</div>
        </div>
      </div>

      <div class="trans-route-timeline">
        <div class="time-point-block">
          <span class="time-val">${opt.departureTime}</span>
          <span class="time-place">${opt.route.split('➔')[0].trim()}</span>
        </div>

        <div class="duration-connector">
          <span class="duration-pill">⏱️ ${opt.duration}</span>
          <div class="duration-line"></div>
        </div>

        <div class="time-point-block" style="text-align: right;">
          <span class="time-val">${opt.arrivalTime}</span>
          <span class="time-place">${opt.route.split('➔')[1] ? opt.route.split('➔')[1].trim() : state.trip.destination}</span>
        </div>
      </div>

      <div class="time-impact-callout">
        <span>⏰</span>
        <span><strong>Time Management:</strong> ${opt.timeImpact}</span>
      </div>

      <div class="trans-card-actions">
        <div class="trans-tag-row">
          <span style="font-size: 0.775rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.35rem;">
            <span>✓ ${opt.pros}</span>
          </span>
        </div>

        <div class="trans-btn-group">
          <button type="button" class="btn-secondary" style="font-size: 0.8rem; padding: 0.45rem 0.9rem;" onclick="selectTransportForTrip('${opt.id}')">
            ${isSelected ? '✓ Selected Transit' : '+ Select for Yatra'}
          </button>
          <button type="button" class="btn-book-action" onclick="openBookingModal('${opt.id}')">
            <span>Book / Availability ↗</span>
          </button>
        </div>
      </div>
    </div>
  `;
}

function filterTransportMode(mode) {
  state.transportFilter.mode = mode;
  document.querySelectorAll('.trans-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });
  renderTransportCards();
  const itinWrap = document.getElementById('itinTransportHubWrap');
  if (itinWrap && itinWrap.children.length > 0) {
    renderItineraryTransportHub();
  }
}

function filterTransportBudget(maxBudget, btnEl) {
  state.transportFilter.maxBudget = maxBudget;
  // Sync fare quick chips
  document.querySelectorAll('.fare-quick-chips .chip-mini').forEach(c => c.classList.remove('active'));
  if (btnEl) {
    btnEl.classList.add('active');
  }
  // Sync custom fare input
  const fareInput = document.getElementById('customFareInput');
  const clearBtn = document.getElementById('clearFareBtn');
  if (fareInput) {
    fareInput.value = maxBudget || '';
  }
  if (clearBtn) {
    clearBtn.style.display = maxBudget ? 'flex' : 'none';
  }
  renderTransportCards();
  const itinWrap = document.getElementById('itinTransportHubWrap');
  if (itinWrap && itinWrap.children.length > 0) {
    renderItineraryTransportHub();
  }
}

function filterTransportHours(maxHours, btnEl) {
  state.transportFilter.maxHours = maxHours;
  if (btnEl && btnEl.parentElement) {
    btnEl.parentElement.querySelectorAll('.chip-mini').forEach(c => c.classList.remove('active'));
    btnEl.classList.add('active');
  }
  renderTransportCards();
  const itinWrap = document.getElementById('itinTransportHubWrap');
  if (itinWrap && itinWrap.children.length > 0) {
    renderItineraryTransportHub();
  }
}

function resetTransportFilters() {
  state.transportFilter.mode = 'all';
  state.transportFilter.maxBudget = null;
  state.transportFilter.maxHours = null;
  state.transportFilter.priority = 'none';
  document.querySelectorAll('.trans-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === 'all');
  });
  document.querySelectorAll('.fare-quick-chips .chip-mini').forEach(c => c.classList.remove('active'));
  const anyFareChip = document.querySelector('.fare-quick-chips .chip-mini[data-fare="null"]');
  if (anyFareChip) anyFareChip.classList.add('active');
  document.querySelectorAll('.max-time-subfilter .chip-mini').forEach((c, i) => {
    c.classList.toggle('active', i === 0);
  });
  // Reset custom fare input
  const fareInput = document.getElementById('customFareInput');
  const clearBtn = document.getElementById('clearFareBtn');
  if (fareInput) fareInput.value = '';
  if (clearBtn) clearBtn.style.display = 'none';
  // Reset priority toggle
  document.querySelectorAll('.priority-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.priority === 'none');
  });
  renderTransportCards();
}

/* --------------------------------------------------------------------------
   Custom Fare Input & Priority Filter
   -------------------------------------------------------------------------- */
function handleCustomFareInput(val) {
  const amount = parseInt(val);
  const clearBtn = document.getElementById('clearFareBtn');
  if (isNaN(amount) || amount <= 0) {
    state.transportFilter.maxBudget = null;
    if (clearBtn) clearBtn.style.display = 'none';
  } else {
    state.transportFilter.maxBudget = amount;
    if (clearBtn) clearBtn.style.display = 'flex';
  }
  // Deselect all fare quick chips, select 'Any Fare' if empty
  document.querySelectorAll('.fare-quick-chips .chip-mini').forEach(c => c.classList.remove('active'));
  if (!state.transportFilter.maxBudget) {
    const anyFareChip = document.querySelector('.fare-quick-chips .chip-mini[data-fare="null"]');
    if (anyFareChip) anyFareChip.classList.add('active');
  }
  renderTransportCards();
  const itinWrap = document.getElementById('itinTransportHubWrap');
  if (itinWrap && itinWrap.children.length > 0) {
    renderItineraryTransportHub();
  }
}

function clearCustomFare() {
  const fareInput = document.getElementById('customFareInput');
  const clearBtn = document.getElementById('clearFareBtn');
  if (fareInput) fareInput.value = '';
  if (clearBtn) clearBtn.style.display = 'none';
  state.transportFilter.maxBudget = null;
  document.querySelectorAll('.fare-quick-chips .chip-mini').forEach(c => c.classList.remove('active'));
  const anyFareChip = document.querySelector('.fare-quick-chips .chip-mini[data-fare="null"]');
  if (anyFareChip) anyFareChip.classList.add('active');
  renderTransportCards();
}

function setTransportPriority(priority) {
  state.transportFilter.priority = priority;

  // Update old pill buttons (for compatibility)
  document.querySelectorAll('.priority-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.priority === priority);
  });

  // Update new radio buttons visual state
  const radioTime = document.getElementById('radioSortTime');
  const radioMoney = document.getElementById('radioSortMoney');
  const labelTime = document.getElementById('labelSortTime');
  const labelMoney = document.getElementById('labelSortMoney');

  if (radioTime && radioMoney) {
    if (priority === 'time') {
      radioTime.checked = true;
      if (labelTime) {
        labelTime.style.border = '2px solid var(--accent-cyan)';
        labelTime.style.background = 'rgba(6,182,212,0.10)';
        labelTime.style.color = 'var(--accent-cyan)';
      }
      if (labelMoney) {
        labelMoney.style.border = '2px solid transparent';
        labelMoney.style.background = 'transparent';
        labelMoney.style.color = 'var(--text-secondary)';
      }
    } else if (priority === 'money') {
      radioMoney.checked = true;
      if (labelMoney) {
        labelMoney.style.border = '2px solid var(--accent-emerald)';
        labelMoney.style.background = 'rgba(16,185,129,0.10)';
        labelMoney.style.color = 'var(--accent-emerald)';
      }
      if (labelTime) {
        labelTime.style.border = '2px solid transparent';
        labelTime.style.background = 'transparent';
        labelTime.style.color = 'var(--text-secondary)';
      }
    } else {
      // none / balanced
      [radioTime, radioMoney].forEach(r => r.checked = false);
      [labelTime, labelMoney].forEach(l => {
        if (l) {
          l.style.border = '2px solid transparent';
          l.style.background = 'transparent';
          l.style.color = 'var(--text-secondary)';
        }
      });
    }
  }

  renderTransportCards();
  const itinWrap = document.getElementById('itinTransportHubWrap');
  if (itinWrap && itinWrap.children.length > 0) {
    renderItineraryTransportHub();
  }
}

function updateFilterStatusStrip(result) {
  const strip = document.getElementById('transFilterStatusStrip');
  if (!strip) return;

  const parts = [];
  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';
  const priority = state.transportFilter.priority;

  if (priority === 'money') {
    parts.push('<span class="filter-status-tag filter-tag-money">💰 Sorted: Cheapest First</span>');
  } else if (priority === 'time') {
    parts.push('<span class="filter-status-tag filter-tag-time">⏱️ Sorted: Fastest First</span>');
  }

  if (state.transportFilter.mode !== 'all') {
    const modeLabels = { flight: '✈️ Flights', train: '🚆 Trains', bus: '🚌 Buses', car: '🚗 Own Vehicle' };
    parts.push(`<span class="filter-status-tag">${modeLabels[state.transportFilter.mode] || state.transportFilter.mode}</span>`);
  }

  if (state.transportFilter.maxBudget) {
    parts.push(`<span class="filter-status-tag">Max Fare: ${sym}${formatIndianNumber(state.transportFilter.maxBudget)}</span>`);
  }

  if (state.transportFilter.maxHours) {
    parts.push(`<span class="filter-status-tag">Max Time: ${state.transportFilter.maxHours}h</span>`);
  }

  if (parts.length > 0) {
    parts.push(`<span class="filter-status-count">${result.matchedCount} of ${result.totalAvailable} options shown</span>`);
    strip.innerHTML = parts.join('');
    strip.style.display = 'flex';
  } else {
    strip.innerHTML = '';
    strip.style.display = 'none';
  }
}

function selectTransportForTrip(transportId) {
  state.selectedTransport = transportId;
  const currentKey = state.trip.destinationKey || 'jaipur';
  const data = TRANSPORT_DATABASE[currentKey] || TRANSPORT_DATABASE.jaipur;
  const opt = data.options.find(o => o.id === transportId);
  
  if (opt) {
    state.trip.transport = opt.mode;
    renderTransportCards();
    showToast(`Locked ${opt.title} into your yatra!`, 'success');

    // Dynamically update Day 1 arrival in the day-by-day itinerary if already generated
    if (state.currentItinerary && state.currentItinerary.days && state.currentItinerary.days[0]) {
      const day1 = state.currentItinerary.days[0];
      if (day1.activities && day1.activities[0]) {
        day1.activities[0].title = `${opt.title} Arrival & Check-in`;
        day1.activities[0].time = opt.arrivalTime;
        day1.activities[0].desc = `Arrive in ${state.trip.destination} via ${opt.title}. ${opt.timeImpact}`;
        day1.activities[0].cost = opt.price;
        const scheduleStack = document.getElementById('daysTimelineStack');
        const sym = CURRENCY_SYMBOLS[state.currency] || '₹';
        if (scheduleStack) {
          scheduleStack.innerHTML = state.currentItinerary.days.map(d => renderDayCard(d, sym)).join('');
        }
      }
    }
  }
}

function openBookingModal(transportId) {
  const currentKey = state.trip.destinationKey || 'jaipur';
  const data = TRANSPORT_DATABASE[currentKey] || TRANSPORT_DATABASE.jaipur;
  const opt = data.options.find(o => o.id === transportId) || data.options[0];
  if (!opt) return;

  const modal = document.getElementById('bookingModal');
  const modalBody = document.getElementById('bookingModalBody');
  const bmTitle = document.getElementById('bmTitle');
  const bmModeIcon = document.getElementById('bmModeIcon');
  const bmRoute = document.getElementById('bmRoute');

  if (bmTitle) bmTitle.textContent = opt.title;
  if (bmModeIcon) bmModeIcon.textContent = opt.modeIcon;
  if (bmRoute) bmRoute.textContent = opt.route;

  const sym = CURRENCY_SYMBOLS[state.currency] || '₹';

  if (modalBody) {
    modalBody.innerHTML = `
      <div class="booking-details-box">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
          <div>
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700;">Operator & Mode</span>
            <div style="font-size: 1rem; font-weight: 700;">${opt.operator} (${opt.modeLabel})</div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700;">Starting Fare</span>
            <div style="font-size: 1.25rem; font-weight: 800; color: #34d399;">${sym}${formatIndianNumber(opt.price)}</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; padding-top: 0.75rem; border-top: 1px solid var(--border-subtle); font-size: 0.85rem;">
          <div>
            <strong style="color: var(--text-muted);">Departure:</strong>
            <p style="font-family: var(--font-mono); font-weight: 700; color: var(--accent-cyan);">${opt.departureTime}</p>
            <p style="font-size: 0.75rem; color: var(--text-secondary);">${opt.route.split('➔')[0]}</p>
          </div>
          <div>
            <strong style="color: var(--text-muted);">Arrival:</strong>
            <p style="font-family: var(--font-mono); font-weight: 700; color: #34d399;">${opt.arrivalTime}</p>
            <p style="font-size: 0.75rem; color: var(--text-secondary);">${opt.route.split('➔')[1] || state.trip.destination}</p>
          </div>
        </div>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem;">Available Ticket Classes / Pricing</h4>
        <div class="classes-list-box">
          ${opt.classes.map(cls => `
            <div class="class-tier-item">
              <span style="font-weight: 600;">${cls.split(':')[0]}</span>
              <span style="color: var(--accent-cyan); font-weight: 700;">${cls.split(':')[1] || ''}</span>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="time-impact-callout">
        <span>⏰</span>
        <span><strong>Schedule & Time Management:</strong> ${opt.timeImpact}</span>
      </div>

      ${opt.pitstops ? `
        <div style="background: var(--bg-card); padding: 0.85rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); font-size: 0.85rem;">
          <strong style="color: var(--accent-amber);">Recommended Highway Pit-Stops & Dhabas:</strong>
          <ul style="margin-left: 1.25rem; margin-top: 0.35rem; color: var(--text-secondary);">
            ${opt.pitstops.map(p => `<li>${p}</li>`).join('')}
          </ul>
        </div>
      ` : ''}

      <div>
        <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; display: flex; align-items: center; justify-content: space-between;">
          <span>Official Direct Booking Portals</span>
          <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 400;">Opens official verified portal</span>
        </h4>
        <div class="provider-buttons-grid">
          ${opt.bookingProviders.map(p => `
            <a href="${p.url}" target="_blank" rel="noopener noreferrer" class="provider-portal-btn ${p.recommended ? 'featured' : ''}">
              <span>${p.name} ${p.recommended ? '★' : ''}</span>
              <span style="font-size: 0.8rem;">↗</span>
            </a>
          `).join('')}
        </div>
      </div>

      <div style="display: flex; gap: 0.75rem; margin-top: 0.5rem;">
        <button type="button" class="btn-primary" style="flex: 1;" onclick="selectTransportForTrip('${opt.id}'); closeBookingModal();">
          <span>✓ Lock this Transit into My Yatra Plan</span>
        </button>
        <button type="button" class="btn-secondary" onclick="closeBookingModal()">
          Close
        </button>
      </div>
    `;
  }

  modal.classList.add('active');
}

function closeBookingModal() {
  const modal = document.getElementById('bookingModal');
  if (modal) modal.classList.remove('active');
}

function renderItineraryTransportHub() {
  const wrap = document.getElementById('itinTransportHubWrap');
  if (!wrap) return;

  const currentKey = state.trip.destinationKey || 'jaipur';
  const data = TRANSPORT_DATABASE[currentKey] || TRANSPORT_DATABASE.jaipur;

  wrap.innerHTML = `
    <div class="glass-panel" style="padding: 1.75rem;">
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border-subtle); padding-bottom: 1rem;">
        <div>
          <h3 style="font-size: 1.35rem; font-weight: 800;">Available Transport Sources & Booking Hub</h3>
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.25rem;">
            Real flights, trains, Volvo buses, and self-drive routes from ${state.trip.origin || data.origin} to ${state.trip.destination}.
          </p>
        </div>
        <div class="transport-route-badge">
          <span>📍 ${data.distanceKm} km Highway Distance</span>
        </div>
      </div>

      <div class="transport-cards-stack">
        ${getFilteredTransportOptions(state.trip.destinationKey, state.transportFilter.mode, state.transportFilter.maxBudget, state.transportFilter.maxHours, state.transportFilter.priority).options.map(opt => renderSingleTransportCard(opt)).join('')}
      </div>
    </div>
  `;
}

