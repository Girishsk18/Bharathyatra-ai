/**
 * BharatYatra AI - Complete Indian States & Districts Master Database
 * Comprehensive directory for travellers covering all 28 States and 8 Union Territories
 * Includes capitals, zones, transit hubs, languages, and full district lists.
 */

const INDIA_STATES_DATA = [
  {
    id: "andhra-pradesh",
    name: "Andhra Pradesh",
    type: "state",
    capital: "Amaravati",
    zone: "South",
    officialLanguages: ["Telugu"],
    bestSeason: "October to March",
    climate: "Tropical, coastal breeze",
    description: "Famous for the holy Tirupati Balaji shrine, scenic Araku Valley, Buddhist sites, and rich spicy cuisine along the Coromandel coast.",
    transit: {
      airports: ["Visakhapatnam (VTZ)", "Vijayawada (VGA)", "Tirupati (TIR)", "Rajahmundry (RJA)"],
      railwayJunctions: ["Vijayawada Jn (BZA)", "Visakhapatnam (VSKP)", "Tirupati (TPTY)", "Guntur (GNT)"],
      highways: ["NH-16 (Kolkata-Chennai)", "NH-65 (Pune-Machilipatnam)", "NH-40"]
    },
    districtHighlights: {
      "Tirupati": "Sri Venkateswara Temple (Tirumala), Chandragiri Fort",
      "Visakhapatnam": "RK Beach, Submarine Museum, Araku Valley gateway, Kailasagiri",
      "Alluri Sitharama Raju": "Araku Valley, Borra Caves, Lambasingi (Kashmir of AP)",
      "Krishna": "Machilipatnam beaches, Manginapudi beach",
      "NTR": "Vijayawada, Kanaka Durga Temple, Prakasam Barrage",
      "Kurnool": "Belum Caves, Oravakallu Rock Garden, Yaganti Temple",
      "Ananthapuramu": "Lepakshi Temple (Hanging Pillar), Penukonda Fort",
      "Chittoor": "Horsley Hills, Kanipakam Vinayaka Temple",
      "East Godavari": "Rajahmundry, Godavari River Ghats",
      "Konaseema": "Dindi Backwaters, lush coconut island villages",
      "Bapatla": "Suryalanka Beach"
    },
    districts: [
      "Alluri Sitharama Raju", "Anakapalli", "Ananthapuramu", "Annamayya", "Bapatla",
      "Chittoor", "Dr. B.R. Ambedkar Konaseema", "East Godavari", "Eluru", "Guntur",
      "Kakinada", "Krishna", "Kurnool", "Nandyal", "NTR",
      "Palnadu", "Parvathipuram Manyam", "Prakasam", "Sri Potti Sriramulu Nellore", "Sri Sathya Sai",
      "Srikakulam", "Tirupati", "Visakhapatnam", "Vizianagaram", "West Godavari", "YSR Kadapa"
    ]
  },
  {
    id: "arunachal-pradesh",
    name: "Arunachal Pradesh",
    type: "state",
    capital: "Itanagar",
    zone: "North-East",
    officialLanguages: ["English"],
    bestSeason: "October to April",
    climate: "Sub-tropical to alpine high mountain",
    description: "The Land of the Dawn-lit Mountains. Renowned for majestic Himalayan monasteries, snow-covered Sela Pass, and pristine indigenous tribal culture.",
    transit: {
      airports: ["Donyi Polo Airport Itanagar (HGI)", "Pasighat (IXT)", "Tezu (TEI)"],
      railwayJunctions: ["Naharlagun (NHLN) connected to Guwahati & New Delhi"],
      highways: ["NH-13 (Trans-Arunachal Highway)", "NH-15"]
    },
    districtHighlights: {
      "Tawang": "Tawang Monastery (largest in India), Sela Pass, Madhuri Lake",
      "West Kameng": "Bomdila Monastery, Dirang Valley, apple orchards",
      "Lower Subansiri": "Ziro Valley (UNESCO World Heritage landscape, Apatani tribe)",
      "Papum Pare": "Itanagar, Ita Fort, Ganga Lake (Gyakar Sinyi)",
      "East Siang": "Pasighat, Daying Ering Wildlife Sanctuary",
      "Changlang": "Namdapha National Park (Tiger reserve, 4 big cat species)",
      "Lohit": "Parasuram Kund holy pilgrimage site"
    },
    districts: [
      "Anjaw", "Changlang", "Dibang Valley", "East Kameng", "East Siang",
      "Kamle", "Keyi Panyor", "Kra Daadi", "Kurung Kumey", "Lepa Rada",
      "Lohit", "Longding", "Lower Dibang Valley", "Lower Siang", "Lower Subansiri",
      "Namsai", "Pakke Kessang", "Papum Pare", "Shi Yomi", "Siang",
      "Tawang", "Tirap", "Upper Siang", "Upper Subansiri", "West Kameng", "West Siang"
    ]
  },
  {
    id: "assam",
    name: "Assam",
    type: "state",
    capital: "Dispur",
    zone: "North-East",
    officialLanguages: ["Assamese", "Bodo"],
    bestSeason: "November to May",
    climate: "Tropical monsoon with lush green valleys",
    description: "Gateway to the North-East, famed for Assam Tea gardens, the mighty Brahmaputra river, Kamakhya Devi Shaktipeeth, and the one-horned rhinoceros.",
    transit: {
      airports: ["Guwahati Lokpriya Gopinath Bordoloi (GAU)", "Dibrugarh (DIB)", "Silchar (IXS)", "Jorhat (JRH)"],
      railwayJunctions: ["Guwahati (GHY)", "Kamakhya (KYQ)", "Lumding Jn (LMG)", "Dibrugarh (DBRG)"],
      highways: ["NH-27 (East-West corridor)", "NH-15", "NH-37"]
    },
    districtHighlights: {
      "Kamrup Metropolitan": "Guwahati, Kamakhya Temple, Umananda Island, Brahmaputra River Cruise",
      "Golaghat": "Kaziranga National Park (One-horned Rhinos, World Heritage Site)",
      "Majuli": "World's largest inhabited river island, Neo-Vaishnavite Satras",
      "Jorhat": "Tea capital of the world, Gibbon Wildlife Sanctuary",
      "Sivasagar": "Historic Ahom dynasty kingdom, Rang Ghar, Talatal Ghar",
      "Dima Hasao": "Haflong (Assam's only hill station), Jatinga valley",
      "Baksa": "Manas National Park (Tiger, Golden Langur habitat)"
    },
    districts: [
      "Baksa", "Barpeta", "Biswanath", "Bongaigaon", "Cachar",
      "Charaideo", "Chirang", "Darrang", "Dhemaji", "Dhubri",
      "Dibrugarh", "Dima Hasao", "Goalpara", "Golaghat", "Hailakandi",
      "Hojai", "Jorhat", "Kamrup", "Kamrup Metropolitan", "Karbi Anglong",
      "Karimganj", "Kokrajhar", "Lakhimpur", "Majuli", "Morigaon",
      "Nagaon", "Nalbari", "Sivasagar", "Sonitpur", "South Salmara-Mankachar",
      "Tinsukia", "Udalguri", "West Karbi Anglong"
    ]
  },
  {
    id: "bihar",
    name: "Bihar",
    type: "state",
    capital: "Patna",
    zone: "East",
    officialLanguages: ["Hindi", "Urdu"],
    bestSeason: "October to March",
    climate: "Humid sub-tropical, pleasant dry winters",
    description: "Birthplace of Buddhism and Jainism, cradle of ancient empires (Maurya, Gupta), home to Nalanda University and Mahabodhi Temple.",
    transit: {
      airports: ["Jay Prakash Narayan Patna (PAT)", "Gaya International (GAY)", "Darbhanga (DBR)"],
      railwayJunctions: ["Patna Jn (PNBE)", "Gaya Jn (GAYA)", "Samastipur Jn", "Muzaffarpur Jn"],
      highways: ["NH-19 (Grand Trunk Road)", "NH-27", "NH-31"]
    },
    districtHighlights: {
      "Gaya": "Bodh Gaya (Mahabodhi Temple, Bodhi Tree), Vishnupad Temple",
      "Nalanda": "Ruins of ancient Nalanda University, Rajgir ropeway, Vishwa Shanti Stupa",
      "Patna": "Golghar, Patna Sahib Gurudwara (Birthplace of Guru Gobind Singh Ji), Bihar Museum",
      "Vaishali": "Ashoka Pillar, Buddha Stupa, birthplace of Lord Mahavira",
      "Bhagalpur": "Vikramashila University ruins, Gangetic Dolphin Sanctuary",
      "West Champaran": "Valmiki National Park (Tiger Reserve), Gandhi Smarak",
      "Rohtas": "Rohtasgarh Fort, Sasaram (Sher Shah Suri Mausoleum)"
    },
    districts: [
      "Araria", "Arwal", "Aurangabad", "Banka", "Begusarai",
      "Bhagalpur", "Bhojpur", "Buxar", "Darbhanga", "East Champaran",
      "Gaya", "Gopalganj", "Jamui", "Jehanabad", "Kaimur",
      "Katihar", "Khagaria", "Kishanganj", "Lakhisarai", "Madhepura",
      "Madhubani", "Munger", "Muzaffarpur", "Nalanda", "Nawada",
      "Patna", "Purnia", "Rohtas", "Saharsa", "Samastipur",
      "Saran", "Sheikhpura", "Sheohar", "Sitamarhi", "Siwan",
      "Supaul", "Vaishali", "West Champaran"
    ]
  },
  {
    id: "chhattisgarh",
    name: "Chhattisgarh",
    type: "state",
    capital: "Raipur",
    zone: "Central",
    officialLanguages: ["Hindi", "Chhattisgarhi"],
    bestSeason: "October to March",
    climate: "Tropical wet and dry, dense sal forests",
    description: "The herbal and waterfall hub of India. Known for the horse-shoe Chitrakote Falls (Niagara of India), Bastar tribal art, and ancient temples.",
    transit: {
      airports: ["Swami Vivekananda Airport Raipur (RPR)", "Bilaspur (PAB)", "Jagdalpur (JGB)"],
      railwayJunctions: ["Raipur Jn (R)", "Bilaspur Jn (SECR HQ)", "Durg Jn (DURG)"],
      highways: ["NH-30", "NH-53 (Kolkata-Mumbai route)", "NH-130"]
    },
    districtHighlights: {
      "Bastar": "Chitrakote Falls, Tirathgarh Falls, Bastar Dhokra Bell Metal craft",
      "Raipur": "Purkhouti Muktangan, Marine Drive Raipur, Mahant Ghasidas Memorial Museum",
      "Bilaspur": "Ratanpur Mahamaya Temple, Achanakmar Tiger Reserve",
      "Kabirdham": "Bhoramdeo Temple (Khajuraho of Chhattisgarh)",
      "Dantewada": "Maa Danteshwari Temple (52 Shaktipeeths)"
    },
    districts: [
      "Balod", "Baloda Bazar", "Balrampur", "Bastar", "Bemetara",
      "Bijapur", "Bilaspur", "Dantewada", "Dhamtari", "Durg",
      "Gariaband", "Gaurela-Pendra-Marwahi", "Janjgir-Champa", "Jashpur", "Kabirdham",
      "Kanker", "Khairagarh-Chhuikhadan-Gandai", "Kondagaon", "Korba", "Koriya",
      "Mahasamund", "Manendragarh-Chirmiri-Bharatpur", "Mohla-Manpur-Ambagarh Chowki", "Mungeli", "Narayanpur",
      "Raigarh", "Raipur", "Rajnandgaon", "Sakti", "Sarangarh-Bilaigarh",
      "Sukma", "Surajpur", "Surguja"
    ]
  },
  {
    id: "goa",
    name: "Goa",
    type: "state",
    capital: "Panaji",
    zone: "West",
    officialLanguages: ["Konkani"],
    bestSeason: "November to March",
    climate: "Coastal tropical, monsoon rains",
    description: "India's beach paradise, famous for Portuguese colonial churches, UNESCO Basilica of Bom Jesus, susegad lifestyle, spices, and coastal nightlife.",
    transit: {
      airports: ["Goa Dabolim Airport (GOI)", "Manohar International Mopa (GOX)"],
      railwayJunctions: ["Madgaon Jn (MAO)", "Thivim (THVM)", "Karmali (KRMI)"],
      highways: ["NH-66 (Mumbai-Kanyakumari coastal highway)", "NH-748"]
    },
    districtHighlights: {
      "North Goa": "Panaji, Calangute, Baga, Anjuna Flea Market, Aguada Fort, Chapora Fort, Vagator",
      "South Goa": "Colva, Palolem, Agonda, Dudhsagar Falls, Basilica of Bom Jesus, Cabo de Rama"
    },
    districts: [
      "North Goa", "South Goa"
    ]
  },
  {
    id: "gujarat",
    name: "Gujarat",
    type: "state",
    capital: "Gandhinagar",
    zone: "West",
    officialLanguages: ["Gujarati"],
    bestSeason: "October to March",
    climate: "Semi-arid to desert in Kutch, pleasant winters",
    description: "Land of the White Rann, Asiatic Lions, Statue of Unity (world's tallest), sacred Somnath & Dwarka, and rich Gujarati thalis & garba.",
    transit: {
      airports: ["Sardar Vallabhbhai Patel Ahmedabad (AMD)", "Surat (STV)", "Vadodara (BDQ)", "Rajkot (Hirasar)", "Bhuj (BHJ)"],
      railwayJunctions: ["Ahmedabad Jn (ADI)", "Vadodara Jn (BRC)", "Surat (ST)", "Rajkot (RJT)"],
      highways: ["NE-1 (Ahmedabad-Vadodara)", "NH-48 (Delhi-Mumbai)", "NH-27"]
    },
    districtHighlights: {
      "Kutch": "Great Rann of Kutch (White Salt Desert, Rann Utsav), Bhuj, Mandvi Beach Palace",
      "Gir Somnath": "Gir National Park (Sole home of Asiatic Lion), Somnath Jyotirlinga Temple",
      "Devbhumi Dwarka": "Dwarkadhish Temple, Bet Dwarka, Shivrajpur Blue Flag Beach",
      "Narmada": "Statue of Unity (182m, Kevadia), Sardar Sarovar Dam",
      "Ahmedabad": "Sabarmati Ashram, Adalaj Stepwell, UNESCO Heritage Old City",
      "Patan": "Rani ki Vav (Queen's Stepwell - UNESCO), Patola Silk weaving",
      "Junagadh": "Girnar Ropeway & Temples, Uparkot Fort, Mahabat Maqbara"
    },
    districts: [
      "Ahmedabad", "Amreli", "Anand", "Aravalli", "Banaskantha",
      "Bharuch", "Bhavnagar", "Botad", "Chhota Udaipur", "Dahod",
      "Dang", "Devbhumi Dwarka", "Gandhinagar", "Gir Somnath", "Jamnagar",
      "Junagadh", "Kheda", "Kutch", "Mahisagar", "Mehsana",
      "Morbi", "Narmada", "Navsari", "Panchmahal", "Patan",
      "Porbandar", "Rajkot", "Sabarkantha", "Surat", "Surendranagar",
      "Tapi", "Vadodara", "Valsad"
    ]
  },
  {
    id: "haryana",
    name: "Haryana",
    type: "state",
    capital: "Chandigarh",
    zone: "North",
    officialLanguages: ["Hindi"],
    bestSeason: "October to March",
    climate: "Hot summers, cool refreshing winters",
    description: "Land of the Mahabharata and Gita (Kurukshetra), cyber hub Gurugram, Sultanpur Bird Sanctuary, and rich rural heritage.",
    transit: {
      airports: ["Indira Gandhi International Delhi (DEL - adjacent)", "Hisar Airport"],
      railwayJunctions: ["Ambala Cantt (UMB)", "Panipat Jn", "Kalka (toy train gateway)", "Rewari Jn"],
      highways: ["NH-44 (Grand Trunk)", "KMP Expressway", "NH-48"]
    },
    districtHighlights: {
      "Kurukshetra": "Brahma Sarovar, Jyotisar (Geeta preaching site), Krishna Museum",
      "Gurugram": "Cyber City, Kingdom of Dreams, Sultanpur National Park (migratory birds)",
      "Panchkula": "Pinjore Gardens (Yadavindra Gardens), Morni Hills",
      "Faridabad": "Surajkund Crafts Mela, Badkhal Lake",
      "Ambala": "Historic Cloth Market, European Cemetery, military aviation hub"
    },
    districts: [
      "Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad",
      "Gurugram", "Hisar", "Jhajjar", "Jind", "Kaithal",
      "Karnal", "Kurukshetra", "Mahendragarh", "Nuh", "Palwal",
      "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa",
      "Sonipat", "Yamunanagar"
    ]
  },
  {
    id: "himachal-pradesh",
    name: "Himachal Pradesh",
    type: "state",
    capital: "Shimla (Summer) / Dharamshala (Winter)",
    zone: "North",
    officialLanguages: ["Hindi"],
    bestSeason: "March to June (Summer) & Dec to Feb (Snow/Skiing)",
    climate: "Alpine mountain, snowbound passes, fresh pine air",
    description: "Devbhoomi (Land of Gods). Himalayan paradise of snow peaks, cedar forests, Rohtang & Atal Tunnel, Tibetan culture in Dharamshala, and river valleys.",
    transit: {
      airports: ["Kullu-Bhuntar (KUU)", "Kangra-Gaggal (DHM)", "Shimla-Jubbarhatti (SLV)"],
      railwayJunctions: ["Kalka (KLK - UNESCO Heritage Toy Train to Shimla)", "Una Himachal (UHL)"],
      highways: ["NH-3 (Manali-Leh Highway via Atal Tunnel)", "NH-5 (Hindustan-Tibet Road)", "NH-154"]
    },
    districtHighlights: {
      "Kullu": "Manali, Solang Valley, Rohtang Pass, Kasol & Parvati Valley, Great Himalayan National Park",
      "Shimla": "Mall Road, Ridge, Jakhoo Temple, Kufri snow sports, colonial heritage",
      "Kangra": "Dharamshala, McLeod Ganj (Residence of Dalai Lama), Kangra Fort, Bir Billing (Paragliding)",
      "Lahaul and Spiti": "Atal Tunnel, Kaza, Key Monastery, Chandratal Lake, Kunzum Pass",
      "Chamba": "Dalhousie, Khajjiar (Mini Switzerland of India), Chamba town",
      "Mandi": "Prashar Lake, Rewalsar Lake, historic Panchvaktra temple",
      "Kinnaur": "Sangla Valley, Kalpa (Kinner Kailash peak view), Chitkul (last Indian village)"
    },
    districts: [
      "Bilaspur", "Chamba", "Hamirpur", "Kangra", "Kinnaur",
      "Kullu", "Lahaul and Spiti", "Mandi", "Shimla", "Sirmaur",
      "Solan", "Una"
    ]
  },
  {
    id: "jharkhand",
    name: "Jharkhand",
    type: "state",
    capital: "Ranchi",
    zone: "East",
    officialLanguages: ["Hindi"],
    bestSeason: "October to March",
    climate: "Pleasant winters, monsoon plateau waterfalls",
    description: "The Waterfall City of Ranchi, holy Baidyanath Jyotirlinga, Betla National Park, and sacred Parasnath hill (Shikharji Jain pilgrimage).",
    transit: {
      airports: ["Birsa Munda Airport Ranchi (IXR)", "Deoghar Airport (DGH)"],
      railwayJunctions: ["Ranchi (RNC)", "Dhanbad Jn", "Tatanagar/Jamshedpur (TATA)", "Jasidih Jn (Deoghar)"],
      highways: ["NH-19", "NH-20", "NH-33"]
    },
    districtHighlights: {
      "Deoghar": "Baba Baidyanath Jyotirlinga Temple, Trikut Pahar ropeway",
      "Ranchi": "Hundru Falls, Dassam Falls, Jonha Falls, Tagor Hill",
      "Giridih": "Parasnath Hill (Shikharji - sacred Jain Tirthankar nirvana site)",
      "East Singhbhum": "Jamshedpur (Steel City, Jubilee Park, Dalma Wildlife Sanctuary)",
      "Latehar": "Betla National Park (Elephants & Tigers), Lodh Falls"
    },
    districts: [
      "Bokaro", "Chatra", "Deoghar", "Dhanbad", "Dumka",
      "East Singhbhum", "Garhwa", "Giridih", "Godda", "Gumla",
      "Hazaribagh", "Jamtara", "Khunti", "Koderma", "Latehar",
      "Lohardaga", "Pakur", "Palamu", "Ramgarh", "Ranchi",
      "Sahibganj", "Seraikela Kharsawan", "Simdega", "West Singhbhum"
    ]
  },
  {
    id: "karnataka",
    name: "Karnataka",
    type: "state",
    capital: "Bengaluru",
    zone: "South",
    officialLanguages: ["Kannada"],
    bestSeason: "October to March",
    climate: "Moderate temperate plateau to lush tropical Western Ghats",
    description: "One State, Many Worlds. Ancient Vijayanagara ruins of Hampi, coffee hills of Coorg, pristine beaches of Gokarna, and royal Mysuru Palace.",
    transit: {
      airports: ["Kempegowda International Bengaluru (BLR)", "Mangaluru (IXE)", "Hubballi (HBX)", "Belagavi (IXG)"],
      railwayJunctions: ["KSR Bengaluru (SBC)", "Yesvantpur (YPR)", "Mysuru Jn (MYS)", "Hubballi Jn (UBL)"],
      highways: ["NH-48 (Bengaluru-Pune)", "NH-44", "NH-66 (Coastal)", "Bengaluru-Mysuru Expressway"]
    },
    districtHighlights: {
      "Vijayanagara": "Hampi (UNESCO World Heritage, Virupaksha, Stone Chariot, Matanga Hill)",
      "Mysuru": "Mysore Palace (Grand Dasara), Chamundi Hill, Brindavan Gardens",
      "Kodagu": "Coorg (Scotland of India, Abbey Falls, coffee estates, Raja's Seat)",
      "Uttara Kannada": "Gokarna (Om Beach, Mahabaleshwar Temple), Murudeshwar (Giant Shiva Statue)",
      "Chikkamagaluru": "Mullayanagiri peak (Highest in Karnataka), Baba Budangiri, coffee hills",
      "Bengaluru Urban": "Lalbagh Botanical Garden, Bangalore Palace, Vidhana Soudha, tech parks",
      "Hassan": "Belur and Halebidu (UNESCO Hoysala Temple architectures)",
      "Bagalkote": "Badami Cave Temples, Pattadakal, Aihole (cradle of Indian temple architecture)"
    },
    districts: [
      "Bagalkote", "Ballari", "Belagavi", "Bengaluru Rural", "Bengaluru Urban",
      "Bidar", "Chamarajanagara", "Chikkaballapura", "Chikkamagaluru", "Chitradurga",
      "Dakshina Kannada", "Davanagere", "Dharwad", "Gadag", "Hassan",
      "Haveri", "Kalaburagi", "Kodagu", "Kolar", "Koppal",
      "Mandya", "Mysuru", "Raichur", "Ramanagara", "Shivamogga",
      "Tumakuru", "Udupi", "Uttara Kannada", "Vijayanagara", "Vijayapura", "Yadgir"
    ]
  },
  {
    id: "kerala",
    name: "Kerala",
    type: "state",
    capital: "Thiruvananthapuram",
    zone: "South",
    officialLanguages: ["Malayalam"],
    bestSeason: "September to March",
    climate: "Tropical tropical greenery, coastal breezes, soothing monsoon",
    description: "God's Own Country. Serene palm-fringed Alleppey backwaters, mist-shrouded Munnar tea estates, cliff beaches of Varkala, and Ayurvedic rejuvenations.",
    transit: {
      airports: ["Cochin International (COK)", "Trivandrum (TRV)", "Calicut (CCJ)", "Kannur (CNN)"],
      railwayJunctions: ["Ernakulam Jn/Town (ERS/ERN)", "Thiruvananthapuram Central (TVC)", "Kozhikode (CLT)", "Shoranur Jn"],
      highways: ["NH-66 (Coastal Highway)", "NH-544 (Salem-Kochi)", "NH-85 (Munnar corridor)"]
    },
    districtHighlights: {
      "Alappuzha": "Alleppey Houseboat Backwaters, Punnamada Lake, Marari Beach",
      "Idukki": "Munnar (Tea Gardens, Anamudi Peak), Thekkady (Periyar Tiger Reserve)",
      "Ernakulam": "Fort Kochi (Chinese Fishing Nets, colonial streets), Marine Drive, Mattancherry",
      "Thiruvananthapuram": "Padmanabhaswamy Temple (wealthiest shrine), Kovalam Beach, Varkala Cliff",
      "Wayanad": "Banasura Sagar Dam, Chembra Peak, Edakkal Caves, Wayanad Wildlife",
      "Kottayam": "Kumarakom Bird Sanctuary, Vembanad Lake backwaters",
      "Thrissur": "Cultural Capital of Kerala, Thrissur Pooram festival, Vadakkunnathan Temple"
    },
    districts: [
      "Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod",
      "Kollam", "Kottayam", "Kozhikode", "Malappuram", "Palakkad",
      "Pathanamthitta", "Thiruvananthapuram", "Thrissur", "Wayanad"
    ]
  },
  {
    id: "madhya-pradesh",
    name: "Madhya Pradesh",
    type: "state",
    capital: "Bhopal",
    zone: "Central",
    officialLanguages: ["Hindi"],
    bestSeason: "October to March",
    climate: "Sub-tropical continental, crisp clear winters",
    description: "The Heart of Incredible India. Khajuraho erotic temples, Sanchi Buddhist stupas, tiger reserves of Kanha & Bandhavgarh, and Gwalior fort.",
    transit: {
      airports: ["Raja Bhoj Bhopal (BHO)", "Devi Ahilya Bai Holkar Indore (IDR)", "Gwalior (GWL)", "Jabalpur (JLR)", "Khajuraho (HJR)"],
      railwayJunctions: ["Itarsi Jn (ET - biggest junction)", "Bhopal Jn (BPL)", "Indore (INDB)", "Jabalpur (JBP)", "Gwalior (GWL)"],
      highways: ["NH-44 (North-South)", "NH-46", "Delhi-Mumbai Expressway"]
    },
    districtHighlights: {
      "Chhatarpur": "Khajuraho Temples (UNESCO World Heritage erotic sandstone carvings)",
      "Raisen": "Sanchi Stupa (Emperor Ashoka), Bhimbetka Rock Shelters (Paleolithic cave art)",
      "Ujjain": "Mahakaleshwar Jyotirlinga, Kumbh Mela, Ram Ghat on Shipra river",
      "Umaria": "Bandhavgarh National Park (Highest Bengal Tiger density in the world)",
      "Mandla": "Kanha Tiger Reserve (Inspiration for Rudyard Kipling's Jungle Book)",
      "Gwalior": "Gwalior Fort (Pearl of Indian Fortresses), Jai Vilas Palace",
      "Jabalpur": "Bhedaghat Marble Rocks, Dhuandhar Waterfalls on Narmada River",
      "Hoshangabad/Narmadapuram": "Pachmarhi (Queen of Satpura hill station), Bee Falls"
    },
    districts: [
      "Agar Malwa", "Alirajpur", "Anuppur", "Ashoknagar", "Balaghat",
      "Barwani", "Betul", "Bhind", "Bhopal", "Burhanpur",
      "Chhatarpur", "Chhindwara", "Damoh", "Datia", "Dewas",
      "Dhar", "Dindori", "Guna", "Gwalior", "Harda",
      "Indore", "Jabalpur", "Jhabua", "Katni", "Khandwa",
      "Khargone", "Maihar", "Mandla", "Mandsaur", "Mauganj",
      "Morena", "Narmadapuram", "Narsinghpur", "Neemuch", "Niwari",
      "Pandhurna", "Panna", "Raisen", "Rajgarh", "Ratlam",
      "Rewa", "Sagar", "Satna", "Sehore", "Seoni",
      "Shahdol", "Shajapur", "Sheopur", "Shivpuri", "Sidhi",
      "Singrauli", "Tikamgarh", "Ujjain", "Umaria", "Vidisha"
    ]
  },
  {
    id: "maharashtra",
    name: "Maharashtra",
    type: "state",
    capital: "Mumbai",
    zone: "West",
    officialLanguages: ["Marathi"],
    bestSeason: "October to March (Monsoon for Western Ghat treks)",
    climate: "Coastal warm to Deccan plateau dry, lush monsoon waterfalls",
    description: "Land of Chhatrapati Shivaji Maharaj, Bollywood, Gateway of India, ancient Ajanta-Ellora caves, Lonavala hill getaways, and Maharashtrian misal pav.",
    transit: {
      airports: ["Chhatrapati Shivaji Maharaj Mumbai (BOM)", "Pune (PNQ)", "Nagpur (NAG)", "Shirdi (SAG)", "Nashik (ISK)"],
      railwayJunctions: ["CSMT Mumbai", "Pune Jn (PUNE)", "Nagpur Jn (NGP)", "Bhusawal Jn", "Kalyan Jn"],
      highways: ["Mumbai-Pune Expressway", "Samruddhi Mahamarg (Mumbai-Nagpur)", "NH-48", "NH-66"]
    },
    districtHighlights: {
      "Mumbai City": "Gateway of India, Marine Drive, Colaba, Chhatrapati Shivaji Terminus (UNESCO)",
      "Chhatrapati Sambhajinagar": "Ajanta Caves, Ellora Caves (Kailasa Temple), Daulatabad Fort, Bibi ka Maqbara",
      "Pune": "Shaniwar Wada, Aga Khan Palace, Sinhagad Fort, Lonavala/Khandala gateway",
      "Ahmednagar": "Shirdi Sai Baba Temple, Shani Shingnapur",
      "Nashik": "Trimbakeshwar Jyotirlinga, Sula Vineyards (Wine capital of India), Panchavati",
      "Satara": "Mahabaleshwar (Strawberries, Arthur's Seat), Panchgani, Kaas Plateau (Valley of Flowers)",
      "Raigad": "Raigad Fort (Capital of Chhatrapati Shivaji Maharaj), Alibaug beaches",
      "Sindhudurg": "Tarkarli scuba diving, Sindhudurg sea fort, Malvan seafood"
    },
    districts: [
      "Ahilyanagar", "Akola", "Amravati", "Beed", "Bhandara",
      "Buldhana", "Chandrapur", "Chhatrapati Sambhajinagar", "Dhule", "Gadchiroli",
      "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kolhapur",
      "Latur", "Mumbai City", "Mumbai Suburban", "Nagpur", "Nanded",
      "Nandurbar", "Nashik", "Dharashiv", "Palghar", "Parbhani",
      "Pune", "Raigad", "Ratnagiri", "Sangli", "Satara",
      "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal"
    ]
  },
  {
    id: "manipur",
    name: "Manipur",
    type: "state",
    capital: "Imphal",
    zone: "North-East",
    officialLanguages: ["Meitei (Manipuri)"],
    bestSeason: "October to April",
    climate: "Sub-tropical alpine, temperate hills",
    description: "The Jeweled Land of India. Home to Loktak Lake with floating phumdis, the Keibul Lamjao (only floating national park in the world), and classical Raas Leela.",
    transit: {
      airports: ["Bir Tikendrajit International Airport Imphal (IMF)"],
      railwayJunctions: ["Jiribam (JRM), railway line to Imphal under development"],
      highways: ["NH-2 (connecting Kohima & Imphal)", "NH-37"]
    },
    districtHighlights: {
      "Bishnupur": "Loktak Lake (Floating Phumdis), Keibul Lamjao National Park (Sangai Dancing Deer)",
      "Imphal West": "Kangla Fort, Ima Keithel (Mother's Market - world's only all-women market)",
      "Ukhrul": "Shirui Hills (Home to rare Shirui Lily), Khangkhui lime caves",
      "Churachandpur": "Khuga Dam, tribal handicrafts"
    },
    districts: [
      "Bishnupur", "Chandel", "Churachandpur", "Imphal East", "Imphal West",
      "Jiribam", "Kakching", "Kamjong", "Kangpokpi", "Noney",
      "Pherzawl", "Senapati", "Tamenglong", "Tengnoupal", "Thoubal", "Ukhrul"
    ]
  },
  {
    id: "meghalaya",
    name: "Meghalaya",
    type: "state",
    capital: "Shillong",
    zone: "North-East",
    officialLanguages: ["English"],
    bestSeason: "October to May",
    climate: "Wettest place on Earth, crisp mountain mist",
    description: "The Abode of Clouds. Renowned for UNESCO bio-engineered Living Root Bridges, crystal clear Umngot River in Dawki, and roaring waterfalls.",
    transit: {
      airports: ["Shillong Airport Umroi (SHL)", "Guwahati Airport (GAU - 100km away)"],
      railwayJunctions: ["Guwahati Jn (GHY - nearest major station)"],
      highways: ["NH-6 (Guwahati-Shillong-Silchar)", "NH-106"]
    },
    districtHighlights: {
      "East Khasi Hills": "Shillong (Scotland of the East), Cherrapunji/Sohra, Nohkalikai Falls, Double Decker Root Bridge",
      "West Jaintia Hills": "Dawki (Umngot River transparent waters, India-Bangladesh border), Krang Suri Falls",
      "East Jaintia Hills": "Krem Liat Prah (longest natural cave system in India)",
      "Ri Bhoi": "Umiam Lake (Barapani water sports, boating)",
      "East Garo Hills": "Nokrek Biosphere Reserve (Red Panda habitat)"
    },
    districts: [
      "East Garo Hills", "East Jaintia Hills", "East Khasi Hills", "Eastern West Khasi Hills", "North Garo Hills",
      "Ri Bhoi", "South Garo Hills", "South West Garo Hills", "South West Khasi Hills", "West Garo Hills",
      "West Jaintia Hills", "West Khasi Hills"
    ]
  },
  {
    id: "mizoram",
    name: "Mizoram",
    type: "state",
    capital: "Aizawl",
    zone: "North-East",
    officialLanguages: ["Mizo", "English"],
    bestSeason: "October to April",
    climate: "Mild temperate mountain climate",
    description: "Land of Rolling Hills and Bamboo Groves. Known for high literacy, vibrant festivals like Chapchar Kut, Vantawng Falls, and pristine mountain trails.",
    transit: {
      airports: ["Lengpui Airport Aizawl (AJL)"],
      railwayJunctions: ["Bairabi (BHRB), connecting to Silchar"],
      highways: ["NH-2", "NH-306 (connects to Silchar, Assam)"]
    },
    districtHighlights: {
      "Aizawl": "Solomon's Temple, Durtlang Hills viewpoint, Bara Bazar, State Museum",
      "Serchhip": "Vantawng Falls (highest in Mizoram), Thenzawl handloom village",
      "Champhai": "Rih Dil lake gateway (sacred Mizo folklore), scenic border vineyard hills",
      "Mamit": "Dampa Tiger Reserve (dense tropical rainforest)"
    },
    districts: [
      "Aizawl", "Champhai", "Hnahthial", "Khawzawl", "Kolasib",
      "Lawngtlai", "Lunglei", "Mamit", "Saitual", "Serchhip", "Siaha"
    ]
  },
  {
    id: "nagaland",
    name: "Nagaland",
    type: "state",
    capital: "Kohima",
    zone: "North-East",
    officialLanguages: ["English"],
    bestSeason: "October to May (Hornbill Festival: Dec 1-10)",
    climate: "Cool temperate mountain climate",
    description: "Land of Festivals. World-famous Hornbill Festival, historic Kohima War Cemetery, pristine Dzukou Valley of Flowers, and rich tribal heritage.",
    transit: {
      airports: ["Dimapur Airport (DMU)"],
      railwayJunctions: ["Dimapur Railway Station (DMV)"],
      highways: ["NH-2", "NH-29 (Dimapur-Kohima)"]
    },
    districtHighlights: {
      "Kohima": "Kohima War Cemetery (WWII battle), Kisama Heritage Village (Hornbill Festival venue)",
      "Phek": "Dzukou Valley (Valley of Flowers on Manipur-Nagaland border), Glory Peak",
      "Mon": "Konyak Naga tattooed warrior tribe headquarter, Longwa village (half in India, half in Myanmar)",
      "Mokokchung": "Cultural hub of Ao Nagas, Ungma oldest village",
      "Dimapur": "Kachari ruins, Triple Falls, vibrant entry hub"
    },
    districts: [
      "Chümoukedima", "Dimapur", "Kiphire", "Kohima", "Longleng",
      "Mokokchung", "Mon", "Niuland", "Noklak", "Peren",
      "Phek", "Shamator", "Tseminyü", "Tuensang", "Wokha", "Zünheboto"
    ]
  },
  {
    id: "odisha",
    name: "Odisha",
    type: "state",
    capital: "Bhubaneswar",
    zone: "East",
    officialLanguages: ["Odia"],
    bestSeason: "October to March",
    climate: "Coastal tropical with cool winter breezes",
    description: "The Soul of Incredible India. Konark Sun Temple (UNESCO), holy Jagannath Temple in Puri, Chilika Lake (Irrawaddy dolphins), and Odissi classical dance.",
    transit: {
      airports: ["Biju Patnaik Airport Bhubaneswar (BBI)", "Jharsuguda Veer Surendra Sai (JRG)"],
      railwayJunctions: ["Bhubaneswar (BBS)", "Puri (PURI)", "Cuttack (CTC)", "Khurda Road (KUR)"],
      highways: ["NH-16 (Kolkata-Chennai)", "NH-53", "NH-57"]
    },
    districtHighlights: {
      "Puri": "Jagannath Temple (Rath Yatra), Golden Beach (Blue Flag certified), Konark Sun Temple",
      "Khordha": "Bhubaneswar (Temple City - Lingaraj Temple, Mukteshvara), Udayagiri & Khandagiri caves",
      "Ganjam": "Chilika Lake (Asia's largest brackish lagoon, migratory birds, Irrawaddy dolphins), Gopalpur-on-Sea",
      "Mayurbhanj": "Simlipal National Park (Tiger reserve, waterfalls, lush sal forest)",
      "Kendrapara": "Bhitarkanika National Park (Saltwater crocodiles, mangrove boat safari)"
    },
    districts: [
      "Angul", "Balangir", "Balasore", "Bargarh", "Bhadrak",
      "Boudh", "Cuttack", "Deogarh", "Dhenkanal", "Gajapati",
      "Ganjam", "Jagatsinghpur", "Jajpur", "Jharsuguda", "Kalahandi",
      "Kandhamal", "Kendrapara", "Kendujhar", "Khordha", "Koraput",
      "Malkangiri", "Mayurbhanj", "Nabarangpur", "Nayagarh", "Nuapada",
      "Puri", "Rayagada", "Sambalpur", "Subarnapur", "Sundargarh"
    ]
  },
  {
    id: "punjab",
    name: "Punjab",
    type: "state",
    capital: "Chandigarh",
    zone: "North",
    officialLanguages: ["Punjabi"],
    bestSeason: "October to March",
    climate: "Continental, golden mustard fields in winter",
    description: "Land of the Five Rivers and Golden Temple (Harmandir Sahib). Renowned for heart-warming Punjabi hospitality, Wagah border ceremony, and rich dhabas.",
    transit: {
      airports: ["Sri Guru Ram Dass Jee Amritsar (ATQ)", "Chandigarh (IXC)"],
      railwayJunctions: ["Amritsar Jn (ASR)", "Ludhiana Jn (LDH)", "Jalandhar City (JUC)", "Bathinda Jn (BTI)"],
      highways: ["NH-44 (Grand Trunk Road)", "NH-5", "Delhi-Amritsar Expressway"]
    },
    districtHighlights: {
      "Amritsar": "Golden Temple (Sri Harmandir Sahib), Jallianwala Bagh, Attari-Wagah Border Retreat, Gobindgarh Fort",
      "Bathinda": "Qila Mubarak (ancient brick fort where Razia Sultan was imprisoned)",
      "Patiala": "Qila Mubarak, Sheesh Mahal, royal Patiala peg & paranda culture",
      "Rupnagar": "Anandpur Sahib (Birthplace of the Khalsa, Virasat-e-Khalsa museum, Hola Mohalla festival)"
    },
    districts: [
      "Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib",
      "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar",
      "Kapurthala", "Ludhiana", "Malerkotla", "Mansa", "Moga",
      "Muktsar", "Pathankot", "Patiala", "Rupnagar", "Sahibzada Ajit Singh Nagar",
      "Sangrur", "Shahid Bhagat Singh Nagar", "Tarn Taran"
    ]
  },
  {
    id: "rajasthan",
    name: "Rajasthan",
    type: "state",
    capital: "Jaipur",
    zone: "West",
    officialLanguages: ["Hindi", "Rajasthani"],
    bestSeason: "October to March",
    climate: "Desert arid to semi-arid, pleasant winter sunshine",
    description: "Land of Kings and Palaces. Iconic pink city of Jaipur, romantic lakes of Udaipur, golden sands of Jaisalmer, blue houses of Jodhpur, and tiger safaris.",
    transit: {
      airports: ["Jaipur International (JAI)", "Udaipur Maharana Pratap (UDR)", "Jodhpur (JDH)", "Jaisalmer (JSA)", "Bikaner (BKB)"],
      railwayJunctions: ["Jaipur Jn (JP)", "Jodhpur Jn (JU)", "Ajmer Jn (AII)", "Bikaner Jn", "Kota Jn (KOTA)"],
      highways: ["Delhi-Mumbai Expressway", "NH-48", "NH-62", "NH-11"]
    },
    districtHighlights: {
      "Jaipur": "Hawa Mahal, Amer Fort, City Palace, Jantar Mantar (UNESCO), Nahargarh sunset",
      "Udaipur": "Lake Pichola, City Palace Udaipur, Jag Mandir, Sajjangarh Monsoon Palace",
      "Jodhpur": "Mehrangarh Fort, Umaid Bhawan Palace, Jaswant Thada, Blue City alleyways",
      "Jaisalmer": "Golden Fort (Living Fort), Sam Sand Dunes (Camel safari), Patwon ki Haveli",
      "Sawai Madhopur": "Ranthambore National Park (Iconic Bengal Tiger Safaris & ancient fort)",
      "Ajmer": "Ajmer Sharif Dargah, Ana Sagar Lake, Pushkar (Brahma Temple & Camel Fair)",
      "Chittorgarh": "Chittorgarh Fort (India's largest fort, Vijay Stambh, Padmini Palace)",
      "Sirohi": "Mount Abu (Rajasthan's only hill station, Dilwara Jain Temples, Nakki Lake)",
      "Bikaner": "Junagarh Fort, Karni Mata Rat Temple (Deshnoke), Camel research farm"
    },
    districts: [
      "Ajmer", "Alwar", "Anupgarh", "Balotra", "Banswara",
      "Baran", "Barmer", "Beawar", "Bharatpur", "Bhilwara",
      "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa",
      "Deeg", "Dholpur", "Didwana-Kuchaman", "Dudu", "Dungarpur",
      "Ganganagar", "Gangapur City", "Hanumangarh", "Jaipur", "Jaipur Rural",
      "Jaisalmer", "Jalore", "Jhalawar", "Jhunjhunu", "Jodhpur",
      "Jodhpur Rural", "Karauli", "Kekri", "Khairthal-Tijara", "Kota",
      "Kotputli-Behror", "Nagaur", "Neem Ka Thana", "Pali", "Phalodi",
      "Pratapgarh", "Rajsamand", "Salumbar", "Sanchore", "Sawai Madhopur",
      "Shahpura", "Sikar", "Sirohi", "Tonk", "Udaipur"
    ]
  },
  {
    id: "sikkim",
    name: "Sikkim",
    type: "state",
    capital: "Gangtok",
    zone: "North-East",
    officialLanguages: ["Nepali", "Sikkimese", "English"],
    bestSeason: "March to May & October to mid-December",
    climate: "Alpine mountain, snow valleys, rhododendron blooms",
    description: "Land of Mt. Kanchenjunga (World's 3rd highest peak). India's 100% organic state, famed for Tsomgo Lake, Nathula Pass, Yumthang Valley, and monasteries.",
    transit: {
      airports: ["Pakyong Airport (PYG)", "Bagdogra Airport (IXB - 120km away in West Bengal)"],
      railwayJunctions: ["New Jalpaiguri Jn (NJP - nearest railhead, Sivok-Rangpo railway in progress)"],
      highways: ["NH-10 (Siliguri-Gangtok lifeline)"]
    },
    districtHighlights: {
      "Gangtok": "MG Marg, Rumtek Monastery, Tsomgo Lake (Changu Lake), Nathula Pass (Indo-China border), Baba Mandir",
      "Mangan": "Yumthang Valley (Valley of Flowers), Gurudongmar Lake (17,800 ft), Zero Point",
      "Gyalshing": "Pelling (Skywalk, Kanchenjunga view), Pemayangtse Monastery, Rabdentse Ruins",
      "Namchi": "Char Dham (Siddhesvara Dhaam), Samdruptse Hill (Giant Guru Padmasambhava Statue)"
    },
    districts: [
      "Gangtok", "Gyalshing", "Mangan", "Namchi", "Pakyong", "Soreng"
    ]
  },
  {
    id: "tamil-nadu",
    name: "Tamil Nadu",
    type: "state",
    capital: "Chennai",
    zone: "South",
    officialLanguages: ["Tamil"],
    bestSeason: "November to March",
    climate: "Tropical coastal, pleasant winter",
    description: "Land of Grand Dravidian Temples. UNESCO Chola temples, Meenakshi Amman in Madurai, French colonial Pondicherry border, and Queen of Hill Stations Ooty.",
    transit: {
      airports: ["Chennai International (MAA)", "Coimbatore (CJB)", "Madurai (IXM)", "Tiruchirappalli (TRZ)", "Salem (SXV)"],
      railwayJunctions: ["Chennai Central (MAS)", "Chennai Egmore (MS)", "Coimbatore Jn (CBE)", "Madurai Jn (MDU)", "Tiruchirappalli Jn (TPJ)"],
      highways: ["NH-44", "NH-48", "East Coast Road (ECR)", "NH-32"]
    },
    districtHighlights: {
      "Madurai": "Meenakshi Amman Temple (Towering Gopurams, Hall of Thousand Pillars)",
      "Nilgiris": "Ooty (Udhagamandalam), Nilgiri Mountain Railway (Toy Train UNESCO), Doddabetta Peak, Coonoor",
      "Chengalpattu": "Mahabalipuram (Shore Temple, Pancha Rathas, Arjuna's Penance UNESCO)",
      "Thanjavur": "Brihadeeswarar Temple (Big Temple - Great Living Chola Temple), Thanjavur paintings",
      "Ramanathapuram": "Rameswaram (Ramanathaswamy Temple, 22 Theerthams), Pamban Bridge, Dhanushkodi ghost town",
      "Kanyakumari": "Vivekananda Rock Memorial, Thiruvalluvar Statue, Triveni Sangam sunset/sunrise",
      "Dindigul": "Kodaikanal (Princess of Hill Stations, Kodai Lake, Pillar Rocks, Coaker's Walk)",
      "Chennai": "Marina Beach (second longest urban beach), Fort St. George, Kapaleeshwarar Temple"
    },
    districts: [
      "Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore",
      "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram",
      "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai",
      "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai",
      "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi",
      "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli",
      "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur",
      "Vellore", "Viluppuram", "Virudhunagar"
    ]
  },
  {
    id: "telangana",
    name: "Telangana",
    type: "state",
    capital: "Hyderabad",
    zone: "South",
    officialLanguages: ["Telugu", "Urdu"],
    bestSeason: "October to March",
    climate: "Semi-arid Deccan plateau, dry pleasant winters",
    description: "The Pearl City and Silicon Hub. Renowned for Charminar, Golconda Fort, Ramappa Temple (UNESCO), Hyderabadi Biryani, and grand Falaknuma Palace.",
    transit: {
      airports: ["Rajiv Gandhi International Hyderabad (HYD)"],
      railwayJunctions: ["Secunderabad Jn (SC)", "Hyderabad Deccan (HYB)", "Kacheguda (KCG)", "Kazipet Jn"],
      highways: ["NH-44", "NH-65", "Hyderabad Outer Ring Road (ORR)"]
    },
    districtHighlights: {
      "Hyderabad": "Charminar, Golconda Fort, Salar Jung Museum, Chowmahalla Palace, Hussain Sagar Lake",
      "Mulugu": "Ramappa Temple (UNESCO World Heritage Kakatiya architecture), Laknavaram Lake",
      "Hanumakonda": "Thousand Pillar Temple, Warangal Fort gateway",
      "Yadadri Bhuvanagiri": "Yadadri Lakshmi Narasimha Temple, Bhongir Fort rock dome",
      "Nagar Kurnool": "Nallamala Forest, Srisailam Dam gateway, Amrabad Tiger Reserve"
    },
    districts: [
      "Adilabad", "Bhadradri Kothagudem", "Hanumakonda", "Hyderabad", "Jagtial",
      "Jangaon", "Jayashankar Bhupalpally", "Jogulamba Gadwal", "Kamareddy", "Karimnagar",
      "Khammam", "Kumuram Bheem Asifabad", "Mahabubabad", "Mahabubnagar", "Mancherial",
      "Medak", "Medchal-Malkajgiri", "Mulugu", "Nagarkurnool", "Nalgonda",
      "Narayanpet", "Nirmal", "Nizamabad", "Peddapalli", "Rajanna Sircilla",
      "Ranga Reddy", "Sangareddy", "Siddipet", "Suryapet", "Vikarabad",
      "Wanaparthy", "Warangal", "Yadadri Bhuvanagiri"
    ]
  },
  {
    id: "tripura",
    name: "Tripura",
    type: "state",
    capital: "Agartala",
    zone: "North-East",
    officialLanguages: ["Bengali", "Kokborok", "English"],
    bestSeason: "October to March",
    climate: "Humid tropical, mild winter",
    description: "Land of Ujjayanta Palace and Neermahal Water Palace. Famed for ancient rock carvings at Unakoti, bamboo crafts, and lush green border hills.",
    transit: {
      airports: ["Maharaja Bir Bikram Airport Agartala (IXA)"],
      railwayJunctions: ["Agartala (AGTL - connected to Guwahati & Kolkata via Rajdhani)"],
      highways: ["NH-8 (Assam-Agartala Road)"]
    },
    districtHighlights: {
      "West Tripura": "Ujjayanta Palace, Heritage Park Agartala, Akhaura ICP (Indo-Bangladesh Border)",
      "Sepahijala": "Neermahal (Only water palace in Eastern India in Rudrasagar Lake), Clouded Leopard National Park",
      "Unakoti": "Unakoti Rock-Cut Carvings (Colossal Shiva heads carved in hillside, Angkor Wat of the North-East)",
      "Gomati": "Tripura Sundari Temple (51 Shaktipeeths, Udaipur)"
    },
    districts: [
      "Dhalai", "Gomati", "Khowai", "North Tripura", "Sepahijala",
      "South Tripura", "Unakoti", "West Tripura"
    ]
  },
  {
    id: "uttar-pradesh",
    name: "Uttar Pradesh",
    type: "state",
    capital: "Lucknow",
    zone: "North",
    officialLanguages: ["Hindi", "Urdu"],
    bestSeason: "October to March",
    climate: "Warm summers, crisp chilly winters",
    description: "Heartland of India. Taj Mahal in Agra, oldest living city Varanasi with Ganga Aarti, sacred Ram Janmabhoomi Ayodhya, Mathura-Vrindavan, and Awadhi Nawabi cuisine.",
    transit: {
      airports: ["Chaudhary Charan Singh Lucknow (LKO)", "Lal Bahadur Shastri Varanasi (VNS)", "Maharishi Valmiki Ayodhya (AYJ)", "Noida Jewar (Upcoming)"],
      railwayJunctions: ["Varanasi Jn/Banaras", "Lucknow Charbagh (LKO)", "Kanpur Central (CNB)", "Prayagraj Jn (PRYJ)", "Agra Cantt (AGC)", "Mathura Jn"],
      highways: ["Yamuna Expressway", "Agra-Lucknow Expressway", "Purvanchal Expressway", "Bundelkhand Expressway", "NH-19"]
    },
    districtHighlights: {
      "Agra": "Taj Mahal (Wonder of the World), Agra Fort, Fatehpur Sikri (UNESCO), Mehtab Bagh",
      "Varanasi": "Kashi Vishwanath Temple, Dashashwamedh Ghat Ganga Aarti, Sarnath (First sermon of Buddha), Assi Ghat",
      "Ayodhya": "Shri Ram Janmabhoomi Mandir, Hanumangarhi, Saryu River Ghats",
      "Lucknow": "Bara Imambara (Bhool Bhulaiya), Chota Imambara, Rumi Darwaza, Tunday Kababi Nawabi food",
      "Mathura": "Krishna Janmasthan, Vrindavan (Prem Mandir, Banke Bihari, ISKCON)",
      "Prayagraj": "Triveni Sangam (Kumbh Mela), Allahabad Fort, Anand Bhavan",
      "Jhansi": "Jhansi Fort (Rani Laxmibai), Government Museum",
      "Kushinagar": "Mahaparinirvana Temple of Lord Buddha, Ramabhar Stupa"
    },
    districts: [
      "Agra", "Aligarh", "Ambedkar Nagar", "Amethi", "Amroha",
      "Auraiya", "Ayodhya", "Azamgarh", "Baghpat", "Bahraich",
      "Ballia", "Balrampur", "Banda", "Barabanki", "Bareilly",
      "Basti", "Bhadohi", "Bijnor", "Budaun", "Bulandshahr",
      "Chandauli", "Chitrakoot", "Deoria", "Etah", "Etawah",
      "Farrukhabad", "Fatehpur", "Firozabad", "Gautam Buddha Nagar", "Ghaziabad",
      "Ghazipur", "Gonda", "Gorakhpur", "Hamirpur", "Hapur",
      "Hardoi", "Hathras", "Jalaun", "Jaunpur", "Jhansi",
      "Kannauj", "Kanpur Dehat", "Kanpur Nagar", "Kasganj", "Kaushambi",
      "Kheri", "Kushinagar", "Lalitpur", "Lucknow", "Maharajganj",
      "Mahoba", "Mainpuri", "Mathura", "Mau", "Meerut",
      "Mirzapur", "Moradabad", "Muzaffarnagar", "Pilibhit", "Pratapgarh",
      "Prayagraj", "Raebareli", "Rampur", "Saharanpur", "Sambhal",
      "Sant Kabir Nagar", "Shahjahanpur", "Shamli", "Shravasti", "Siddharthnagar",
      "Sitapur", "Sonbhadra", "Sultanpur", "Unnao", "Varanasi"
    ]
  },
  {
    id: "uttarakhand",
    name: "Uttarakhand",
    type: "state",
    capital: "Dehradun (Winter) / Gairsain (Summer)",
    zone: "North",
    officialLanguages: ["Hindi", "Sanskrit"],
    bestSeason: "March to June & September to November (Snow: Dec-Feb)",
    climate: "Alpine mountain, pine forests, holy river valleys",
    description: "Land of Gods (Devbhoomi). The Char Dham (Badrinath, Kedarnath, Gangotri, Yamunotri), Yoga Capital Rishikesh, Ganga Aarti in Haridwar, Nainital, and Jim Corbett.",
    transit: {
      airports: ["Jolly Grant Dehradun (DED)", "Pantnagar (PGH)"],
      railwayJunctions: ["Haridwar (HW)", "Dehradun (DDN)", "Kathgodam (KGM - Nainital gateway)", "Rishikesh (YNRK)"],
      highways: ["NH-7 (Char Dham highway)", "NH-34", "Delhi-Dehradun Expressway"]
    },
    districtHighlights: {
      "Rudraprayag": "Kedarnath Temple (One of 12 Jyotirlingas, Himalayan trek), Chopta-Tungnath (Highest Shiva temple)",
      "Chamoli": "Badrinath Temple, Valley of Flowers (UNESCO), Auli (Skiing resort), Hemkund Sahib",
      "Haridwar": "Har Ki Pauri Ganga Aarti, Mansa Devi ropeway, Kumbh Mela",
      "Dehradun": "Rishikesh (Yoga capital, Laxman Jhula, River rafting), Robber's Cave, Sahastradhara, Mussoorie hill station",
      "Nainital": "Naini Lake, Mall Road, Naina Devi Temple, Jim Corbett National Park (Ramnagar gateway)",
      "Almora": "Binsar Wildlife Sanctuary, Kasar Devi (Crank's Ridge), Jageshwar Dham temples",
      "Uttarkashi": "Gangotri & Yamunotri temples, Gaumukh glacier trek, Dayara Bugyal"
    },
    districts: [
      "Almora", "Bageshwar", "Chamoli", "Champawat", "Dehradun",
      "Haridwar", "Nainital", "Pauri Garhwal", "Pithoragarh", "Rudraprayag",
      "Tehri Garhwal", "Udham Singh Nagar", "Uttarkashi"
    ]
  },
  {
    id: "west-bengal",
    name: "West Bengal",
    type: "state",
    capital: "Kolkata",
    zone: "East",
    officialLanguages: ["Bengali", "English"],
    bestSeason: "October to March",
    climate: "Tropical delta to snow-peaked Himalayan ridges",
    description: "Cultural Capital of India. Victoria Memorial, Howrah Bridge, Durga Puja grandeur, toy train in Darjeeling hills, and Royal Bengal Tigers of Sundarbans.",
    transit: {
      airports: ["Netaji Subhash Chandra Bose Kolkata (CCU)", "Bagdogra (IXB)", "Kazi Nazrul Islam Durgapur (RDP)"],
      railwayJunctions: ["Howrah Jn (HWH)", "Sealdah (SDAH)", "Kolkata (KOAA)", "New Jalpaiguri (NJP)"],
      highways: ["NH-19 (Delhi-Kolkata)", "NH-16 (Kolkata-Chennai)", "NH-12"]
    },
    districtHighlights: {
      "Kolkata": "Victoria Memorial, Howrah Bridge, Dakshineswar Kali Temple, Park Street, Indian Museum",
      "Darjeeling": "Tiger Hill sunrise over Mt. Kanchenjunga, Darjeeling Himalayan Railway (Toy Train), tea estates",
      "South 24 Parganas": "Sundarbans National Park (World's largest mangrove delta, Royal Bengal Tigers UNESCO)",
      "Kalimpong": "Deolo Hill, cactus nurseries, panoramic Himalayan viewpoints",
      "Birbhum": "Shantiniketan (Rabindranath Tagore's Visva-Bharati University UNESCO)",
      "Purba Medinipur": "Digha Beach, Mandarmani red crab beach, Shankarpur"
    },
    districts: [
      "Alipurduar", "Bankura", "Birbhum", "Cooch Behar", "Dakshin Dinajpur",
      "Darjeeling", "Hooghly", "Howrah", "Jalpaiguri", "Jhargram",
      "Kalimpong", "Kolkata", "Malda", "Murshidabad", "Nadia",
      "North 24 Parganas", "Paschim Bardhaman", "Paschim Medinipur", "Purba Bardhaman", "Purba Medinipur",
      "Purulia", "South 24 Parganas", "Uttar Dinajpur"
    ]
  },

  // -------------------------------------------------------------
  // 8 UNION TERRITORIES OF INDIA
  // -------------------------------------------------------------
  {
    id: "andaman-nicobar",
    name: "Andaman and Nicobar Islands",
    type: "ut",
    capital: "Port Blair",
    zone: "South",
    officialLanguages: ["Hindi", "English"],
    bestSeason: "October to May",
    climate: "Equatorial tropical, azure waters, sea breeze",
    description: "Emerald islands surrounded by turquoise coral reefs. Historic Cellular Jail, Radhanagar Beach (Asia's cleanest), water sports & scuba diving.",
    transit: {
      airports: ["Veer Savarkar International Airport Port Blair (IXZ)"],
      railwayJunctions: ["None (Accessible via regular flights and passenger ships from Chennai/Kolkata)"],
      highways: ["Andaman Trunk Road (NH-4)"]
    },
    districtHighlights: {
      "South Andaman": "Port Blair (Cellular Jail, Ross Island/Netaji Subhash Chandra Bose Island), Havelock (Swaraj Dweep - Radhanagar Beach), Neil Island (Shaheed Dweep)",
      "North and Middle Andaman": "Baratang Island (Mud Volcano & Limestone Caves), Diglipur (Ross & Smith Twin Islands)",
      "Nicobar": "Great Nicobar Biosphere Reserve, Indira Point (India's southernmost tip)"
    },
    districts: [
      "Nicobar", "North and Middle Andaman", "South Andaman"
    ]
  },
  {
    id: "chandigarh",
    name: "Chandigarh",
    type: "ut",
    capital: "Chandigarh",
    zone: "North",
    officialLanguages: ["English", "Hindi", "Punjabi"],
    bestSeason: "October to March",
    climate: "Continental, pleasant planned green parks",
    description: "The City Beautiful. India's first planned city designed by Le Corbusier, famous for Nek Chand's Rock Garden, Sukhna Lake, and Rose Garden.",
    transit: {
      airports: ["Shaheed Bhagat Singh International Airport Chandigarh (IXC)"],
      railwayJunctions: ["Chandigarh Jn (CDG)"],
      highways: ["NH-5", "Himalayan Expressway"]
    },
    districtHighlights: {
      "Chandigarh": "Nek Chand Rock Garden, Sukhna Lake boating, Zakir Hussain Rose Garden, Capitol Complex (UNESCO)"
    },
    districts: [
      "Chandigarh"
    ]
  },
  {
    id: "dadra-nagar-haveli-daman-diu",
    name: "Dadra and Nagar Haveli and Daman and Diu",
    type: "ut",
    capital: "Daman",
    zone: "West",
    officialLanguages: ["Gujarati", "Hindi", "English"],
    bestSeason: "October to March",
    climate: "Coastal breeze, sunny beach days",
    description: "Former Portuguese colonies featuring historic seafront ramparts, Diu Fort, peaceful Nagoa Beach, church architecture, and Silvassa tribal greenery.",
    transit: {
      airports: ["Diu Airport (DIU)", "Daman Airport", "Surat Airport (nearby)"],
      railwayJunctions: ["Vapi (VAPI - 12 km from Daman)", "Veraval (nearest for Diu)"],
      highways: ["NH-848A", "NH-48 corridor"]
    },
    districtHighlights: {
      "Diu": "Diu Fort, Nagoa Beach, St. Paul's Church, Naida Caves, Gangeshwar Mahadev Temple",
      "Daman": "Moti Daman Fort, Nani Daman, Jampore Beach, Devka Beach",
      "Dadra and Nagar Haveli": "Silvassa, Dudhni Lake water sports, Lion Safari Vasona, tribal culture"
    },
    districts: [
      "Dadra and Nagar Haveli", "Daman", "Diu"
    ]
  },
  {
    id: "delhi",
    name: "Delhi (NCT)",
    type: "ut",
    capital: "New Delhi",
    zone: "North",
    officialLanguages: ["Hindi", "English"],
    bestSeason: "October to March",
    climate: "Sub-tropical continental, pleasant winter sunshine",
    description: "Heart of India & National Capital. Magnificent Mughal monuments, British colonial boulevards, street food in Chandni Chowk, and world-class metro.",
    transit: {
      airports: ["Indira Gandhi International Airport (DEL) - Terminal 1, 2 & 3"],
      railwayJunctions: ["New Delhi (NDLS)", "Old Delhi (DLI)", "Hazrat Nizamuddin (NZM)", "Anand Vihar (ANVT)"],
      highways: ["Delhi-Mumbai Expressway", "Yamuna Expressway", "NH-44", "Western & Eastern Peripheral"]
    },
    districtHighlights: {
      "Central Delhi": "India Gate, Connaught Place, Rashtrapati Bhavan, Jantar Mantar",
      "North Delhi": "Red Fort, Chandni Chowk, Jama Masjid, Paranthe Wali Gali",
      "South Delhi": "Qutub Minar (UNESCO), Lotus Temple, Hauz Khas Village, Mehrauli Archaeological Park",
      "South East Delhi": "Humayun's Tomb (UNESCO), Nizamuddin Dargah, Akshardham gateway"
    },
    districts: [
      "Central Delhi", "East Delhi", "New Delhi", "North Delhi", "North East Delhi",
      "North West Delhi", "Shahdara", "South Delhi", "South East Delhi", "South West Delhi", "West Delhi"
    ]
  },
  {
    id: "jammu-kashmir",
    name: "Jammu and Kashmir",
    type: "ut",
    capital: "Srinagar (Summer) / Jammu (Winter)",
    zone: "North",
    officialLanguages: ["Kashmiri", "Dogri", "Urdu", "Hindi", "English"],
    bestSeason: "April to October (Gardens & Valley) & Dec to Feb (Skiing in Gulmarg)",
    climate: "Alpine valley, snow-capped Himalayas, refreshing mountain air",
    description: "Paradise on Earth. Shikara rides on Dal Lake, houseboats, Mughal gardens of Srinagar, Gondola skiing in Gulmarg, Pahalgam valleys, and holy Vaishno Devi.",
    transit: {
      airports: ["Sheikh ul-Alam International Airport Srinagar (SXR)", "Jammu Airport (IXJ)"],
      railwayJunctions: ["Jammu Tawi (JAT)", "Shri Mata Vaishno Devi Katra (SVDK)", "Srinagar (connected via Udhampur-Srinagar-Baramulla rail link)"],
      highways: ["NH-44 (Chenani-Nashri & Banihal Qazigund Tunnels)"]
    },
    districtHighlights: {
      "Srinagar": "Dal Lake (Shikara & Houseboats), Nigeen Lake, Shalimar Bagh, Nishat Bagh, Shankaracharya Temple",
      "Baramulla": "Gulmarg (World's highest Gondola cable car, Apharwat Peak skiing)",
      "Anantnag": "Pahalgam (Betaab Valley, Aru Valley, Chandanwari, Amarnath Yatra base)",
      "Reasi": "Shri Mata Vaishno Devi Shrine (Katra), Chenab Railway Bridge (World's highest railway bridge)",
      "Ganderbal": "Sonamarg (Meadow of Gold, Thajiwas Glacier, gateway to Ladakh)"
    },
    districts: [
      "Anantnag", "Bandipora", "Baramulla", "Budgam", "Doda",
      "Ganderbal", "Jammu", "Kathua", "Kishtwar", "Kulgam",
      "Kupwara", "Poonch", "Pulwama", "Rajouri", "Ramban",
      "Reasi", "Samba", "Shopian", "Srinagar", "Udhampur"
    ]
  },
  {
    id: "ladakh",
    name: "Ladakh",
    type: "ut",
    capital: "Leh",
    zone: "North",
    officialLanguages: ["Ladakhi", "Hindi", "English"],
    bestSeason: "May to September (Winter for Chadar Trek in Jan-Feb)",
    climate: "Cold high-altitude desert, crystal clear blue skies",
    description: "The Land of High Passes. Stunning turquoise Pangong Tso, sand dunes of Nubra Valley with double-humped camels, Khardung La pass, and ancient Tibetan gompas.",
    transit: {
      airports: ["Kushok Bakula Rimpochee Airport Leh (IXL)"],
      railwayJunctions: ["None (Nearest major railhead is Jammu Tawi / Chandigarh)"],
      highways: ["Manali-Leh Highway (via Atal & Shinku La tunnels)", "Srinagar-Leh Highway (NH-1 via Zoji La)"]
    },
    districtHighlights: {
      "Leh": "Pangong Tso (color-changing lake), Khardung La (17,982 ft pass), Nubra Valley (Hunder sand dunes, Diskit Monastery), Thiksey & Hemis Gompas, Magnetic Hill",
      "Kargil": "Kargil War Memorial (Drass - 2nd coldest inhabited place), Suru Valley, Zanskar Valley (Padum, Phugtal Monastery, Chadar frozen river trek)"
    },
    districts: [
      "Kargil", "Leh"
    ]
  },
  {
    id: "lakshadweep",
    name: "Lakshadweep",
    type: "ut",
    capital: "Kavaratti",
    zone: "South",
    officialLanguages: ["Malayalam", "English"],
    bestSeason: "October to April",
    climate: "Tropical archipelago, crystal coral atolls",
    description: "India's secluded coral atoll paradise in the Arabian Sea. Unspoiled white sand beaches, turquoise lagoons, scuba diving, and marine biodiversity.",
    transit: {
      airports: ["Agatti Airport (AGX - regular Alliance Air flights from Kochi)"],
      railwayJunctions: ["None (Passenger ships operate from Kochi, Kerala)"],
      highways: ["Island inter-atoll ferry routes"]
    },
    districtHighlights: {
      "Lakshadweep": "Agatti Island (scuba diving, coral reef airstrip), Bangaram Atoll (uninhibited luxury lagoon), Kavaratti (capital lagoon & marine aquarium), Minicoy (Lighthouse & unique culture)"
    },
    districts: [
      "Lakshadweep"
    ]
  },
  {
    id: "puducherry",
    name: "Puducherry",
    type: "ut",
    capital: "Puducherry",
    zone: "South",
    officialLanguages: ["Tamil", "French", "English"],
    bestSeason: "October to March",
    climate: "Tropical coastal, pleasant sea breezes",
    description: "The French Riviera of the East. Charming pastel French quarters, Promenade Beach, Sri Aurobindo Ashram, international township Auroville, and beach cafes.",
    transit: {
      airports: ["Puducherry Airport (PNY)", "Chennai International (135 km via scenic ECR)"],
      railwayJunctions: ["Puducherry Railway Station (PDY)", "Villupuram Jn (VM - 38 km)"],
      highways: ["East Coast Road (ECR - scenic coastal route)", "NH-332"]
    },
    districtHighlights: {
      "Puducherry": "White Town (French Colony, yellow villas), Promenade Rock Beach, Sri Aurobindo Ashram, Auroville (Matrimandir), Paradise Beach",
      "Karaikal": "Karaikal Beach, ancient temples",
      "Mahe": "Arabian Sea coastal enclave, Tagore Park, colonial riverfront",
      "Yanam": "Godavari delta enclave, French colonial heritage riverwalk"
    },
    districts: [
      "Karaikal", "Mahe", "Puducherry", "Yanam"
    ]
  }
];

// Helper to calculate total statistics across India
const INDIA_STATS = {
  totalStates: INDIA_STATES_DATA.filter(s => s.type === 'state').length, // 28
  totalUTs: INDIA_STATES_DATA.filter(s => s.type === 'ut').length,       // 8
  totalDistricts: INDIA_STATES_DATA.reduce((acc, curr) => acc + curr.districts.length, 0),
  zones: ['North', 'South', 'East', 'West', 'Central', 'North-East']
};
