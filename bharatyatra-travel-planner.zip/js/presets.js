/**
 * WanderAI - Curated Indian Tourism Presets & Mock Data Engine (presets.js)
 * Tailored exclusively for Indian destinations with Indian Rupee (₹) economics.
 */

const CURRENCY_SYMBOLS = {
  INR: '₹',
  USD: '$',
  EUR: '€',
  GBP: '£',
  AED: 'AED'
};

const CURRENCY_RATES_FROM_INR = {
  INR: 1,
  USD: 0.012,
  EUR: 0.011,
  GBP: 0.0095,
  AED: 0.044
};

const INDIAN_POPULAR_DESTINATIONS = [
  { name: 'Jaipur, Rajasthan', state: 'Rajasthan', key: 'jaipur', icon: '🏰', img: 'assets/images/jaipur.jpg', tag: 'Royal Forts & Palaces' },
  { name: 'Alleppey & Munnar, Kerala', state: 'Kerala', key: 'kerala', icon: '🛶', img: 'assets/images/kerala.jpg', tag: 'Houseboats & Tea Hills' },
  { name: 'Manali & Solang, Himachal', state: 'Himachal Pradesh', key: 'manali', icon: '🏔️', img: 'assets/images/manali.jpg', tag: 'Snow Valleys & Treks' },
  { name: 'Goa (North & South)', state: 'Goa', key: 'goa', icon: '🏖️', img: 'assets/images/goa.jpg', tag: 'Beaches & Nightlife' },
  { name: 'Varanasi, Uttar Pradesh', state: 'Uttar Pradesh', key: 'varanasi', icon: '🛕', img: 'assets/images/jaipur.jpg', tag: 'Ganga Aarti & Ghats' },
  { name: 'Leh-Ladakh', state: 'Ladakh', key: 'ladakh', icon: '🏍️', img: 'assets/images/manali.jpg', tag: 'Pangong Lake & High Passes' },
  { name: 'Udaipur, Rajasthan', state: 'Rajasthan', key: 'udaipur', icon: '👑', img: 'assets/images/jaipur.jpg', tag: 'City of Lakes' },
  { name: 'Rishikesh, Uttarakhand', state: 'Uttarakhand', key: 'rishikesh', icon: '🧘', img: 'assets/images/manali.jpg', tag: 'Yoga & River Rafting' },
  { name: 'Darjeeling & Gangtok', state: 'West Bengal & Sikkim', key: 'darjeeling', icon: '🫖', img: 'assets/images/kerala.jpg', tag: 'Kanchenjunga & Toy Train' },
  { name: 'Andaman & Nicobar Islands', state: 'Andaman', key: 'andaman', icon: '🤿', img: 'assets/images/goa.jpg', tag: 'Radhanagar Beach & Scuba' }
];

const CURATED_PRESETS = {
  jaipur: {
    id: 'jaipur',
    name: 'Jaipur & Amer, Rajasthan',
    state: 'Rajasthan',
    image: 'assets/images/jaipur.jpg',
    origin: 'New Delhi (DEL)',
    durationDays: 4,
    party: 'couple',
    adults: 2,
    children: 0,
    budgetTier: 'luxury',
    budgetAmount: 48000,
    currency: 'INR',
    pace: 'balanced',
    vibes: ['heritage', 'food', 'photography', 'culture', 'shopping'],
    accommodation: 'haveli',
    transport: 'cab',
    dietary: ['vegetarian'],
    accessibility: [],
    customNotes: 'Sunset view from Nahargarh Fort, authentic Rajasthani Dal Baati Churma at Chokhi Dhani, visit Hawa Mahal at sunrise.',
    itinerary: {
      title: '4-Day Royal Rajasthan: Grand Forts, Havelis & Rajasthani Flavors',
      tagline: 'Immerse yourself in Rajput grandeur, vibrant bazaars, and royal dining.',
      totalEstimatedCost: 44500,
      days: [
        {
          dayNumber: 1,
          theme: 'Arrival, Pink City Stroll & Hawa Mahal',
          date: 'Day 1',
          activities: [
            {
              time: '10:30 AM',
              period: 'Morning',
              title: 'Vande Bharat Express Arrival & Heritage Haveli Check-in',
              category: 'Transit & Stay',
              desc: 'Arrive at Jaipur Junction via the morning Vande Bharat from Delhi. Check into a restored 19th-century royal Haveli in Bani Park with jharokha balconies.',
              tip: 'Request an upper-floor room with a traditional courtyard view.',
              cost: 1800,
              location: 'Bani Park, Jaipur'
            },
            {
              time: '02:00 PM',
              period: 'Afternoon',
              title: 'City Palace & Jantar Mantar Astronomical Observatory',
              category: 'Heritage & Architecture',
              desc: 'Explore Chandra Mahal, Mubarak Mahal, and the giant sundial Samrat Yantra at the UNESCO World Heritage Jantar Mantar.',
              tip: 'Get the composite entry ticket to skip lines at multiple monuments.',
              cost: 600,
              location: 'Jaleb Chowk, Old City'
            },
            {
              time: '05:30 PM',
              period: 'Evening',
              title: 'Hawa Mahal View from Wind View Café at Golden Hour',
              category: 'Photography & Chai',
              desc: 'Sip hot Kulhad Masala Chai overlooking the 953 honeycombed pink sandstone windows catching the sunset glow.',
              tip: 'The rooftop terrace directly across Hawa Mahal gives the best portrait angles.',
              cost: 350,
              location: 'Badi Chaupar'
            },
            {
              time: '08:00 PM',
              period: 'Night',
              title: 'Royal Rajasthani Thali at LMB (Laxmi Misthan Bhandar)',
              category: 'Food & Dining',
              desc: 'Feast on authentic Dal Baati Churma, Ker Sangri, Gatte ki Sabzi, and hot Ghewar dessert.',
              tip: 'Try their famous Pyaaz ki Kachori as an appetizer.',
              cost: 1400,
              location: 'Johari Bazaar'
            }
          ]
        },
        {
          dayNumber: 2,
          theme: 'Amer Fort Splendor & Nahargarh Sunset',
          date: 'Day 2',
          activities: [
            {
              time: '08:30 AM',
              period: 'Morning',
              title: 'Amer Fort & Sheesh Mahal (Mirror Palace)',
              category: 'Forts & Heritage',
              desc: 'Ascend the rugged Aravalli hillside to Amer Fort. Marvel at the Sheesh Mahal where a single candle flame illuminates the entire hall of convex mirrors.',
              tip: 'Hire an official government-approved guide at the gate for untold historical folklore.',
              cost: 1100,
              location: 'Amer, Jaipur'
            },
            {
              time: '01:00 PM',
              period: 'Afternoon',
              title: 'Panna Meena ka Kund Stepwell & Jal Mahal Photo Stop',
              category: 'Architecture',
              desc: 'Admire the symmetrical geometric staircases of the 16th-century stepwell, followed by a lakeside view of Jal Mahal floating in Man Sagar Lake.',
              tip: 'Stepwell is peaceful before midday tour groups arrive.',
              cost: 200,
              location: 'Amer Town'
            },
            {
              time: '05:00 PM',
              period: 'Evening',
              title: 'Nahargarh Fort Panoramic Sunset over Pink City',
              category: 'Scenic Views',
              desc: 'Watch the entire city of Jaipur bathe in amber and twilight lights from the ramparts of Nahargarh Fort perched on the Aravalli ridge.',
              tip: 'Dine or grab a cold beverage at Padao open-air restaurant inside the fort.',
              cost: 500,
              location: 'Aravalli Hills'
            },
            {
              time: '08:30 PM',
              period: 'Night',
              title: 'Chokhi Dhani Ethnic Cultural Village',
              category: 'Culture & Entertainment',
              desc: 'Experience live Kalbelia folk dances, puppet shows, camel rides, and a traditional sit-down village dinner served on leaf platters.',
              tip: 'Pre-book online to skip the main ticket counter rush.',
              cost: 2200,
              location: 'Tonk Road'
            }
          ]
        },
        {
          dayNumber: 3,
          theme: 'Jaigarh Fort, Blue Pottery & Johari Bazaar',
          date: 'Day 3',
          activities: [
            {
              time: '09:00 AM',
              period: 'Morning',
              title: 'Jaigarh Fort & The Legendary Jaivana Cannon',
              category: 'Military Heritage',
              desc: 'Visit the military fortress housing Jaivana, once the world’s largest cannon on wheels, connected to Amer Fort via underground secret passages.',
              tip: 'Explore the fort armory museum showcasing Mughal swords and shields.',
              cost: 400,
              location: 'Cheel ka Teela'
            },
            {
              time: '01:30 PM',
              period: 'Afternoon',
              title: 'Artisan Blue Pottery & Block Printing Workshop in Sanganer',
              category: 'Art & Crafts',
              desc: 'Witness master artisans hand-painting iconic quartz-powder Blue Pottery and hand block-printing natural dye fabrics.',
              tip: 'Authentic GI-tagged Jaipur blue pottery is lead-free and heat-resistant.',
              cost: 800,
              location: 'Sanganer'
            },
            {
              time: '05:30 PM',
              period: 'Evening',
              title: 'Bapu Bazaar & Johari Bazaar Shopping Spree',
              category: 'Shopping & Bazaars',
              desc: 'Shop for Jaipuri razai (quilts), leather Mojari footwear, silver jewelry, and Bandhani dupattas with lively bargaining.',
              tip: 'Start bargaining at 50-60% of quoted price in street stalls.',
              cost: 3500,
              location: 'Bapu Bazaar'
            },
            {
              time: '08:30 PM',
              period: 'Night',
              title: 'Rooftop Dinner at Baradari / 1135 AD',
              category: 'Fine Dining',
              desc: 'Dine in an opulent dining hall with silver-plated chairs, crystal chandeliers, and live Santoor music.',
              tip: 'Try their signature vegetarian Gatta Curry and saffron pulao.',
              cost: 3200,
              location: 'Amer / City Palace'
            }
          ]
        },
        {
          dayNumber: 4,
          theme: 'Albert Hall Museum & Royal Departure',
          date: 'Day 4',
          activities: [
            {
              time: '09:30 AM',
              period: 'Morning',
              title: 'Albert Hall Museum (Central Museum)',
              category: 'Culture & Museum',
              desc: 'Marvel at Indo-Saracenic architecture, Persian carpets, ivory carvings, and feed thousands of pigeons in the front plaza.',
              tip: 'Morning light provides crisp architectural photography.',
              cost: 300,
              location: 'Ram Niwas Garden'
            },
            {
              time: '12:30 PM',
              period: 'Afternoon',
              title: 'Ghewar Box Pickup & Departure Transfer',
              category: 'Departure',
              desc: 'Pick up fresh Malai Ghewar from Sambhar Fini / LMB and board your outstation AC cab or Vande Bharat back home.',
              tip: 'Ask for vacuum packing if carrying sweets on long train/flight journeys.',
              cost: 1500,
              location: 'Jaipur Junction'
            }
          ]
        }
      ],
      budgetBreakdown: {
        accommodation: { amount: 18000, percent: 40, label: 'Heritage Haveli & Boutique Stay (3 Nights)' },
        food: { amount: 11000, percent: 25, label: 'Royal Thalis, Chokhi Dhani, LMB & Cafes' },
        transit: { amount: 7500, percent: 17, label: 'Private AC Cab for 4 Days & Vande Bharat' },
        activities: { amount: 5000, percent: 11, label: 'Amer, Nahargarh, City Palace & Guides' },
        cushion: { amount: 3000, percent: 7, label: 'Handicrafts, Sweets & Emergency Buffer' }
      },
      weatherForecast: [
        { day: 'Day 1', icon: '☀️', temp: '28°C / 18°C', desc: 'Sunny & pleasant breeze' },
        { day: 'Day 2', icon: '☀️', temp: '29°C / 17°C', desc: 'Clear skies, perfect for forts' },
        { day: 'Day 3', icon: '🌤️', temp: '27°C / 16°C', desc: 'Mild with light evening chill' },
        { day: 'Day 4', icon: '☀️', temp: '28°C / 17°C', desc: 'Bright & warm departure' }
      ],
      advisorNotes: [
        { icon: '🎟️', title: 'Composite Ticket', text: 'Buy the Department of Archaeology composite ticket (valid for 2 days) covering Amer Fort, Albert Hall, Hawa Mahal, Jantar Mantar, and Nahargarh to save ₹400+.' },
        { icon: '🚕', title: 'Local Transport', text: 'Pre-book a full-day AC sedan cab (approx ₹2,000-2,500/day for 80km) to comfortably cover Amer and Nahargarh forts which are situated outside city limits.' },
        { icon: '🧥', title: 'Winter Evenings', text: 'Between October and February, temperatures drop noticeably at Nahargarh Fort after sunset; pack a light jacket or shawl.' }
      ]
    }
  },

  kerala: {
    id: 'kerala',
    name: 'Alleppey & Munnar, Kerala',
    state: 'Kerala',
    image: 'assets/images/kerala.jpg',
    origin: 'Bengaluru (BLR)',
    durationDays: 5,
    party: 'family',
    adults: 3,
    children: 1,
    budgetTier: 'luxury',
    budgetAmount: 58000,
    currency: 'INR',
    pace: 'relaxed',
    vibes: ['nature', 'wellness', 'photography', 'food', 'culture'],
    accommodation: 'resort',
    transport: 'cab',
    dietary: ['vegetarian'],
    accessibility: [],
    customNotes: 'Private overnight luxury houseboat in Alleppey backwaters, tea factory tasting in Munnar, Ayurvedic massage.',
    itinerary: {
      title: '5-Day God’s Own Country: Emerald Tea Mist & Serene Houseboat Backwaters',
      tagline: 'Rolling tea gardens of Munnar, spice plantations, and dreamy backwater houseboat cruising.',
      totalEstimatedCost: 52400,
      days: [
        {
          dayNumber: 1,
          theme: 'Cochin Arrival & Ascent into Misty Munnar',
          date: 'Day 1',
          activities: [
            {
              time: '09:00 AM',
              period: 'Morning',
              title: 'Cochin Airport Pickup & Scenic Western Ghats Drive',
              category: 'Transit',
              desc: 'Private Innova Crysta drive through rubber plantations and misty mountain hairpin bends toward Munnar.',
              tip: 'Stop at Cheeyappara and Valara waterfalls along the highway for fresh tender coconut.',
              cost: 3200,
              location: 'Kochi to Munnar'
            },
            {
              time: '02:30 PM',
              period: 'Afternoon',
              title: 'Spice Plantation Guided Walk in Adimali',
              category: 'Nature & Agriculture',
              desc: 'Learn about organic green cardamom, black pepper vines, cinnamon bark, and vanilla pods from local farmers.',
              tip: 'Buy fresh vacuum-packed whole spices directly at farm-gate prices.',
              cost: 500,
              location: 'Adimali'
            },
            {
              time: '07:00 PM',
              period: 'Night',
              title: 'Traditional Kathakali & Kalaripayattu Martial Arts Show',
              category: 'Culture',
              desc: 'Witness the classical storytelling dance drama with elaborate facial makeup followed by ancient martial arts acrobatics.',
              tip: 'Arrive 30 minutes early to watch the artists apply natural mineral makeup.',
              cost: 1200,
              location: 'Punnamada Munnar Center'
            }
          ]
        },
        {
          dayNumber: 2,
          theme: 'Munnar Tea Estates, Eravikulam & Top Station',
          date: 'Day 2',
          activities: [
            {
              time: '07:30 AM',
              period: 'Morning',
              title: 'Eravikulam National Park & Nilgiri Tahr Sanctuary',
              category: 'Wildlife & Nature',
              desc: 'Ride the park shuttle to spot the endangered wild mountain goat (Nilgiri Tahr) roaming rolling grasslands under Anamudi Peak (South India’s highest peak).',
              tip: 'Advance online booking is mandatory through Kerala Forest Dept portal.',
              cost: 1100,
              location: 'Rajamalai'
            },
            {
              time: '01:00 PM',
              period: 'Afternoon',
              title: 'Tata Tea Museum & Orthodox Tea Factory Experience',
              category: 'Heritage & Food',
              desc: 'Watch the historic CTC and orthodox tea production process and participate in a guided tea tasting session.',
              tip: 'Pick up Munnar silver tips and green tea packets at the factory outlet.',
              cost: 450,
              location: 'Nullatanni Estate'
            },
            {
              time: '04:30 PM',
              period: 'Evening',
              title: 'Mattupetty Dam & Echo Point Boating',
              category: 'Scenic & Leisure',
              desc: 'Speedboat cruise on the reservoir surrounded by emerald hills, followed by yelling your name at the acoustic Echo Point.',
              tip: 'Look out for wild elephants drinking by the reservoir shore in the late afternoon.',
              cost: 900,
              location: 'Mattupetty'
            }
          ]
        },
        {
          dayNumber: 3,
          theme: 'Munnar to Alleppey (Alappuzha) Backwaters',
          date: 'Day 3',
          activities: [
            {
              time: '08:30 AM',
              period: 'Morning',
              title: 'Descent from Ghats to Alleppey Backwater Jetty',
              category: 'Transit',
              desc: 'Scenic 4-hour drive down the Western Ghats into the palm-fringed coastal backwaters of Alleppey.',
              tip: 'Stop at a local bakery for hot Kerala banana fritters (Pazham Pori).',
              cost: 2800,
              location: 'Munnar to Alleppey'
            },
            {
              time: '01:00 PM',
              period: 'Afternoon',
              title: 'Check-in to Private Luxury Thatched Houseboat (Kettuvallam)',
              category: 'Stay & Experience',
              desc: 'Board your private AC houseboat with dedicated captain, chef, and crew. Welcome drink of fresh tender coconut.',
              tip: 'Houseboats cruise until 5:30 PM and anchor peacefully in the village canal for the night.',
              cost: 16500,
              location: 'Punnamada Jetty'
            },
            {
              time: '02:00 PM',
              period: 'Afternoon',
              title: 'Traditional Kerala Sadhya Lunch Served on Banana Leaf',
              category: 'Dining',
              desc: 'Freshly prepared feast of Kerala red rice, Avial, Thoran, Sambar, crispy Pappadam, and Payasam dessert.',
              tip: 'Chef will happily tailor spice levels for kids and prepare special items upon request.',
              cost: 0,
              location: 'Onboard Houseboat'
            },
            {
              time: '05:30 PM',
              period: 'Evening',
              title: 'Sunset Backwater Cruise through Kuttanad Paddy Fields',
              category: 'Scenic Wonder',
              desc: 'Glide silently past duck farms and village canals in Kuttanad, the only place in India where farming is done below sea level.',
              tip: 'Golden hour reflections on the lake are extraordinary for family portraits.',
              cost: 0,
              location: 'Vembanad Lake'
            }
          ]
        },
        {
          dayNumber: 4,
          theme: 'Village Canoe Ride & Traditional Ayurvedic Rejuvenation',
          date: 'Day 4',
          activities: [
            {
              time: '07:00 AM',
              period: 'Morning',
              title: 'Early Morning Country Canoe Shikara in Narrow Canals',
              category: 'Hidden Gems',
              desc: 'Hop onto a traditional wooden hand-rowed canoe to explore narrow village canals where houseboats cannot enter.',
              tip: 'Observe kingfishers, cormorants, and village morning life up close.',
              cost: 800,
              location: 'Kainakary Village'
            },
            {
              time: '11:30 AM',
              period: 'Morning',
              title: 'Houseboat Checkout & Marari Beach Resort Check-in',
              category: 'Stay & Leisure',
              desc: 'Transfer to a tranquil eco-beach resort on Marari Beach with swaying coconut palms and white sands.',
              tip: 'Marari is significantly cleaner and quieter than commercial beaches.',
              cost: 6500,
              location: 'Mararikulam'
            },
            {
              time: '03:30 PM',
              period: 'Afternoon',
              title: 'Authentic Ayurvedic Abhyanga Full-Body Massage',
              category: 'Wellness & Spa',
              desc: 'Herbal medicated warm oil massage followed by steam bath administered by licensed Ayurvedic practitioners.',
              tip: 'Rest for an hour after the treatment and drink warm herbal water.',
              cost: 3200,
              location: 'Marari Wellness Spa'
            }
          ]
        },
        {
          dayNumber: 5,
          theme: 'Fort Kochi Heritage Walk & Departure',
          date: 'Day 5',
          activities: [
            {
              time: '09:00 AM',
              period: 'Morning',
              title: 'Chinese Fishing Nets & Jew Town in Fort Kochi',
              category: 'Heritage & Shopping',
              desc: 'Watch fishermen operate the iconic 14th-century cantilevered Chinese fishing nets, followed by Jewish Synagogue and antique shopping in Jew Town.',
              tip: 'Grab lunch at the legendary Kashi Art Café.',
              cost: 1100,
              location: 'Fort Kochi'
            },
            {
              time: '03:00 PM',
              period: 'Afternoon',
              title: 'Transfer to Cochin International Airport (COK)',
              category: 'Departure',
              desc: 'Cochin airport is the world’s first fully solar-powered airport. Board your return flight with unforgettable memories.',
              tip: 'Allow 1.5 hours for Fort Kochi to Cochin Airport transit.',
              cost: 1600,
              location: 'Nedumbassery'
            }
          ]
        }
      ],
      budgetBreakdown: {
        accommodation: { amount: 23000, percent: 44, label: 'Houseboat (1N) + Munnar Tea Resort (2N) + Marari (1N)' },
        transit: { amount: 12500, percent: 24, label: 'Dedicated Outstation Innova Crysta (5 Days)' },
        food: { amount: 8400, percent: 16, label: 'Kerala Sadhya, Houseboat Meals & Dining' },
        activities: { amount: 5500, percent: 10, label: 'Ayurveda, Kathakali, Eravikulam & Shikara' },
        cushion: { amount: 3000, percent: 6, label: 'Munnar Spices, Tea & Souvenirs' }
      },
      weatherForecast: [
        { day: 'Day 1', icon: '🌤️', temp: '22°C / 14°C', desc: 'Misty hills in Munnar' },
        { day: 'Day 2', icon: '⛅', temp: '21°C / 13°C', desc: 'Pleasant & crisp mountain air' },
        { day: 'Day 3', icon: '☀️', temp: '30°C / 24°C', desc: 'Sunny tropical backwaters' },
        { day: 'Day 4', icon: '🌤️', temp: '31°C / 24°C', desc: 'Warm coastal sea breeze' },
        { day: 'Day 5', icon: '☀️', temp: '30°C / 25°C', desc: 'Clear skies in Fort Kochi' }
      ],
      advisorNotes: [
        { icon: '🛶', title: 'Houseboat Selection', text: 'Always book government-licensed houseboats with green category eco-certification to ensure top safety, hygiene, and functioning AC.' },
        { icon: '🚗', title: 'Hilly Ghat Roads', text: 'Munnar hairpins can cause motion sickness for young kids or elders; carry sickness tablets and avoid heavy meals right before mountain climbs.' }
      ]
    }
  },

  manali: {
    id: 'manali',
    name: 'Manali & Solang Valley, Himachal',
    state: 'Himachal Pradesh',
    image: 'assets/images/manali.jpg',
    origin: 'Chandigarh (IXC)',
    durationDays: 5,
    party: 'friends',
    adults: 4,
    children: 0,
    budgetTier: 'moderate',
    budgetAmount: 36000,
    currency: 'INR',
    pace: 'fast',
    vibes: ['adventure', 'nature', 'photography', 'food', 'nightlife'],
    accommodation: 'cottage',
    transport: 'cab',
    dietary: ['none'],
    accessibility: [],
    customNotes: 'Atal Tunnel road trip, paragliding at Solang Valley, river rafting in Beas river, Old Manali hippie cafes.',
    itinerary: {
      title: '5-Day Himalayan Thrill: Atal Tunnel, Solang Snow & Beas River Rafting',
      tagline: 'Snow-capped Himalayan valleys, alpine pine forests, thrilling white-water rapids, and café culture.',
      totalEstimatedCost: 32800,
      days: [
        {
          dayNumber: 1,
          theme: 'Arrival, Hadimba Temple & Old Manali Vibe',
          date: 'Day 1',
          activities: [
            {
              time: '11:00 AM',
              period: 'Morning',
              title: 'Arrival in Manali & Wooden Alpine Cottage Check-in',
              category: 'Stay',
              desc: 'Check into a cozy cedar wood cottage overlooking the snowcapped Pir Panjal range in Old Manali.',
              tip: 'Breathe in the crisp Himalayan pine air on your balcony.',
              cost: 1600,
              location: 'Old Manali'
            },
            {
              time: '02:30 PM',
              period: 'Afternoon',
              title: 'Historic Hadimba Devi Temple in Dhungri Forest',
              category: 'Heritage & Nature',
              desc: 'Visit the 1553 AD pagoda-style wooden temple nestled inside towering cedar deodar forests.',
              tip: 'Take a photo with fluffy Angora rabbits and mountain yaks outside the temple.',
              cost: 100,
              location: 'Dhungri'
            },
            {
              time: '07:30 PM',
              period: 'Night',
              title: 'Old Manali Live Music Café Night (Café 1947 / Dylan’s)',
              category: 'Food & Nightlife',
              desc: 'Wood-fired pizzas, trout fish delicacies, and live acoustic Indie music alongside the roaring Manalsu river.',
              tip: 'Try their fresh hot apple crumble with vanilla ice cream.',
              cost: 1400,
              location: 'Old Manali Bridge'
            }
          ]
        },
        {
          dayNumber: 2,
          theme: 'Solang Valley Adventure & High Paragliding',
          date: 'Day 2',
          activities: [
            {
              time: '08:30 AM',
              period: 'Morning',
              title: 'Tandem Paragliding at Solang Valley',
              category: 'Thrills & Adventure',
              desc: 'Soar like an eagle with an experienced pilot above Solang Valley with 360-degree views of glaciated peaks.',
              tip: 'Opt for GoPro video recording bundle to capture the flight in 4K.',
              cost: 3200,
              location: 'Solang Valley'
            },
            {
              time: '01:00 PM',
              period: 'Afternoon',
              title: 'Zorbing & Solang Valley Ropeway Cable Car',
              category: 'Adventure',
              desc: 'Roll down grassy slopes in a giant inflatable sphere and take the ropeway to Mount Phatru at 3,200m.',
              tip: 'Wear sturdy sports shoes with warm socks.',
              cost: 1100,
              location: 'Solang'
            },
            {
              time: '06:00 PM',
              period: 'Evening',
              title: 'Jogini Waterfall Short Forest Hike',
              category: 'Nature & Hike',
              desc: 'Brisk 45-minute pine trail walk from Vashisht village to the base of cascading Jogini falls.',
              tip: 'The mountain water is ice-cold but invigorating to splash your face.',
              cost: 0,
              location: 'Vashisht'
            }
          ]
        },
        {
          dayNumber: 3,
          theme: 'Atal Tunnel Feat & Sissu Waterfall in Lahaul Valley',
          date: 'Day 3',
          activities: [
            {
              time: '08:00 AM',
              period: 'Morning',
              title: 'Drive through Atal Tunnel (World’s Longest Highway Tunnel above 10,000 ft)',
              category: 'Engineering & Scenic',
              desc: '9.02 km engineering marvel cutting right through the Rohtang ridge, instantly emerging into the stark Himalayan desert of Lahaul.',
              tip: 'The sudden landscape transition from lush green Manali to barren snow-dusted Lahaul is breathtaking.',
              cost: 2500,
              location: 'Atal Tunnel North Portal'
            },
            {
              time: '11:00 AM',
              period: 'Morning',
              title: 'Sissu Waterfall & Glacial Lake Walk',
              category: 'Nature Wonder',
              desc: 'Marvel at the high hanging waterfall dropping into the Chandra River with prayer flags fluttering in mountain winds.',
              tip: 'Eat hot steaming Maggi and Thukpa at local Lahauli roadside stalls.',
              cost: 400,
              location: 'Sissu, Lahaul'
            },
            {
              time: '07:00 PM',
              period: 'Night',
              title: 'Bonfire & Barbecue Night at Mountain Cottage',
              category: 'Leisure',
              desc: 'Gather around a crackling pine wood bonfire under a crystal clear starry Himalayan sky.',
              tip: 'Cottages provide wood and grill setups upon prior intimation.',
              cost: 1200,
              location: 'Cottage Lawn'
            }
          ]
        },
        {
          dayNumber: 4,
          theme: 'Beas River White-Water Rafting & Naggar Castle',
          date: 'Day 4',
          activities: [
            {
              time: '09:00 AM',
              period: 'Morning',
              title: 'Grade III White-Water Rafting on River Beas in Kullu',
              category: 'Thrills & Water Sports',
              desc: '14-kilometer exhilarating rapid descent through bouncy rapids of the glacial Beas river.',
              tip: 'Government-certified rafting operators provide full lifejackets, helmets, and rescue kayaks.',
              cost: 2400,
              location: 'Pirdi, Kullu'
            },
            {
              time: '02:00 PM',
              period: 'Afternoon',
              title: 'Historic Naggar Castle & Nicholas Roerich Art Gallery',
              category: 'Heritage & Art',
              desc: 'Visit the 500-year-old Kathkuni wood-and-stone castle that withstood major earthquakes, overlooking the entire Kullu valley.',
              tip: 'The balcony cafe serves delicious Himachali trout and walnut pie.',
              cost: 350,
              location: 'Naggar'
            }
          ]
        },
        {
          dayNumber: 5,
          theme: 'Mall Road Shopping & Departure',
          date: 'Day 5',
          activities: [
            {
              time: '10:00 AM',
              period: 'Morning',
              title: 'Mall Road Woolen Shopping & Himachali Apples',
              category: 'Shopping',
              desc: 'Buy authentic Kullu shawls, handmade woolen caps, fresh apple cider, and pine honey.',
              tip: 'Look for the certified Kullu Shawls weavers cooperative emblem.',
              cost: 2500,
              location: 'The Mall, Manali'
            },
            {
              time: '03:00 PM',
              period: 'Afternoon',
              title: 'Outstation Cab Departure to Chandigarh / Delhi',
              category: 'Departure',
              desc: 'Board the scenic Himalayan four-lane expressway back toward Chandigarh airport or Volvo bus.',
              tip: 'Allow 8-9 hours for travel down to Chandigarh.',
              cost: 3800,
              location: 'Manali Bus Terminal'
            }
          ]
        }
      ],
      budgetBreakdown: {
        accommodation: { amount: 12000, percent: 37, label: 'Alpine Wood Cottage in Old Manali (4 Nights)' },
        activities: { amount: 8200, percent: 25, label: 'Paragliding, River Rafting, Ropeway & Atal Tunnel' },
        transit: { amount: 6500, percent: 20, label: 'Dedicated 4x4 / Outstation Cab' },
        food: { amount: 4600, percent: 14, label: 'Riverside Cafes, Trout Dinners & Himachali Food' },
        cushion: { amount: 1500, percent: 4, label: 'Woolens & Apple Cider Souvenirs' }
      },
      weatherForecast: [
        { day: 'Day 1', icon: '🌤️', temp: '16°C / 4°C', desc: 'Crisp valley sunshine' },
        { day: 'Day 2', icon: '☀️', temp: '14°C / 3°C', desc: 'Clear skies in Solang' },
        { day: 'Day 3', icon: '❄️', temp: '6°C / -2°C', desc: 'Cold & breezy in Sissu / Lahaul' },
        { day: 'Day 4', icon: '☀️', temp: '17°C / 5°C', desc: 'Sunny rafting weather in Kullu' },
        { day: 'Day 5', icon: '🌤️', temp: '15°C / 4°C', desc: 'Clear departure day' }
      ],
      advisorNotes: [
        { icon: '🚗', title: 'Atal Tunnel & Rohtang Permit', text: 'Vehicles traveling past Atal Tunnel into Lahaul do not require Green Tax permits, but Rohtang Pass itself requires a limited daily SDM permit booked in advance.' },
        { icon: '🧥', title: 'Warm Clothing', text: 'Temperatures dip below freezing at Sissu and Solang in mornings. Carry thermal inners, waterproof gloves, and windproof jackets.' }
      ]
    }
  },

  goa: {
    id: 'goa',
    name: 'Goa (North & South)',
    state: 'Goa',
    image: 'assets/images/goa.jpg',
    origin: 'Mumbai (BOM)',
    durationDays: 4,
    party: 'friends',
    adults: 3,
    children: 0,
    budgetTier: 'moderate',
    budgetAmount: 28000,
    currency: 'INR',
    pace: 'relaxed',
    vibes: ['nightlife', 'food', 'adventure', 'photography', 'hidden_gems'],
    accommodation: 'boutique',
    transport: 'bike',
    dietary: ['none'],
    accessibility: [],
    customNotes: 'Fontainhas Latin Quarter walk, Scuba at Grande Island, Anjuna sunset shack, Palolem beach kayak.',
    itinerary: {
      title: '4-Day Sun, Susegad & Sea: Latin Quarters to Pristine Southern Shores',
      tagline: 'Vibrant beach shacks, Portuguese heritage, thrilling water sports, and laid-back sunset vibes.',
      totalEstimatedCost: 25400,
      days: [
        {
          dayNumber: 1,
          theme: 'Arrival, Fontainhas Latin Quarter & Panaji Heritage',
          date: 'Day 1',
          activities: [
            {
              time: '11:00 AM',
              period: 'Morning',
              title: 'Mopa / Dabolim Airport Arrival & Scooter / Thar Rental',
              category: 'Transit',
              desc: 'Pick up Activa scooters or open-top Thar for the classic Goan coastal road freedom.',
              tip: 'Wear ISI-marked helmets at all times; Goan traffic police strictly monitor coastal highways.',
              cost: 1500,
              location: 'Airport to Panaji'
            },
            {
              time: '02:00 PM',
              period: 'Afternoon',
              title: 'Walking Tour of Fontainhas Latin Quarter',
              category: 'Heritage & Photography',
              desc: 'Stroll among pastel yellow, blue, and terracotta Portuguese colonial villas with wrought-iron balconies.',
              tip: 'Stop at Confeitaria 31 De Janeiro (Goa’s oldest bakery since 1930) for warm Bebinca.',
              cost: 400,
              location: 'Fontainhas, Panaji'
            },
            {
              time: '06:30 PM',
              period: 'Evening',
              title: 'Sunset Drinks & Seafood at Fisherman’s Wharf',
              category: 'Dining & Drinks',
              desc: 'Live acoustic Goan music with spicy butter garlic prawns, Goan fish curry, and cold King’s beer.',
              tip: 'Sit by the riverside deck to catch the river breeze.',
              cost: 1600,
              location: 'Panaji / Sal River'
            }
          ]
        },
        {
          dayNumber: 2,
          theme: 'Grande Island Scuba Diving & Dolphin Cruise',
          date: 'Day 2',
          activities: [
            {
              time: '07:30 AM',
              period: 'Morning',
              title: 'Speedboat Cruise to Grande Island & Scuba Diving',
              category: 'Adventure & Water Sports',
              desc: 'Explore coral reefs, sea turtles, and colorful parrotfish with certified PADI dive instructors.',
              tip: 'Includes light breakfast, fruits, and underwater video recording.',
              cost: 3800,
              location: 'Grande Island'
            },
            {
              time: '02:00 PM',
              period: 'Afternoon',
              title: 'Beachside Seafood BBQ at Monkey Beach',
              category: 'Food',
              desc: 'Fresh grilled mackerel with Recheado masala and Goan poi bread prepared on a secluded cove beach.',
              tip: 'Included in the Grande Island adventure package.',
              cost: 0,
              location: 'Monkey Beach'
            },
            {
              time: '07:30 PM',
              period: 'Night',
              title: 'Anjuna Clifftop Sunset & Curlies / Thalassa Vibe',
              category: 'Nightlife',
              desc: 'Watch the Arabian Sea sunset from clifftops with electronic ambient music and fire dancers on the beach.',
              tip: 'Reserve sunset tables at least 24 hours ahead during peak season.',
              cost: 1800,
              location: 'Vagator / Anjuna'
            }
          ]
        },
        {
          dayNumber: 3,
          theme: 'Tranquil South Goa: Palolem & Cabo de Rama Fort',
          date: 'Day 3',
          activities: [
            {
              time: '09:00 AM',
              period: 'Morning',
              title: 'Coastal Ride South to Cabo de Rama Fort',
              category: 'Scenic Ride & Views',
              desc: 'Centuries-old cliffside fort offering panoramic views where turquoise sea meets rugged volcanic cliffs.',
              tip: 'Check out the secluded pebble beach just beneath the fort ramparts.',
              cost: 100,
              location: 'Canacona'
            },
            {
              time: '01:30 PM',
              period: 'Afternoon',
              title: 'Sea Kayaking at Palolem Crescent Beach',
              category: 'Nature & Sports',
              desc: 'Paddle two-person ocean kayaks into Butterfly Beach lagoon with calm, crystal turquoise waters.',
              tip: 'Mornings and early afternoons offer the flattest sea conditions.',
              cost: 800,
              location: 'Palolem Beach'
            },
            {
              time: '08:00 PM',
              period: 'Night',
              title: 'Candlelight Dinner with Toes in the Sand at Dropadi',
              category: 'Gastronomy',
              desc: 'Watch gentle phosphorescent waves roll onto the shore while enjoying fresh tandoori crab and garlic naan.',
              tip: 'Try local Cashew Feni cocktails mixed with Limca and green chillies.',
              cost: 1500,
              location: 'Palolem Beach'
            }
          ]
        },
        {
          dayNumber: 4,
          theme: 'Chapora Fort (Dil Chahta Hai) & Departure',
          date: 'Day 4',
          activities: [
            {
              time: '09:30 AM',
              period: 'Morning',
              title: 'Chapora Fort Clifftop Panoramas',
              category: 'Iconic Sights',
              desc: 'Iconic red laterite fort overlooking Vagator Beach and Morjim river mouth made famous by Bollywood movies.',
              tip: 'Wear slip-resistant sneakers for the short 10-minute stone pathway ascent.',
              cost: 50,
              location: 'Vagator'
            },
            {
              time: '01:00 PM',
              period: 'Afternoon',
              title: 'Goan Cashew & Spices Shopping & Airport Run',
              category: 'Departure',
              desc: 'Pick up roasted salted Goan cashews, artisanal coconut feni, and choriz sausages before heading to the terminal.',
              tip: 'Zantye’s is the most trusted brand for authentic Goan cashews.',
              cost: 1200,
              location: 'Panaji Market'
            }
          ]
        }
      ],
      budgetBreakdown: {
        accommodation: { amount: 10000, percent: 39, label: 'Beachside Boutique Resort in North/South Goa (3N)' },
        food: { amount: 6500, percent: 26, label: 'Beach Shacks, Seafood Curries & Clifftop Cafes' },
        activities: { amount: 4800, percent: 19, label: 'Scuba Diving, Kayaking & Forts' },
        transit: { amount: 2600, percent: 10, label: 'Scooter / Thar Rentals & Fuel' },
        cushion: { amount: 1500, percent: 6, label: 'Cashews, Bebinca & Souvenirs' }
      },
      weatherForecast: [
        { day: 'Day 1', icon: '☀️', temp: '32°C / 23°C', desc: 'Sunny beach weather' },
        { day: 'Day 2', icon: '☀️', temp: '31°C / 22°C', desc: 'Calm seas, perfect for diving' },
        { day: 'Day 3', icon: '🌤️', temp: '32°C / 23°C', desc: 'Warm with gentle evening breeze' },
        { day: 'Day 4', icon: '☀️', temp: '31°C / 24°C', desc: 'Bright coastal sunshine' }
      ],
      advisorNotes: [
        { icon: '🏖️', title: 'North vs South Goa', text: 'North Goa (Baga, Anjuna, Vagator) is ideal for nightlife, water sports, and bustling markets. South Goa (Palolem, Benaulim, Agonda) is serene, clean, and ideal for relaxation.' },
        { icon: '🛵', title: 'Vehicle Rentals', text: 'Ensure you carry a valid original driver’s license. Always inspect rental bikes for existing scratches and take a quick phone video before driving off.' }
      ]
    }
  }
};

/**
 * Real Indian Transport Options Database
 * Flights, Trains, Buses, and Own Vehicle Routes with time management and booking links
 */
const TRANSPORT_DATABASE = {
  jaipur: {
    origin: 'New Delhi (DEL)',
    destination: 'Jaipur, Rajasthan',
    distanceKm: 268,
    options: [
      // ✈️ Flights
      {
        id: 'flight_6e_del_jai',
        mode: 'flight',
        modeLabel: 'Plane / Flight',
        modeIcon: '✈️',
        title: 'IndiGo 6E-2134 (Non-Stop)',
        operator: 'IndiGo Airlines',
        badge: 'Fastest Transit',
        route: 'Indira Gandhi T3 (DEL) ➔ Jaipur Airport (JAI)',
        departureTime: '06:45 AM',
        arrivalTime: '07:40 AM',
        duration: '55 mins',
        durationHours: 0.92,
        price: 3650,
        classes: ['Economy: ₹3,650 (7kg cabin + 15kg check-in)', 'Flexi Plus: ₹4,450 (free seat + meal)'],
        frequency: 'Daily (4 flights/day)',
        timeImpact: '⚡ Super-Early Arrival: Lands at 7:40 AM. You have the entire Day 1 free for City Palace and Amer Fort!',
        pros: 'Shortest travel time, zero fatigue',
        cons: 'Need to reach airport 1.5h in advance',
        bookingProviders: [
          { name: 'IndiGo Official', url: 'https://www.goindigo.in/', badge: 'Official', recommended: true },
          { name: 'MakeMyTrip', url: 'https://www.makemytrip.com/flights/', badge: 'Instant Discount' },
          { name: 'EaseMyTrip', url: 'https://www.easemytrip.com/', badge: 'Zero Convenience Fee' }
        ]
      },
      {
        id: 'flight_ai_del_jai',
        mode: 'flight',
        modeLabel: 'Plane / Flight',
        modeIcon: '✈️',
        title: 'Air India AI-804 (Non-Stop)',
        operator: 'Air India',
        badge: 'Full Service',
        route: 'Delhi T3 (DEL) ➔ Jaipur Airport (JAI)',
        departureTime: '04:15 PM',
        arrivalTime: '05:15 PM',
        duration: '1h 00m',
        durationHours: 1.0,
        price: 4200,
        classes: ['Economy: ₹4,200 (includes hot meal)', 'Business: ₹9,800'],
        frequency: 'Daily (Evening)',
        timeImpact: '🌅 Golden Hour Arrival: Reach at 5:15 PM, straight to Nahargarh sunset view!',
        pros: 'Complimentary hot snack & generous baggage',
        cons: 'Higher fare',
        bookingProviders: [
          { name: 'Air India Official', url: 'https://www.airindia.com/', badge: 'Official', recommended: true },
          { name: 'MakeMyTrip', url: 'https://www.makemytrip.com/flights/', badge: 'Offers' }
        ]
      },

      // 🚆 Trains
      {
        id: 'train_vb_20978',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '20978 Vande Bharat Express',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Most Popular & Reliable',
        route: 'New Delhi (NDLS) ➔ Jaipur Junction (JP)',
        departureTime: '06:10 AM',
        arrivalTime: '09:50 AM',
        duration: '3h 40m',
        durationHours: 3.67,
        price: 1250,
        classes: ['AC Chair Car (CC): ₹1,250 (includes breakfast)', 'Executive Chair Car (EC): ₹2,350 (leather seats + gourmet breakfast)'],
        frequency: 'Daily (except Wednesday)',
        timeImpact: '☕ Morning Scenic Express: Enjoy hot breakfast onboard while watching Aravalli hills, arrive right in city center at 9:50 AM.',
        pros: 'Center-to-center travel, high-speed 130 km/h, very clean',
        cons: 'Book 7-10 days in advance for confirmed seats',
        bookingProviders: [
          { name: 'IRCTC NextGen', url: 'https://www.irctc.co.in/nget/train-search', badge: 'Govt Official Portal', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/', badge: 'Live PNR & Seat Prediction' }
        ]
      },
      {
        id: 'train_shatabdi_12015',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '12015 Ajmer Shatabdi Express',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Classic Express',
        route: 'New Delhi (NDLS) ➔ Jaipur Junction (JP)',
        departureTime: '06:10 AM',
        arrivalTime: '10:40 AM',
        duration: '4h 30m',
        durationHours: 4.5,
        price: 990,
        classes: ['AC Chair Car (CC): ₹990 (with meals)', 'Executive Class (EC): ₹1,850'],
        frequency: 'Daily',
        timeImpact: '🥪 Great Morning Timing: On-time arrival with breakfast served at your seat.',
        pros: 'Economical, punctuality',
        cons: 'Older coaches compared to Vande Bharat',
        bookingProviders: [
          { name: 'IRCTC NextGen', url: 'https://www.irctc.co.in/nget/train-search', badge: 'Official', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/', badge: 'Instant Tatkal' }
        ]
      },
      {
        id: 'train_ashram_12916',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '12916 Ashram Superfast Express',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Budget Sleeper',
        route: 'Old Delhi (DLI) ➔ Jaipur Junction (JP)',
        departureTime: '03:20 PM',
        arrivalTime: '08:25 PM',
        duration: '5h 05m',
        durationHours: 5.08,
        price: 380,
        classes: ['Sleeper (SL): ₹380', 'AC 3 Tier (3A): ₹890', 'AC 2 Tier (2A): ₹1,250'],
        frequency: 'Daily',
        timeImpact: '🌙 Evening Arrival: Check into your Haveli, enjoy dinner in Bani Park and get ready for a fresh Day 2.',
        pros: 'Super budget-friendly',
        cons: 'Slower speed, stops at multiple stations',
        bookingProviders: [
          { name: 'IRCTC NextGen', url: 'https://www.irctc.co.in/nget/train-search', badge: 'Official', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/', badge: 'App Booking' }
        ]
      },

      // 🚌 Buses
      {
        id: 'bus_zingbus_del_jai',
        mode: 'bus',
        modeLabel: 'AC Volvo / Sleeper Bus',
        modeIcon: '🚌',
        title: 'Zingbus Electric Multi-Axle Volvo AC Sleeper',
        operator: 'Zingbus Premium',
        badge: 'Eco-Friendly & Luxurious',
        route: 'Dhaula Kuan / Kashmiri Gate ➔ Sindhi Camp, Jaipur',
        departureTime: '07:00 AM (Multiple slots)',
        arrivalTime: '12:15 PM',
        duration: '5h 15m',
        durationHours: 5.25,
        price: 780,
        classes: ['Single AC Sleeper: ₹780', 'Semi-Sleeper Recliner: ₹620'],
        frequency: 'Hourly departures all day & night',
        timeImpact: '🛋️ Comfortable Highway Ride: High-speed charging, free WiFi & clean midway bio-rest stop.',
        pros: 'Frequent buses without booking weeks in advance, lounge pickup',
        cons: 'Can face morning Delhi-Gurgaon traffic',
        bookingProviders: [
          { name: 'RedBus', url: 'https://www.redbus.in/', badge: 'Top Rated', recommended: true },
          { name: 'AbhiBus', url: 'https://www.abhibus.com/', badge: 'Cashback Offers' },
          { name: 'Zingbus Official', url: 'https://www.zingbus.com/', badge: 'Direct Discounts' }
        ]
      },
      {
        id: 'bus_intrcity_del_jai',
        mode: 'bus',
        modeLabel: 'AC Volvo / Sleeper Bus',
        modeIcon: '🚌',
        title: 'IntrCity SmartBus Volvo Club Class',
        operator: 'IntrCity SmartBus',
        badge: 'Washroom Onboard',
        route: 'IFFCO Chowk Gurgaon ➔ 200 Ft Bypass, Jaipur',
        departureTime: '11:30 PM (Overnight)',
        arrivalTime: '05:00 AM (Next Day)',
        duration: '5h 30m',
        durationHours: 5.5,
        price: 890,
        classes: ['AC Sleeper (Upper/Lower): ₹890'],
        frequency: 'Nightly',
        timeImpact: '🛌 Save a Hotel Night: Sleep during transit, wake up at 5:00 AM right on time for Hawa Mahal sunrise!',
        pros: 'In-bus clean washroom, saves hotel bill for 1 night',
        cons: 'Bumpy sleep for sensitive travelers',
        bookingProviders: [
          { name: 'RedBus', url: 'https://www.redbus.in/', badge: 'RedBus Assured', recommended: true },
          { name: 'IntrCity Official', url: 'https://www.intrcity.com/', badge: 'SmartLounge' }
        ]
      },

      // 🚗 Own Vehicle / Road Trip
      {
        id: 'car_del_jai_exp',
        mode: 'car',
        modeLabel: 'Own Vehicle (Self-Drive / Road Trip)',
        modeIcon: '🚗',
        title: 'Road Trip via NE-4 Delhi-Mumbai Expressway',
        operator: 'Self-Drive (Car / SUV / Bike)',
        badge: 'Maximum Flexibility',
        route: 'Delhi (Sohna Entry) ➔ NE-4 Expressway ➔ Dausa ➔ Jaipur',
        departureTime: 'Flexible (Recommended: 06:00 AM)',
        arrivalTime: '10:15 AM (~4h 15m)',
        duration: '4h 15m (268 km)',
        durationHours: 4.25,
        price: 2485,
        classes: ['Petrol / Diesel Cost: ~₹2,100 (15 km/l)', 'FASTag Toll Cost: ₹385'],
        frequency: 'Round-the-clock open expressway',
        timeImpact: '🚘 Pure Freedom: Stop anywhere, take scenic detours to Neemrana Fort or Chand Baori stepwell along the way.',
        pros: 'Complete control of your schedule, carry luggage with ease',
        cons: 'Driving fatigue, need to maintain 120 km/h speed limit strictly',
        pitstops: ['Highway King Dhaba', 'Mannat Expressway Waypoint', 'Starbucks & Haldiram Rest Stop (Km 92)'],
        bookingProviders: [
          { name: 'Google Maps Route', url: 'https://maps.google.com/?q=Delhi+to+Jaipur+via+NE4', badge: 'Live GPS & Traffic', recommended: true },
          { name: 'FASTag NHAI Portal', url: 'https://www.nhai.gov.in/', badge: 'Toll Estimator' }
        ]
      }
    ]
  },

  kerala: {
    origin: 'Bengaluru (BLR)',
    destination: 'Alleppey & Munnar, Kerala',
    distanceKm: 540,
    options: [
      {
        id: 'flight_blr_cok',
        mode: 'flight',
        modeLabel: 'Plane / Flight',
        modeIcon: '✈️',
        title: 'IndiGo 6E-6712 Non-Stop to Cochin (COK)',
        operator: 'IndiGo Airlines',
        badge: 'Quickest Option',
        route: 'Kempegowda T1 (BLR) ➔ Cochin Airport (COK)',
        departureTime: '07:15 AM',
        arrivalTime: '08:20 AM',
        duration: '1h 05m',
        durationHours: 1.08,
        price: 3400,
        classes: ['Economy: ₹3,400', 'Flexi: ₹4,100'],
        frequency: 'Daily (6+ flights/day)',
        timeImpact: '⚡ Instant Reach: Reach Cochin by 8:20 AM, hop into your Munnar hill cab by 9:00 AM!',
        pros: 'Bypasses 10+ hours road/rail journey',
        cons: 'Cochin to Munnar still requires 3.5h scenic ghat cab drive',
        bookingProviders: [
          { name: 'IndiGo Official', url: 'https://www.goindigo.in/', recommended: true },
          { name: 'MakeMyTrip', url: 'https://www.makemytrip.com/flights/' },
          { name: 'EaseMyTrip', url: 'https://www.easemytrip.com/' }
        ]
      },
      {
        id: 'train_vb_blr_ers',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '20641 Bengaluru - Ernakulam Vande Bharat Express',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Scenic Western Ghats Route',
        route: 'KSR Bengaluru (SBC) ➔ Ernakulam Junction (ERS)',
        departureTime: '05:30 AM',
        arrivalTime: '02:20 PM',
        duration: '8h 50m',
        durationHours: 8.83,
        price: 1540,
        classes: ['AC Chair Car (CC): ₹1,540', 'Executive Class (EC): ₹2,940'],
        frequency: '6 Days a week',
        timeImpact: '🌴 Lush Green Views: Travel past Coimbatore, Palakkad gap, and Kerala paddy fields in high comfort.',
        pros: 'Panoramic wide windows, meals served onboard',
        cons: 'Takes half a day',
        bookingProviders: [
          { name: 'IRCTC Official', url: 'https://www.irctc.co.in/nget/train-search', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/' }
        ]
      },
      {
        id: 'train_kanyakumari_16526',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '16526 Island Express (Overnight)',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Overnight Budget',
        route: 'Bengaluru Cant (BNC) ➔ Alappuzha (ALLP)',
        departureTime: '08:10 PM',
        arrivalTime: '08:45 AM (Next Day)',
        duration: '12h 35m',
        durationHours: 12.58,
        price: 490,
        classes: ['Sleeper: ₹490', '3rd AC: ₹1,340', '2nd AC: ₹1,950'],
        frequency: 'Daily',
        timeImpact: '🛶 Direct to Backwaters: Drops directly at Alleppey station right at 8:45 AM in time for houseboat check-in!',
        pros: 'Direct station at Alleppey, saves hotel night',
        cons: 'Longer duration',
        bookingProviders: [
          { name: 'IRCTC Official', url: 'https://www.irctc.co.in/nget/train-search', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/' }
        ]
      },
      {
        id: 'bus_ksrtc_airavat',
        mode: 'bus',
        modeLabel: 'AC Volvo / Sleeper Bus',
        modeIcon: '🚌',
        title: 'KSRTC Airavat Club Class Multi-Axle Volvo',
        operator: 'Karnataka / Kerala State RTC',
        badge: 'Reliable Govt Volvo',
        route: 'Shantinagar Bengaluru ➔ Munnar / Ernakulam',
        departureTime: '09:00 PM',
        arrivalTime: '07:30 AM (Next Day)',
        duration: '10h 30m',
        durationHours: 10.5,
        price: 1150,
        classes: ['Multi-Axle Semi-Sleeper: ₹1,150', 'AC Sleeper: ₹1,480'],
        frequency: 'Daily Night Service',
        timeImpact: '💤 Sleep & Wake up in Kerala: Depart after dinner, wake up to misty tea hills.',
        pros: 'Very experienced mountain drivers, comfortable suspension',
        cons: 'Winding ghat roads in last 2 hours',
        bookingProviders: [
          { name: 'RedBus', url: 'https://www.redbus.in/', recommended: true },
          { name: 'KSRTC Official Portal', url: 'https://www.ksrtc.in/' }
        ]
      },
      {
        id: 'car_blr_kerala',
        mode: 'car',
        modeLabel: 'Own Vehicle (Self-Drive / Road Trip)',
        modeIcon: '🚗',
        title: 'Road Trip via NH 44 & NH 85 Kochi-Dhanushkodi Road',
        operator: 'Self-Drive Car / SUV',
        badge: 'Epic Mountain Drive',
        route: 'Bangalore ➔ Salem ➔ Dindigul ➔ Theni ➔ Gap Road Munnar',
        departureTime: '05:00 AM',
        arrivalTime: '02:00 PM (~9h drive)',
        duration: '9h 00m (485 km)',
        durationHours: 9.0,
        price: 4350,
        classes: ['Fuel Cost: ~₹3,800', 'FASTag Tolls: ₹550'],
        frequency: 'Self Planned',
        timeImpact: '🏞️ Gap Road Spectacle: Drive on the newly widened Gap Road Munnar with sheer cliff drops and waterfalls.',
        pros: 'Total flexibility to explore hidden tea plantations and viewpoints',
        cons: '9 hours behind the wheel',
        pitstops: ['Murugan Idli Shop Salem', 'Theni Foothill Spice Stalls'],
        bookingProviders: [
          { name: 'Google Maps Route', url: 'https://maps.google.com/?q=Bangalore+to+Munnar', recommended: true }
        ]
      }
    ]
  },

  manali: {
    origin: 'New Delhi / Chandigarh',
    destination: 'Manali & Solang, Himachal',
    distanceKm: 520,
    options: [
      {
        id: 'flight_del_kullu',
        mode: 'flight',
        modeLabel: 'Plane / Flight',
        modeIcon: '✈️',
        title: 'Alliance Air 9I-805 to Kullu-Bhuntar (KUU)',
        operator: 'Alliance Air (ATR-72)',
        badge: 'Spectacular Himalayan Flight',
        route: 'Delhi T3 (DEL) ➔ Bhuntar/Kullu Airport (KUU)',
        departureTime: '06:45 AM',
        arrivalTime: '08:05 AM',
        duration: '1h 20m',
        durationHours: 1.33,
        price: 6800,
        classes: ['Economy: ₹6,800'],
        frequency: 'Daily morning flight (subject to mountain weather)',
        timeImpact: '🏔️ Fly above snow peaks, land in Kullu valley, only 1 hour taxi to Old Manali!',
        pros: 'Avoids 12 hours mountain road journey',
        cons: 'Expensive, weight restrictions on small ATR aircraft',
        bookingProviders: [
          { name: 'Alliance Air Official', url: 'https://allianceair.in/', recommended: true },
          { name: 'MakeMyTrip', url: 'https://www.makemytrip.com/flights/' }
        ]
      },
      {
        id: 'train_vb_del_chd',
        mode: 'train',
        modeLabel: 'Indian Railways (Train + Connecting Cab)',
        modeIcon: '🚆',
        title: 'Vande Bharat Express to Chandigarh + Scenic Expressway Cab',
        operator: 'IRCTC + Hill Cab',
        badge: 'Smart Hybrid Combo',
        route: 'NDLS ➔ Chandigarh (3h 15m) + 4-Lane Cab to Manali (5h 30m)',
        departureTime: '05:50 AM',
        arrivalTime: '03:30 PM',
        duration: '8h 45m combined',
        durationHours: 8.75,
        price: 2450,
        classes: ['Train CC: ₹980 + Cab Share: ~₹1,470'],
        frequency: 'Daily',
        timeImpact: '⚡ Fastest ground route: Smooth Vande Bharat breakfast, then swift drive on the new Kiratpur-Nerchowk bypass!',
        pros: 'Much less exhausting than driving from Delhi',
        cons: 'Requires 1 quick transfer at Chandigarh station',
        bookingProviders: [
          { name: 'IRCTC Official', url: 'https://www.irctc.co.in/nget/train-search', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/' }
        ]
      },
      {
        id: 'bus_hrtc_himsuta',
        mode: 'bus',
        modeLabel: 'AC Volvo / Sleeper Bus',
        modeIcon: '🚌',
        title: 'HRTC Him-Suta / Zingbus AC Volvo Multi-Axle',
        operator: 'Himachal Road Transport (HRTC) & Zingbus',
        badge: 'Classic Backpacker Choice',
        route: 'Kashmiri Gate Delhi / Majnu Ka Tila ➔ Manali Private Bus Stand',
        departureTime: '07:30 PM (Multiple night slots)',
        arrivalTime: '08:00 AM (Next Day)',
        duration: '12h 30m',
        durationHours: 12.5,
        price: 1350,
        classes: ['Semi-Sleeper Volvo: ₹1,350', 'AC Sleeper: ₹1,750'],
        frequency: '25+ buses every evening',
        timeImpact: '💤 Classic Overnight Rite of Passage: Board at night in Delhi, wake up surrounded by towering pine trees in Manali.',
        pros: 'High frequency, economical, saves night accommodation cost',
        cons: 'Long winding night journey',
        bookingProviders: [
          { name: 'RedBus', url: 'https://www.redbus.in/', recommended: true },
          { name: 'HRTC Official', url: 'https://www.hrtchp.com/' },
          { name: 'Zingbus', url: 'https://www.zingbus.com/' }
        ]
      },
      {
        id: 'car_del_manali_exp',
        mode: 'car',
        modeLabel: 'Own Vehicle (Self-Drive / Road Trip)',
        modeIcon: '🚗',
        title: 'Road Trip via New Kiratpur-Nerchowk Himalayan 4-Lane Highway',
        operator: 'Self-Drive Car / 4x4 / Royal Enfield',
        badge: 'Scenic Mountain Drive',
        route: 'Delhi ➔ Ambala ➔ Kiratpur ➔ Mandi ➔ Pandoh Dam ➔ Aut Tunnel ➔ Manali',
        departureTime: '04:00 AM',
        arrivalTime: '04:00 PM (~11-12h with breaks)',
        duration: '11h 30m (520 km)',
        durationHours: 11.5,
        price: 4800,
        classes: ['Fuel: ~₹4,100', 'Tolls: ₹700'],
        frequency: 'Self Driven',
        timeImpact: '🏔️ Complete Freedom: Drive past cascading Beas river, stop at Pandoh dam, and cross Atal Tunnel at your own pace.',
        pros: 'Having your own vehicle in Manali saves thousands on local Solang & Sissu taxi unions',
        cons: 'Challenging mountain hairpins, landslides during peak monsoon',
        pitstops: ['Amrik Sukhdev Murthal (Parathas)', 'Zimidara Dhaba Bharatgarh'],
        bookingProviders: [
          { name: 'Google Maps Route', url: 'https://maps.google.com/?q=Delhi+to+Manali+via+Kiratpur', recommended: true }
        ]
      }
    ]
  },

  goa: {
    origin: 'Mumbai / Pune / Delhi / Bengaluru',
    destination: 'Goa (North & South)',
    distanceKm: 580,
    options: [
      {
        id: 'flight_bom_goa',
        mode: 'flight',
        modeLabel: 'Plane / Flight',
        modeIcon: '✈️',
        title: 'IndiGo / Akasa Air Non-Stop to Manohar Mopa Airport (GOX)',
        operator: 'IndiGo / Akasa Air',
        badge: '1 Hour Beach Hopper',
        route: 'Mumbai T2 (BOM) ➔ Mopa North Goa (GOX)',
        departureTime: '08:30 AM',
        arrivalTime: '09:40 AM',
        duration: '1h 10m',
        durationHours: 1.17,
        price: 2950,
        classes: ['Economy: ₹2,950', 'Flexi: ₹3,650'],
        frequency: '12+ flights daily',
        timeImpact: '🏖️ Land at 9:40 AM: Grab a cold coconut and be on Morjim / Vagator beach before lunch!',
        pros: 'Extremely fast, low fares on Mumbai/Bangalore route',
        cons: 'Mopa airport is in extreme North Goa; cab to South Goa takes 1.5h',
        bookingProviders: [
          { name: 'IndiGo Official', url: 'https://www.goindigo.in/', recommended: true },
          { name: 'MakeMyTrip', url: 'https://www.makemytrip.com/flights/' },
          { name: 'EaseMyTrip', url: 'https://www.easemytrip.com/' }
        ]
      },
      {
        id: 'train_tejas_22119',
        mode: 'train',
        modeLabel: 'Indian Railways (Train)',
        modeIcon: '🚆',
        title: '22119 Mumbai CSMT - Madgaon Tejas / Vande Bharat Express',
        operator: 'Indian Railways (IRCTC)',
        badge: 'Konkan Railway Masterpiece',
        route: 'CSMT Mumbai ➔ Madgaon (MAO) / Karmali',
        departureTime: '05:50 AM',
        arrivalTime: '02:00 PM',
        duration: '8h 10m',
        durationHours: 8.17,
        price: 1680,
        classes: ['AC Chair Car: ₹1,680', 'Executive: ₹3,120'],
        frequency: 'Daily except Mondays',
        timeImpact: '🌉 Konkan Railway Wonder: Cross over 2,000 bridges, tunnels, and Sahyadri waterfalls while enjoying hot food.',
        pros: 'One of India’s most scenic railway routes, punctual',
        cons: 'Daytime journey takes 8 hours',
        bookingProviders: [
          { name: 'IRCTC Official', url: 'https://www.irctc.co.in/nget/train-search', recommended: true },
          { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/' }
        ]
      },
      {
        id: 'bus_kadamba_sleeper',
        mode: 'bus',
        modeLabel: 'AC Volvo / Sleeper Bus',
        modeIcon: '🚌',
        title: 'Kadamba / IntrCity Multi-Axle AC Sleeper',
        operator: 'Kadamba Transport / IntrCity',
        badge: 'Overnight Sleeper',
        route: 'Borivali / Vashi Mumbai ➔ Mapusa / Panaji, Goa',
        departureTime: '08:00 PM',
        arrivalTime: '07:30 AM (Next Day)',
        duration: '11h 30m',
        durationHours: 11.5,
        price: 1100,
        classes: ['AC Single Sleeper: ₹1,100', 'Double Sleeper: ₹1,950'],
        frequency: 'Nightly',
        timeImpact: '🍻 Party Ready: Fall asleep in Mumbai/Pune, wake up in sunny Panaji ready for breakfast at a Latin bakery.',
        pros: 'Affordable, easy boarding points in suburbs',
        cons: 'Traffic near border checkpoints',
        bookingProviders: [
          { name: 'RedBus', url: 'https://www.redbus.in/', recommended: true },
          { name: 'AbhiBus', url: 'https://www.abhibus.com/' }
        ]
      },
      {
        id: 'car_mumbai_goa_nh66',
        mode: 'car',
        modeLabel: 'Own Vehicle (Self-Drive / Road Trip)',
        modeIcon: '🚗',
        title: 'Road Trip via NH 66 Mumbai-Goa Coastal Highway',
        operator: 'Self-Drive Car / Thar / Royal Enfield',
        badge: 'Iconic Dil Chahta Hai Road Trip',
        route: 'Mumbai ➔ Panvel ➔ Chiplun ➔ Ratnagiri ➔ Kankavli ➔ North Goa',
        departureTime: '05:00 AM',
        arrivalTime: '05:30 PM (~11-12h)',
        duration: '11h 30m (570 km)',
        durationHours: 11.5,
        price: 4900,
        classes: ['Fuel: ~₹4,300', 'FASTag Tolls: ₹600'],
        frequency: 'Self Scheduled',
        timeImpact: '🌴 Coastal Ghat vistas: Stop for authentic Konkani fish thali and Alphonso mangoes in Ratnagiri.',
        pros: 'Freedom to take off to secret secluded beaches along South Goa',
        cons: 'Full day drive',
        pitstops: ['Abhishek Hotel Chiplun', 'Hotel Open Umbrella Khed'],
        bookingProviders: [
          { name: 'Google Maps Route', url: 'https://maps.google.com/?q=Mumbai+to+Goa+via+NH66', recommended: true }
        ]
      }
    ]
  }
};

/**
 * Comprehensive Indian Travel Hubs Mapping
 */
const MAJOR_TRAVEL_HUBS = {
  bengaluru: { name: 'Bengaluru', airport: 'Kempegowda T1/T2 (BLR)', iata: 'BLR', station: 'KSR Bengaluru (SBC)', state: 'Karnataka', lat: 12.9716, lon: 77.5946 },
  bangalore: { name: 'Bengaluru', airport: 'Kempegowda T1/T2 (BLR)', iata: 'BLR', station: 'KSR Bengaluru (SBC)', state: 'Karnataka', lat: 12.9716, lon: 77.5946 },
  mumbai: { name: 'Mumbai', airport: 'Chhatrapati Shivaji Maharaj T2 (BOM)', iata: 'BOM', station: 'Mumbai Central / CSMT', state: 'Maharashtra', lat: 19.0760, lon: 72.8777 },
  delhi: { name: 'New Delhi', airport: 'Indira Gandhi T3 (DEL)', iata: 'DEL', station: 'New Delhi (NDLS)', state: 'Delhi (NCT)', lat: 28.6139, lon: 77.2090 },
  hyderabad: { name: 'Hyderabad', airport: 'Rajiv Gandhi International (HYD)', iata: 'HYD', station: 'Secunderabad Jn (SC)', state: 'Telangana', lat: 17.3850, lon: 78.4867 },
  chennai: { name: 'Chennai', airport: 'Chennai International (MAA)', iata: 'MAA', station: 'Chennai Central (MAS)', state: 'Tamil Nadu', lat: 13.0827, lon: 80.2707 },
  kolkata: { name: 'Kolkata', airport: 'Netaji Subhash Chandra Bose (CCU)', iata: 'CCU', station: 'Howrah Jn (HWH)', state: 'West Bengal', lat: 22.5726, lon: 88.3639 },
  pune: { name: 'Pune', airport: 'Pune International (PNQ)', iata: 'PNQ', station: 'Pune Junction (PUNE)', state: 'Maharashtra', lat: 18.5204, lon: 73.8567 },
  ahmedabad: { name: 'Ahmedabad', airport: 'Sardar Vallabhbhai Patel (AMD)', iata: 'AMD', station: 'Ahmedabad Jn (ADI)', state: 'Gujarat', lat: 23.0225, lon: 72.5714 },
  jaipur: { name: 'Jaipur', airport: 'Jaipur International (JAI)', iata: 'JAI', station: 'Jaipur Junction (JP)', state: 'Rajasthan', lat: 26.9124, lon: 75.7873 },
  lucknow: { name: 'Lucknow', airport: 'Chaudhary Charan Singh (LKO)', iata: 'LKO', station: 'Lucknow Charbagh (LKO)', state: 'Uttar Pradesh', lat: 26.8467, lon: 80.9462 },
  chandigarh: { name: 'Chandigarh', airport: 'Shaheed Bhagat Singh (IXC)', iata: 'IXC', station: 'Chandigarh Junction (CDG)', state: 'Punjab & Haryana', lat: 30.7333, lon: 76.7794 },
  kochi: { name: 'Kochi', airport: 'Cochin International (COK)', iata: 'COK', station: 'Ernakulam Jn (ERS)', state: 'Kerala', lat: 9.9312, lon: 76.2673 },
  cochin: { name: 'Kochi', airport: 'Cochin International (COK)', iata: 'COK', station: 'Ernakulam Jn (ERS)', state: 'Kerala', lat: 9.9312, lon: 76.2673 },
  goa: { name: 'Goa', airport: 'Dabolim / Manohar Mopa (GOI/GOX)', iata: 'GOI', station: 'Madgaon Junction (MAO)', state: 'Goa', lat: 15.2993, lon: 74.1240 },
  manali: { name: 'Manali', airport: 'Kullu-Bhuntar (KUU)', iata: 'KUU', station: 'Chandigarh Jn (CDG)', state: 'Himachal Pradesh', lat: 32.2432, lon: 77.1892 },
  varanasi: { name: 'Varanasi', airport: 'Lal Bahadur Shastri (VNS)', iata: 'VNS', station: 'Varanasi Junction (BSB)', state: 'Uttar Pradesh', lat: 25.3176, lon: 82.9739 },
  ladakh: { name: 'Leh-Ladakh', airport: 'Kushok Bakula Rimpochee (IXL)', iata: 'IXL', station: 'Jammu Tawi (JAT)', state: 'Ladakh', lat: 34.1526, lon: 77.5771 },
  udaipur: { name: 'Udaipur', airport: 'Maharana Pratap (UDR)', iata: 'UDR', station: 'Udaipur City (UDZ)', state: 'Rajasthan', lat: 24.5854, lon: 73.7125 },
  rishikesh: { name: 'Rishikesh', airport: 'Dehradun Jolly Grant (DED)', iata: 'DED', station: 'Yog Nagari Rishikesh (YNRK)', state: 'Uttarakhand', lat: 30.0869, lon: 78.2676 },
  ooty: { name: 'Ooty', airport: 'Coimbatore International (CJB)', iata: 'CJB', station: 'Mettupalayam (MTP)', state: 'Tamil Nadu', lat: 11.4102, lon: 76.6950 },
  hampi: { name: 'Hampi', airport: 'Jindal Vidyanagar (VDY)', iata: 'VDY', station: 'Hosapete Junction (HPT)', state: 'Karnataka', lat: 15.3350, lon: 76.4600 },
  darjeeling: { name: 'Darjeeling', airport: 'Bagdogra Airport (IXB)', iata: 'IXB', station: 'New Jalpaiguri (NJP)', state: 'West Bengal', lat: 27.0410, lon: 88.2663 },
  andaman: { name: 'Port Blair', airport: 'Veer Savarkar (IXZ)', iata: 'IXZ', station: 'Port Blair Jetty', state: 'Andaman', lat: 11.6234, lon: 92.7265 }
};

function resolveLocationHub(str) {
  if (!str) return MAJOR_TRAVEL_HUBS.delhi;
  const s = str.toLowerCase();

  for (const [key, hub] of Object.entries(MAJOR_TRAVEL_HUBS)) {
    if (s.includes(key) || s.includes(hub.name.toLowerCase()) || s.includes(hub.iata.toLowerCase())) {
      return hub;
    }
  }

  if (typeof INDIAN_DISTRICTS_COORDINATES !== 'undefined') {
    const match = INDIAN_DISTRICTS_COORDINATES.find(c =>
      s.includes(c.district.toLowerCase()) || s.includes(c.state.toLowerCase())
    );
    if (match) {
      return {
        name: match.district,
        airport: match.hub,
        iata: (match.hub.match(/\(([A-Z]{3})\)/) || [])[1] || 'HUB',
        station: `${match.district} Junction`,
        state: match.state,
        lat: match.lat,
        lon: match.lon
      };
    }
  }

  return {
    name: str.split(',')[0].trim(),
    airport: `${str.split(',')[0]} Airport`,
    iata: 'ORIGIN',
    station: `${str.split(',')[0]} Railway Station`,
    state: 'India',
    lat: 28.6139,
    lon: 77.2090
  };
}

function calcHaversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 1.22);
}

/**
 * Dynamically builds accurate real transport options from the user's origin to their chosen destination
 */
function buildDynamicTransportOptions(originStr, destStr, destKey) {
  const oHub = resolveLocationHub(originStr);
  const dHub = resolveLocationHub(destStr || destKey);

  const distanceKm = Math.max(120, calcHaversineKm(oHub.lat, oHub.lon, dHub.lat, dHub.lon));

  // Flight duration & price
  const flightHours = Number((Math.max(0.85, (distanceKm * 0.0013) + 0.45)).toFixed(2));
  const flightMinsTotal = Math.round(flightHours * 60);
  const flightHoursDisp = Math.floor(flightMinsTotal / 60);
  const flightMinsDisp = flightMinsTotal % 60;
  const flightDuration = flightHoursDisp > 0 ? `${flightHoursDisp}h ${flightMinsDisp}m` : `${flightMinsDisp} mins`;
  const flightPrice = Math.round(2800 + (distanceKm * 1.85));

  // Train duration & price
  const isVandeBharat = distanceKm <= 750;
  const trainSpeed = isVandeBharat ? 90 : 70;
  const trainHours = Number((Math.max(2.5, distanceKm / trainSpeed)).toFixed(2));
  const trainMinsTotal = Math.round(trainHours * 60);
  const trainHoursDisp = Math.floor(trainMinsTotal / 60);
  const trainMinsDisp = trainMinsTotal % 60;
  const trainDuration = `${trainHoursDisp}h ${trainMinsDisp}m`;
  const trainPrice = Math.round(Math.max(450, isVandeBharat ? 750 + (distanceKm * 1.35) : 550 + (distanceKm * 0.95)));

  // Bus duration & price
  const busHours = Number((distanceKm / 48).toFixed(2));
  const busMinsTotal = Math.round(busHours * 60);
  const busDuration = `${Math.floor(busMinsTotal / 60)}h ${busMinsTotal % 60}m`;
  const busPrice = Math.round(Math.max(400, 350 + (distanceKm * 0.9)));

  // Cab / Drive duration & price
  const driveHours = Number((distanceKm / 58).toFixed(2));
  const driveMinsTotal = Math.round(driveHours * 60);
  const driveDuration = `${Math.floor(driveMinsTotal / 60)}h ${driveMinsTotal % 60}m`;
  const cabFuel = Math.round(distanceKm * 7.5);
  const cabToll = Math.round(distanceKm * 1.35);
  const cabPrice = cabFuel + cabToll;

  const destClean = dHub.name || destStr;
  const origClean = oHub.name || originStr;

  const options = [
    // ✈️ Flight Option
    {
      id: `dyn_flight_${oHub.iata}_${dHub.iata}`.toLowerCase(),
      mode: 'flight',
      modeLabel: 'Plane / Flight',
      modeIcon: '✈️',
      title: `IndiGo / Air India Direct (${origClean} to ${destClean})`,
      operator: 'IndiGo & Air India',
      badge: 'Fastest Transit',
      route: `${oHub.airport} ➔ ${dHub.airport}`,
      departureTime: '07:15 AM',
      arrivalTime: '09:20 AM',
      duration: flightDuration,
      durationHours: flightHours,
      price: flightPrice,
      classes: [`Economy: ₹${flightPrice.toLocaleString('en-IN')}`, `Flexi / Premium: ₹${Math.round(flightPrice * 1.3).toLocaleString('en-IN')}`],
      frequency: 'Daily Direct & 1-Stop Connections',
      timeImpact: `⚡ Direct connection: Lands in ${flightDuration} from ${origClean}. Maximize your stay in ${destClean}!`,
      pros: 'Shortest travel time, zero fatigue',
      cons: 'Need to reach airport 1.5h in advance',
      bookingProviders: [
        { name: 'IndiGo Official', url: `https://www.goindigo.in/`, badge: 'Official', recommended: true },
        { name: 'MakeMyTrip', url: `https://www.makemytrip.com/flights/`, badge: 'Best Fares' },
        { name: 'EaseMyTrip', url: `https://www.easemytrip.com/`, badge: 'Zero Conv. Fee' }
      ]
    },

    // 🚆 Train Option
    {
      id: `dyn_train_${oHub.iata}_${dHub.iata}`.toLowerCase(),
      mode: 'train',
      modeLabel: 'Train / Rail',
      modeIcon: '🚆',
      title: isVandeBharat ? `Vande Bharat Express (${origClean} ➔ ${destClean})` : `Rajdhani / Superfast Express (${origClean} ➔ ${destClean})`,
      operator: 'Indian Railways (IRCTC)',
      badge: isVandeBharat ? 'Semi-High Speed Rail' : 'Superfast Express',
      route: `${oHub.station} ➔ ${dHub.station}`,
      departureTime: isVandeBharat ? '06:00 AM' : '05:30 PM',
      arrivalTime: isVandeBharat ? '01:45 PM' : '09:15 AM',
      duration: trainDuration,
      durationHours: trainHours,
      price: trainPrice,
      classes: isVandeBharat ? ['Chair Car (CC): ₹' + trainPrice, 'Executive (EC): ₹' + Math.round(trainPrice * 1.8)] : ['3rd AC (3A): ₹' + trainPrice, '2nd AC (2A): ₹' + Math.round(trainPrice * 1.5)],
      frequency: 'Daily (Confirmed Booking Available)',
      timeImpact: isVandeBharat ? 'Scenic daytime journey with hot meals served onboard.' : 'Overnight sleeper: Sleep on train, wake up refreshed at your destination!',
      pros: 'Central city-to-city drop, generous baggage allowance, scenic Indian landscape',
      cons: 'Book 15-30 days in advance for confirmed berth',
      bookingProviders: [
        { name: 'IRCTC Official', url: 'https://www.irctc.co.in/', badge: 'Official Portal', recommended: true },
        { name: 'ConfirmTkt', url: 'https://www.confirmtkt.com/', badge: 'Waitlist Predictor' },
        { name: 'MakeMyTrip Trains', url: 'https://www.makemytrip.com/railways/', badge: 'Tatkal Assist' }
      ]
    },

    // 🚌 Bus Option (for distance <= 1100 km)
    ...(distanceKm <= 1100 ? [{
      id: `dyn_bus_${oHub.iata}_${dHub.iata}`.toLowerCase(),
      mode: 'bus',
      modeLabel: 'AC Sleeper Bus',
      modeIcon: '🚌',
      title: `IntrCity SmartBus / Zingbus Multi-Axle AC Sleeper`,
      operator: 'IntrCity / Zingbus / State RTC',
      badge: 'Budget Friendly',
      route: `${origClean} Boarding Point ➔ ${destClean} Private Bus Stand`,
      departureTime: '08:30 PM',
      arrivalTime: '07:45 AM',
      duration: busDuration,
      durationHours: busHours,
      price: busPrice,
      classes: ['Single AC Sleeper: ₹' + busPrice, 'Couple Lower Berth: ₹' + Math.round(busPrice * 1.15)],
      frequency: 'Every evening starting 7:30 PM',
      timeImpact: 'Overnight transit saves 1 night hotel expense. Wake up directly in destination.',
      pros: 'Convenient city center boarding, zero baggage weight restrictions',
      cons: 'Subject to highway traffic',
      bookingProviders: [
        { name: 'RedBus', url: 'https://www.redbus.in/', badge: 'Official', recommended: true },
        { name: 'AbhiBus', url: 'https://www.abhibus.com/', badge: 'Live Bus Tracking' }
      ]
    }] : []),

    // 🚗 Road / Cab Option
    {
      id: `dyn_car_${oHub.iata}_${dHub.iata}`.toLowerCase(),
      mode: 'car',
      modeLabel: 'Outstation Cab / Self Drive',
      modeIcon: '🚗',
      title: `Outstation AC Cab / Self-Drive Road Trip`,
      operator: 'MakeMyTrip Cabs / Savaari / Self-Drive',
      badge: distanceKm <= 400 ? 'Ideal Road Trip' : 'Scenic Highway Corridor',
      route: `via National Highway (${origClean} to ${destClean})`,
      departureTime: 'Flexible (Your Choice)',
      arrivalTime: `+${driveDuration}`,
      duration: driveDuration,
      durationHours: driveHours,
      price: cabPrice,
      classes: [`Estimated Fuel: ₹${cabFuel.toLocaleString('en-IN')}`, `FASTag Toll: ₹${cabToll.toLocaleString('en-IN')}`],
      frequency: 'On-Demand 24x7 Doorstep Pickup',
      timeImpact: 'Freedom to stop at dhabas, scenic ghat viewpoints, and village crafts bazaars along the route.',
      pros: 'Door-to-door comfort, stop anytime, no strict schedule',
      cons: distanceKm > 600 ? 'Long driving hours, driver night allowance required' : 'Highway toll charges',
      bookingProviders: [
        { name: 'MakeMyTrip Cabs', url: 'https://www.makemytrip.com/cabs/', recommended: true },
        { name: 'Savaari Car Rentals', url: 'https://www.savaari.com/', badge: 'Verified Drivers' }
      ]
    }
  ];

  return {
    origin: origClean,
    destination: destClean,
    distanceKm,
    options
  };
}

/**
 * Filter and retrieve transport options based on mode, budget, time, and priority (money vs time)
 * Dynamically tailored from user's origin location to destination
 */
function getFilteredTransportOptions(destinationKey, modeFilter = 'all', maxBudget = null, maxHours = null, priority = 'none', userOrigin = null, userDest = null) {
  let data;

  // If user has a specific origin or destination, dynamically generate routes from their exact location!
  if (userOrigin && userOrigin.trim()) {
    data = buildDynamicTransportOptions(userOrigin, userDest || destinationKey, destinationKey);
  } else if (TRANSPORT_DATABASE[destinationKey]) {
    data = TRANSPORT_DATABASE[destinationKey];
  } else {
    data = buildDynamicTransportOptions('My Location', userDest || destinationKey || 'Jaipur', destinationKey);
  }

  let options = [...data.options];

  if (modeFilter && modeFilter !== 'all') {
    options = options.filter(o => o.mode === modeFilter);
  }

  if (maxBudget !== null && maxBudget !== undefined && !isNaN(maxBudget) && maxBudget > 0) {
    options = options.filter(o => o.price <= maxBudget);
  }

  if (maxHours !== null && maxHours !== undefined && !isNaN(maxHours) && maxHours > 0) {
    options = options.filter(o => o.durationHours <= maxHours);
  }

  // Handle priority filter:
  // 'money': display cheaper transportation facility first (lowest fare first)
  // 'time': display short time transportation facility first (shortest duration first)
  if (priority === 'money') {
    options.sort((a, b) => a.price - b.price);
  } else if (priority === 'time') {
    options.sort((a, b) => a.durationHours - b.durationHours);
  }

  const allPrices = data.options.map(o => o.price);
  const minAvailablePrice = allPrices.length ? Math.min(...allPrices) : 0;
  const minAvailableDuration = data.options.length ? Math.min(...data.options.map(o => o.durationHours)) : 0;

  return {
    origin: data.origin,
    destination: data.destination,
    distanceKm: data.distanceKm,
    options,
    minAvailablePrice,
    minAvailableDuration,
    totalAvailable: data.options.length,
    matchedCount: options.length
  };
}
