/**
 * BharatYatra AI - Indian Districts Geo Engine (indian-districts-geo.js)
 * Live Location Detection, Nearest District Finder, and Inter-State Travel Matrix.
 */

// Comprehensive Coordinates of Indian Districts, Capitals & Major Travel Hubs
const INDIAN_DISTRICTS_COORDINATES = [
  // Delhi NCR
  { district: "Central Delhi", state: "Delhi (NCT)", hub: "New Delhi (DEL)", lat: 28.6139, lon: 77.2090, zone: "North" },
  { district: "South Delhi", state: "Delhi (NCT)", hub: "Delhi (DEL)", lat: 28.5355, lon: 77.2100, zone: "North" },
  { district: "Gautam Buddha Nagar", state: "Uttar Pradesh", hub: "Noida / Jewar (DEL)", lat: 28.5355, lon: 77.3910, zone: "North" },
  { district: "Gurugram", state: "Haryana", hub: "Gurugram (DEL)", lat: 28.4595, lon: 77.0266, zone: "North" },
  { district: "Faridabad", state: "Haryana", hub: "Faridabad (DEL)", lat: 28.4089, lon: 77.3178, zone: "North" },
  { district: "Ghaziabad", state: "Uttar Pradesh", hub: "Ghaziabad (DEL)", lat: 28.6692, lon: 77.4538, zone: "North" },

  // Karnataka
  { district: "Bengaluru Urban", state: "Karnataka", hub: "Bengaluru (BLR)", lat: 12.9716, lon: 77.5946, zone: "South" },
  { district: "Bengaluru Rural", state: "Karnataka", hub: "Bengaluru (BLR)", lat: 13.2847, lon: 77.5510, zone: "South" },
  { district: "Mysuru", state: "Karnataka", hub: "Mysuru (MYQ)", lat: 12.2958, lon: 76.6394, zone: "South" },
  { district: "Dakshina Kannada", state: "Karnataka", hub: "Mangaluru (IXE)", lat: 12.9141, lon: 74.8560, zone: "South" },
  { district: "Kodagu", state: "Karnataka", hub: "Madikeri / Coorg (MYQ)", lat: 12.3375, lon: 75.8069, zone: "South" },
  { district: "Dharwad", state: "Karnataka", hub: "Hubballi-Dharwad (HBX)", lat: 15.4589, lon: 75.0078, zone: "South" },
  { district: "Belagavi", state: "Karnataka", hub: "Belagavi (IXG)", lat: 15.8497, lon: 74.4977, zone: "South" },
  { district: "Vijayanagara", state: "Karnataka", hub: "Hosapete / Hampi (VDY)", lat: 15.3350, lon: 76.4600, zone: "South" },
  { district: "Uttara Kannada", state: "Karnataka", hub: "Gokarna / Karwar (GOI)", lat: 14.8080, lon: 74.1306, zone: "South" },
  { district: "Chikkamagaluru", state: "Karnataka", hub: "Chikkamagaluru (BLR)", lat: 13.3161, lon: 75.7720, zone: "South" },

  // Maharashtra
  { district: "Mumbai City", state: "Maharashtra", hub: "Mumbai (BOM)", lat: 18.9220, lon: 72.8347, zone: "West" },
  { district: "Mumbai Suburban", state: "Maharashtra", hub: "Mumbai (BOM)", lat: 19.0760, lon: 72.8777, zone: "West" },
  { district: "Thane", state: "Maharashtra", hub: "Thane (BOM)", lat: 19.2183, lon: 72.9781, zone: "West" },
  { district: "Pune", state: "Maharashtra", hub: "Pune (PNQ)", lat: 18.5204, lon: 73.8567, zone: "West" },
  { district: "Nagpur", state: "Maharashtra", hub: "Nagpur (NAG)", lat: 21.1458, lon: 79.0882, zone: "West" },
  { district: "Nashik", state: "Maharashtra", hub: "Nashik (ISK)", lat: 19.9975, lon: 73.7898, zone: "West" },
  { district: "Chhatrapati Sambhajinagar", state: "Maharashtra", hub: "Aurangabad (IXU)", lat: 19.8762, lon: 75.3433, zone: "West" },
  { district: "Satara", state: "Maharashtra", hub: "Mahabaleshwar / Satara (PNQ)", lat: 17.6805, lon: 73.9903, zone: "West" },
  { district: "Sindhudurg", state: "Maharashtra", hub: "Tarkarli / Chipi (SDW)", lat: 16.0240, lon: 73.4735, zone: "West" },
  { district: "Raigad", state: "Maharashtra", hub: "Alibaug (BOM)", lat: 18.6579, lon: 72.8789, zone: "West" },
  { district: "Kolhapur", state: "Maharashtra", hub: "Kolhapur (KLH)", lat: 16.7050, lon: 74.2433, zone: "West" },

  // Tamil Nadu
  { district: "Chennai", state: "Tamil Nadu", hub: "Chennai (MAA)", lat: 13.0827, lon: 80.2707, zone: "South" },
  { district: "Coimbatore", state: "Tamil Nadu", hub: "Coimbatore (CJB)", lat: 11.0168, lon: 76.9558, zone: "South" },
  { district: "Madurai", state: "Tamil Nadu", hub: "Madurai (IXM)", lat: 9.9252, lon: 78.1198, zone: "South" },
  { district: "Tiruchirappalli", state: "Tamil Nadu", hub: "Trichy (TRZ)", lat: 10.7905, lon: 78.7047, zone: "South" },
  { district: "Nilgiris", state: "Tamil Nadu", hub: "Ooty (CJB)", lat: 11.4102, lon: 76.6950, zone: "South" },
  { district: "Kanyakumari", state: "Tamil Nadu", hub: "Kanyakumari (TRV)", lat: 8.0883, lon: 77.5385, zone: "South" },
  { district: "Ramanathapuram", state: "Tamil Nadu", hub: "Rameswaram (IXM)", lat: 9.2876, lon: 79.3129, zone: "South" },
  { district: "Thanjavur", state: "Tamil Nadu", hub: "Thanjavur (TRZ)", lat: 10.7870, lon: 79.1378, zone: "South" },
  { district: "Chengalpattu", state: "Tamil Nadu", hub: "Mahabalipuram (MAA)", lat: 12.6841, lon: 79.9836, zone: "South" },
  { district: "Salem", state: "Tamil Nadu", hub: "Salem (SXV)", lat: 11.6643, lon: 78.1460, zone: "South" },

  // Telangana
  { district: "Hyderabad", state: "Telangana", hub: "Hyderabad (HYD)", lat: 17.3850, lon: 78.4867, zone: "South" },
  { district: "Medchal-Malkajgiri", state: "Telangana", hub: "Secunderabad (HYD)", lat: 17.6297, lon: 78.4814, zone: "South" },
  { district: "Ranga Reddy", state: "Telangana", hub: "Hyderabad Outer (HYD)", lat: 17.3297, lon: 78.5822, zone: "South" },
  { district: "Hanumakonda", state: "Telangana", hub: "Warangal (HYD)", lat: 17.9689, lon: 79.5941, zone: "South" },
  { district: "Nizamabad", state: "Telangana", hub: "Nizamabad (HYD)", lat: 18.6725, lon: 78.0941, zone: "South" },
  { district: "Mulugu", state: "Telangana", hub: "Ramappa (HYD)", lat: 18.1911, lon: 79.9392, zone: "South" },

  // Andhra Pradesh
  { district: "Visakhapatnam", state: "Andhra Pradesh", hub: "Visakhapatnam (VTZ)", lat: 17.6868, lon: 83.2185, zone: "South" },
  { district: "NTR", state: "Andhra Pradesh", hub: "Vijayawada (VGA)", lat: 16.5062, lon: 80.6480, zone: "South" },
  { district: "Guntur", state: "Andhra Pradesh", hub: "Amaravati / Guntur (VGA)", lat: 16.3067, lon: 80.4365, zone: "South" },
  { district: "Tirupati", state: "Andhra Pradesh", hub: "Tirupati (TIR)", lat: 13.6288, lon: 79.4192, zone: "South" },
  { district: "Alluri Sitharama Raju", state: "Andhra Pradesh", hub: "Araku Valley (VTZ)", lat: 18.3333, lon: 82.8833, zone: "South" },
  { district: "Kurnool", state: "Andhra Pradesh", hub: "Kurnool (KJB)", lat: 15.8281, lon: 78.0373, zone: "South" },
  { district: "East Godavari", state: "Andhra Pradesh", hub: "Rajahmundry (RJA)", lat: 17.0005, lon: 81.8040, zone: "South" },

  // Kerala
  { district: "Thiruvananthapuram", state: "Kerala", hub: "Trivandrum (TRV)", lat: 8.5241, lon: 76.9366, zone: "South" },
  { district: "Ernakulam", state: "Kerala", hub: "Kochi (COK)", lat: 9.9312, lon: 76.2673, zone: "South" },
  { district: "Idukki", state: "Kerala", hub: "Munnar (COK)", lat: 10.0889, lon: 77.0595, zone: "South" },
  { district: "Alappuzha", state: "Kerala", hub: "Alleppey (COK)", lat: 9.4981, lon: 76.3388, zone: "South" },
  { district: "Kozhikode", state: "Kerala", hub: "Calicut (CCJ)", lat: 11.2588, lon: 75.7804, zone: "South" },
  { district: "Wayanad", state: "Kerala", hub: "Wayanad (CCJ)", lat: 11.6854, lon: 76.1320, zone: "South" },
  { district: "Thrissur", state: "Kerala", hub: "Thrissur (COK)", lat: 10.5276, lon: 76.2144, zone: "South" },
  { district: "Kannur", state: "Kerala", hub: "Kannur (CNN)", lat: 11.8745, lon: 75.3704, zone: "South" },

  // Gujarat
  { district: "Ahmedabad", state: "Gujarat", hub: "Ahmedabad (AMD)", lat: 23.0225, lon: 72.5714, zone: "West" },
  { district: "Gandhinagar", state: "Gujarat", hub: "Gandhinagar (AMD)", lat: 23.2156, lon: 72.6369, zone: "West" },
  { district: "Surat", state: "Gujarat", hub: "Surat (STV)", lat: 21.1702, lon: 72.8311, zone: "West" },
  { district: "Vadodara", state: "Gujarat", hub: "Vadodara (BDQ)", lat: 22.3072, lon: 73.1812, zone: "West" },
  { district: "Kutch", state: "Gujarat", hub: "Bhuj / White Rann (BHJ)", lat: 23.2420, lon: 69.6669, zone: "West" },
  { district: "Gir Somnath", state: "Gujarat", hub: "Gir / Somnath (DIU)", lat: 20.9042, lon: 70.3676, zone: "West" },
  { district: "Devbhumi Dwarka", state: "Gujarat", hub: "Dwarka (JGA)", lat: 22.2442, lon: 68.9685, zone: "West" },
  { district: "Rajkot", state: "Gujarat", hub: "Rajkot (HSR)", lat: 22.3039, lon: 70.8022, zone: "West" },
  { district: "Narmada", state: "Gujarat", hub: "Statue of Unity (BDQ)", lat: 21.8380, lon: 73.7191, zone: "West" },

  // Rajasthan
  { district: "Jaipur", state: "Rajasthan", hub: "Jaipur (JAI)", lat: 26.9124, lon: 75.7873, zone: "West" },
  { district: "Udaipur", state: "Rajasthan", hub: "Udaipur (UDR)", lat: 24.5854, lon: 73.7125, zone: "West" },
  { district: "Jodhpur", state: "Rajasthan", hub: "Jodhpur (JDH)", lat: 26.2389, lon: 73.0243, zone: "West" },
  { district: "Jaisalmer", state: "Rajasthan", hub: "Jaisalmer (JSA)", lat: 26.9157, lon: 70.9083, zone: "West" },
  { district: "Sawai Madhopur", state: "Rajasthan", hub: "Ranthambore (JAI)", lat: 25.9928, lon: 76.3526, zone: "West" },
  { district: "Ajmer", state: "Rajasthan", hub: "Pushkar / Ajmer (KQH)", lat: 26.4499, lon: 74.6399, zone: "West" },
  { district: "Bikaner", state: "Rajasthan", hub: "Bikaner (BKB)", lat: 28.0229, lon: 73.3119, zone: "West" },
  { district: "Sirohi", state: "Rajasthan", hub: "Mount Abu (UDR)", lat: 24.5926, lon: 72.7156, zone: "West" },
  { district: "Chittorgarh", state: "Rajasthan", hub: "Chittorgarh (UDR)", lat: 24.8887, lon: 74.6269, zone: "West" },

  // Uttar Pradesh
  { district: "Lucknow", state: "Uttar Pradesh", hub: "Lucknow (LKO)", lat: 26.8467, lon: 80.9462, zone: "North" },
  { district: "Varanasi", state: "Uttar Pradesh", hub: "Varanasi (VNS)", lat: 25.3176, lon: 82.9739, zone: "North" },
  { district: "Agra", state: "Uttar Pradesh", hub: "Agra (AGR)", lat: 27.1767, lon: 78.0081, zone: "North" },
  { district: "Ayodhya", state: "Uttar Pradesh", hub: "Ayodhya (AYJ)", lat: 26.7922, lon: 82.1998, zone: "North" },
  { district: "Prayagraj", state: "Uttar Pradesh", hub: "Prayagraj (IXD)", lat: 25.4358, lon: 81.8463, zone: "North" },
  { district: "Kanpur Nagar", state: "Uttar Pradesh", hub: "Kanpur (KNU)", lat: 26.4499, lon: 80.3319, zone: "North" },
  { district: "Mathura", state: "Uttar Pradesh", hub: "Mathura / Vrindavan (AGR)", lat: 27.4924, lon: 77.6737, zone: "North" },
  { district: "Gorakhpur", state: "Uttar Pradesh", hub: "Gorakhpur (GOP)", lat: 26.7606, lon: 83.3732, zone: "North" },

  // West Bengal
  { district: "Kolkata", state: "West Bengal", hub: "Kolkata (CCU)", lat: 22.5726, lon: 88.3639, zone: "East" },
  { district: "Howrah", state: "West Bengal", hub: "Howrah (CCU)", lat: 22.5958, lon: 88.2636, zone: "East" },
  { district: "Darjeeling", state: "West Bengal", hub: "Darjeeling (IXB)", lat: 27.0410, lon: 88.2663, zone: "East" },
  { district: "Jalpaiguri", state: "West Bengal", hub: "Siliguri (IXB)", lat: 26.7271, lon: 88.3953, zone: "East" },
  { district: "Kalimpong", state: "West Bengal", hub: "Kalimpong (IXB)", lat: 27.0667, lon: 88.4667, zone: "East" },
  { district: "South 24 Parganas", state: "West Bengal", hub: "Sundarbans (CCU)", lat: 22.1667, lon: 88.6667, zone: "East" },

  // Madhya Pradesh
  { district: "Bhopal", state: "Madhya Pradesh", hub: "Bhopal (BHO)", lat: 23.2599, lon: 77.4126, zone: "Central" },
  { district: "Indore", state: "Madhya Pradesh", hub: "Indore (IDR)", lat: 22.7196, lon: 75.8577, zone: "Central" },
  { district: "Gwalior", state: "Madhya Pradesh", hub: "Gwalior (GWL)", lat: 26.2183, lon: 78.1828, zone: "Central" },
  { district: "Jabalpur", state: "Madhya Pradesh", hub: "Jabalpur (JLR)", lat: 23.1815, lon: 79.9864, zone: "Central" },
  { district: "Ujjain", state: "Madhya Pradesh", hub: "Mahakaleshwar (IDR)", lat: 23.1765, lon: 75.7885, zone: "Central" },
  { district: "Chhatarpur", state: "Madhya Pradesh", hub: "Khajuraho (HJR)", lat: 24.8500, lon: 79.9333, zone: "Central" },
  { district: "Umaria", state: "Madhya Pradesh", hub: "Bandhavgarh (JLR)", lat: 23.5333, lon: 80.8333, zone: "Central" },

  // Himachal Pradesh
  { district: "Shimla", state: "Himachal Pradesh", hub: "Shimla (SLV)", lat: 31.1048, lon: 77.1734, zone: "North" },
  { district: "Kullu", state: "Himachal Pradesh", hub: "Manali (KUU)", lat: 32.2432, lon: 77.1892, zone: "North" },
  { district: "Kangra", state: "Himachal Pradesh", hub: "Dharamshala (DHM)", lat: 32.2190, lon: 76.3234, zone: "North" },
  { district: "Lahaul and Spiti", state: "Himachal Pradesh", hub: "Kaza / Atal Tunnel (KUU)", lat: 32.2276, lon: 78.0710, zone: "North" },
  { district: "Chamba", state: "Himachal Pradesh", hub: "Dalhousie (DHM)", lat: 32.5387, lon: 75.9707, zone: "North" },

  // Uttarakhand
  { district: "Dehradun", state: "Uttarakhand", hub: "Dehradun / Rishikesh (DED)", lat: 30.3165, lon: 78.0322, zone: "North" },
  { district: "Haridwar", state: "Uttarakhand", hub: "Haridwar (DED)", lat: 29.9457, lon: 78.1642, zone: "North" },
  { district: "Nainital", state: "Uttarakhand", hub: "Nainital / Corbett (PGH)", lat: 29.3919, lon: 79.4542, zone: "North" },
  { district: "Rudraprayag", state: "Uttarakhand", hub: "Kedarnath (DED)", lat: 30.7352, lon: 79.0669, zone: "North" },
  { district: "Chamoli", state: "Uttarakhand", hub: "Badrinath / Auli (DED)", lat: 30.7433, lon: 79.4938, zone: "North" },

  // Punjab & Chandigarh
  { district: "Amritsar", state: "Punjab", hub: "Amritsar (ATQ)", lat: 31.6340, lon: 74.8723, zone: "North" },
  { district: "Ludhiana", state: "Punjab", hub: "Ludhiana (LUH)", lat: 30.9010, lon: 75.8573, zone: "North" },
  { district: "Chandigarh", state: "Chandigarh", hub: "Chandigarh (IXC)", lat: 30.7333, lon: 76.7794, zone: "North" },

  // Jammu & Kashmir & Ladakh
  { district: "Srinagar", state: "Jammu and Kashmir", hub: "Srinagar (SXR)", lat: 34.0837, lon: 74.7973, zone: "North" },
  { district: "Jammu", state: "Jammu and Kashmir", hub: "Jammu (IXJ)", lat: 32.7266, lon: 74.8570, zone: "North" },
  { district: "Baramulla", state: "Jammu and Kashmir", hub: "Gulmarg (SXR)", lat: 34.0484, lon: 74.3805, zone: "North" },
  { district: "Leh", state: "Ladakh", hub: "Leh (IXL)", lat: 34.1526, lon: 77.5771, zone: "North" },
  { district: "Kargil", state: "Ladakh", hub: "Kargil (IXL)", lat: 34.5539, lon: 76.1349, zone: "North" },

  // Goa
  { district: "North Goa", state: "Goa", hub: "Goa Mopa (GOX)", lat: 15.4909, lon: 73.8278, zone: "West" },
  { district: "South Goa", state: "Goa", hub: "Goa Dabolim (GOI)", lat: 15.2832, lon: 73.9862, zone: "West" },

  // Odisha & Bihar & Jharkhand & Chhattisgarh
  { district: "Khordha", state: "Odisha", hub: "Bhubaneswar (BBI)", lat: 20.2961, lon: 85.8245, zone: "East" },
  { district: "Puri", state: "Odisha", hub: "Puri (BBI)", lat: 19.8135, lon: 85.8312, zone: "East" },
  { district: "Patna", state: "Bihar", hub: "Patna (PAT)", lat: 25.5941, lon: 85.1376, zone: "East" },
  { district: "Gaya", state: "Bihar", hub: "Bodh Gaya (GAY)", lat: 24.7914, lon: 85.0002, zone: "East" },
  { district: "Ranchi", state: "Jharkhand", hub: "Ranchi (IXR)", lat: 23.3441, lon: 85.3096, zone: "East" },
  { district: "Raipur", state: "Chhattisgarh", hub: "Raipur (RPR)", lat: 21.2514, lon: 81.6296, zone: "Central" },

  // North East & Islands
  { district: "Kamrup Metropolitan", state: "Assam", hub: "Guwahati (GAU)", lat: 26.1445, lon: 91.7362, zone: "North-East" },
  { district: "Golaghat", state: "Assam", hub: "Kaziranga (JRH)", lat: 26.5775, lon: 93.1711, zone: "North-East" },
  { district: "Gangtok", state: "Sikkim", hub: "Gangtok (PYG/IXB)", lat: 27.3389, lon: 88.6065, zone: "North-East" },
  { district: "East Khasi Hills", state: "Meghalaya", hub: "Shillong (SHL/GAU)", lat: 25.5788, lon: 91.8933, zone: "North-East" },
  { district: "South Andaman", state: "Andaman and Nicobar Islands", hub: "Port Blair (IXZ)", lat: 11.6234, lon: 92.7265, zone: "South" },
  { district: "Puducherry", state: "Puducherry", hub: "Puducherry (PNY/MAA)", lat: 11.9416, lon: 79.8083, zone: "South" }
];

/**
 * Calculates Great Circle Haversine distance in kilometers between two coordinates
 */
function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Finds the nearest Indian district and state from any given latitude and longitude
 */
function findNearestIndianDistrict(userLat, userLon) {
  let closest = null;
  let minDistance = Infinity;

  for (const item of INDIAN_DISTRICTS_COORDINATES) {
    const dist = calculateHaversineDistance(userLat, userLon, item.lat, item.lon);
    if (dist < minDistance) {
      minDistance = dist;
      closest = { ...item, distanceKm: dist };
    }
  }

  return closest;
}

/**
 * Automatically detects user's live location and closest Indian district.
 * Uses a multi-tiered pipeline:
 * 1. Immediate LocalStorage cache (0ms instant display)
 * 2. Silent & automatic IP-based Geolocation (works instantly without permission prompt)
 * 3. Browser GPS Geolocation (refines precision if granted)
 */
async function detectUserLiveLocation(onSuccess, onError) {
  let hasResolved = false;

  // Tier 1: Check cached district for instant response (0ms)
  const cached = localStorage.getItem('bharatyatra_live_district');
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (parsed && parsed.district) {
        hasResolved = true;
        if (onSuccess) onSuccess(parsed, 'cached');
      }
    } catch (e) {}
  }

  // Tier 2: Silent Automatic IP Geolocation (Zero-click, instant, reliable)
  const fetchIPLocation = async () => {
    const endpoints = [
      'https://freeipapi.com/api/json',
      'https://ipapi.co/json/',
      'https://ipwho.is/'
    ];

    for (const url of endpoints) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3500);
        const resp = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId);

        if (resp.ok) {
          const data = await resp.json();
          const lat = parseFloat(data.latitude || data.lat);
          const lon = parseFloat(data.longitude || data.lon);

          if (!isNaN(lat) && !isNaN(lon)) {
            const nearest = findNearestIndianDistrict(lat, lon);
            if (nearest) {
              nearest.source = 'IP Geolocation';
              nearest.detectedCity = data.cityName || data.city || nearest.district;
              localStorage.setItem('bharatyatra_live_district', JSON.stringify(nearest));
              hasResolved = true;
              if (onSuccess) onSuccess(nearest, 'ip');
              return true;
            }
          }
        }
      } catch (err) {
        // Try next endpoint silently
      }
    }
    return false;
  };

  // Run IP geolocation immediately in background
  fetchIPLocation().then((success) => {
    if (!success && !hasResolved) {
      // Tier 4 Fallback if all IP services failed: Timezone heuristic
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      let fallback = INDIAN_DISTRICTS_COORDINATES[0]; // Delhi
      if (tz.includes('Calcutta') || tz.includes('Kolkata') || tz.includes('Asia/Kolkata')) {
        // Default to Bengaluru or Mumbai if cached
        fallback = INDIAN_DISTRICTS_COORDINATES.find(d => d.district === 'Bengaluru Urban') || INDIAN_DISTRICTS_COORDINATES[0];
      }
      if (onSuccess) onSuccess(fallback, 'fallback');
    }
  });

  // Tier 3: Browser GPS in background (refines location to exact district if permission is granted)
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const nearest = findNearestIndianDistrict(lat, lon);
        if (nearest) {
          nearest.source = 'GPS Precise';
          localStorage.setItem('bharatyatra_live_district', JSON.stringify(nearest));
          if (onSuccess) onSuccess(nearest, 'gps');
        }
      },
      (err) => {
        // GPS denied or timed out; IP layer already resolved it seamlessly
      },
      { enableHighAccuracy: true, timeout: 6000, maximumAge: 60000 }
    );
  }
}

/**
 * Inter-State Circuit Analyzer:
 * Detects whether departure and destination are in different states,
 * and calculates distance and transit recommendations.
 */
function analyzeInterStateTravel(originStr, destStr) {
  if (!originStr || !destStr) return null;

  // Extract states
  const parseState = (str) => {
    // Check against all Indian states
    for (const s of INDIA_STATES_DATA) {
      if (str.toLowerCase().includes(s.name.toLowerCase())) {
        return s;
      }
    }
    return null;
  };

  const originState = parseState(originStr);
  const destState = parseState(destStr);

  const isInterState = originState && destState && originState.id !== destState.id;

  // Estimate distance between state/district hubs if coordinates exist
  let approxDistance = null;
  const oMatch = INDIAN_DISTRICTS_COORDINATES.find(c => originStr.toLowerCase().includes(c.district.toLowerCase()) || originStr.toLowerCase().includes(c.state.toLowerCase()));
  const dMatch = INDIAN_DISTRICTS_COORDINATES.find(c => destStr.toLowerCase().includes(c.district.toLowerCase()) || destStr.toLowerCase().includes(c.state.toLowerCase()));

  if (oMatch && dMatch) {
    approxDistance = calculateHaversineDistance(oMatch.lat, oMatch.lon, dMatch.lat, dMatch.lon);
  }

  let transitAdvice = "Direct Railway / AC Outstation Cab";
  if (approxDistance) {
    if (approxDistance > 800) {
      transitAdvice = "Direct Flight or Overnight Vande Bharat / Rajdhani Express recommended";
    } else if (approxDistance > 350) {
      transitAdvice = "Vande Bharat Express / Express Highway AC Cab";
    } else {
      transitAdvice = "Inter-State Highway Road Trip / Express Train";
    }
  }

  return {
    isInterState: Boolean(isInterState),
    originState: originState ? originState.name : null,
    originZone: originState ? originState.zone : null,
    destState: destState ? destState.name : null,
    destZone: destState ? destState.zone : null,
    destCapital: destState ? destState.capital : null,
    approxDistanceKm: approxDistance,
    transitAdvice: transitAdvice
  };
}
