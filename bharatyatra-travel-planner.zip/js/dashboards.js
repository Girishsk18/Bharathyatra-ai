/**
 * BharatYatra AI - Dashboards Engine (dashboards.js)
 * Powers:
 * 1. Simple Travellers Dashboard: All 28 States, 8 UTs, Capitals, and 780+ Districts
 * 2. All Tourist Places Dashboard: Comprehensive Curated India Attractions Showcase
 */

// Dashboard Internal State
const dashState = {
  currentView: 'planner', // 'planner' | 'states-districts' | 'tourist-places'
  states: {
    search: '',
    zone: 'all',
    type: 'all',
    sort: 'name', // 'name' | 'districts-desc' | 'zone'
    activeModalState: null,
    modalDistrictSearch: ''
  },
  tourist: {
    search: '',
    category: 'all',
    state: 'all',
    season: 'all',
    duration: 'all',
    budgetTier: 'all',
    wishlistOnly: false,
    activeModalPlace: null
  },
  visitedDistricts: JSON.parse(localStorage.getItem('bharatyatra_visited_districts') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('bharatyatra_tourist_wishlist') || '[]')
};

// Initialize Dashboards on DOM load
document.addEventListener('DOMContentLoaded', () => {
  initDashboardRouting();
  populateStateFilterDropdowns();
  updateVisitedTrackerUI();
  updateWishlistBadges();
  
  // Render initial dashboards
  renderStatesDashboard();
  renderTouristPlacesDashboard();
});

/* --------------------------------------------------------------------------
   View Routing & Tab Switching
   -------------------------------------------------------------------------- */
function initDashboardRouting() {
  const hash = window.location.hash.replace('#', '');
  if (hash === 'states-districts' || hash === 'states') {
    switchMainView('states-districts');
  } else if (hash === 'tourist-places' || hash === 'places') {
    switchMainView('tourist-places');
  } else {
    switchMainView('planner');
  }

  window.addEventListener('hashchange', () => {
    const newHash = window.location.hash.replace('#', '');
    if (newHash === 'states-districts' || newHash === 'states') {
      switchMainView('states-districts', false);
    } else if (newHash === 'tourist-places' || newHash === 'places') {
      switchMainView('tourist-places', false);
    } else if (newHash === 'planner') {
      switchMainView('planner', false);
    }
  });
}

function switchMainView(viewName, updateHash = true) {
  dashState.currentView = viewName;
  if (updateHash) {
    window.location.hash = viewName;
  }

  // Update Nav Buttons
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === viewName);
  });

  // Toggle View Panels
  const plannerView = document.getElementById('plannerViewContainer');
  const statesView = document.getElementById('dashboardStatesView');
  const placesView = document.getElementById('dashboardPlacesView');

  if (plannerView) plannerView.classList.toggle('hidden-view', viewName !== 'planner');
  if (statesView) statesView.classList.toggle('hidden-view', viewName !== 'states-districts');
  if (placesView) placesView.classList.toggle('hidden-view', viewName !== 'tourist-places');

  // Smooth scroll to top of content
  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (viewName === 'states-districts') {
    renderStatesDashboard();
  } else if (viewName === 'tourist-places') {
    renderTouristPlacesDashboard();
  }
}

/* ==========================================================================
   DASHBOARD 1: STATES & DISTRICTS LOGIC (SIMPLE TRAVELLER)
   ========================================================================== */

function handleStatesSearch(query) {
  dashState.states.search = query.trim().toLowerCase();
  renderStatesDashboard();
}

function handleZoneFilter(zone) {
  dashState.states.zone = zone;
  document.querySelectorAll('#statesZoneFilters .filter-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.zone === zone);
  });
  renderStatesDashboard();
}

function handleStateTypeFilter(type) {
  dashState.states.type = type;
  renderStatesDashboard();
}

function handleStatesSort(sortMode) {
  dashState.states.sort = sortMode;
  renderStatesDashboard();
}

function renderStatesDashboard() {
  const container = document.getElementById('statesGridContainer');
  const countBadge = document.getElementById('statesCountBadge');
  if (!container) return;

  const { search, zone, type, sort } = dashState.states;

  let filtered = INDIA_STATES_DATA.filter(state => {
    // Zone filter
    if (zone !== 'all' && zone !== 'ut') {
      if (state.zone !== zone) return false;
    }
    if (zone === 'ut' && state.type !== 'ut') return false;

    // Type filter
    if (type !== 'all' && state.type !== type) return false;

    // Search query matches State Name, Capital, or any District name!
    if (search) {
      const matchName = state.name.toLowerCase().includes(search);
      const matchCapital = state.capital.toLowerCase().includes(search);
      const matchZone = state.zone.toLowerCase().includes(search);
      const matchDistrict = state.districts.some(d => d.toLowerCase().includes(search));
      if (!matchName && !matchCapital && !matchZone && !matchDistrict) return false;
    }

    return true;
  });

  // Sorting
  filtered.sort((a, b) => {
    if (sort === 'districts-desc') {
      return b.districts.length - a.districts.length;
    }
    if (sort === 'districts-asc') {
      return a.districts.length - b.districts.length;
    }
    if (sort === 'zone') {
      return a.zone.localeCompare(b.zone) || a.name.localeCompare(b.name);
    }
    return a.name.localeCompare(b.name);
  });

  if (countBadge) {
    countBadge.textContent = `${filtered.length} of ${INDIA_STATES_DATA.length} States & UTs`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem; color: var(--text-muted);">
        <div style="font-size: 3rem; margin-bottom: 0.8rem;">🔍</div>
        <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--text-main); margin-bottom: 0.4rem;">No states or districts found</h3>
        <p>Try searching for a different state name, capital, or specific district (e.g., "Kutch", "Wayanad", "Varanasi").</p>
        <button class="btn-card-action btn-card-secondary" style="max-width: 200px; margin: 1.25rem auto 0;" onclick="resetStatesFilters()">Reset Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(state => {
    // Check visited districts in this state
    const visitedInState = state.districts.filter(d => 
      dashState.visitedDistricts.includes(`${state.name}::${d}`)
    );

    // District preview (highlight matching or first 6)
    const previewList = state.districts.slice(0, 6);
    const hasMore = state.districts.length > 6;

    return `
      <div class="state-card" id="state-card-${state.id}">
        <div>
          <div class="state-card-header">
            <div class="state-title-wrap">
              <h3 class="state-card-name">${state.name}</h3>
              <div class="state-capital-badge">
                <span>🏛️ Capital:</span>
                <strong>${state.capital}</strong>
              </div>
            </div>
            <div class="state-badges-cluster">
              <span class="tag-zone tag-zone-${state.zone.replace(/\s+/g, '-')}">${state.zone} Zone</span>
              <span class="badge-dist-count">${state.districts.length} Districts</span>
            </div>
          </div>

          <p class="state-desc-snippet">${state.description}</p>

          <div class="state-key-info-row">
            <div>
              <div class="info-item-label">Best Season</div>
              <div class="info-item-val">☀️ ${state.bestSeason}</div>
            </div>
            <div>
              <div class="info-item-label">Official Language</div>
              <div class="info-item-val">🗣️ ${state.officialLanguages.join(', ')}</div>
            </div>
          </div>

          <div class="districts-preview-cluster">
            <div class="dist-preview-title">
              <span>Districts Sample</span>
              <span style="color: var(--accent-cyan); font-weight: 600;">
                ${visitedInState.length > 0 ? `✅ ${visitedInState.length}/${state.districts.length} Visited` : `${state.districts.length} total`}
              </span>
            </div>
            <div class="dist-chips-wrap">
              ${previewList.map(dist => {
                const isVisited = dashState.visitedDistricts.includes(`${state.name}::${dist}`);
                const hasHl = state.districtHighlights && state.districtHighlights[dist];
                const isSearched = search && dist.toLowerCase().includes(search);
                return `
                  <span class="dist-chip ${isVisited ? 'visited' : ''} ${hasHl ? 'has-highlight' : ''}" 
                        style="${isSearched ? 'border-color: #22d3ee; font-weight: 700; background: rgba(6,182,212,0.15);' : ''}"
                        title="${hasHl ? state.districtHighlights[dist] : dist}">
                    ${isVisited ? '✓ ' : ''}${dist}
                  </span>
                `;
              }).join('')}
              ${hasMore ? `<span class="dist-chip" style="color: var(--text-muted);">+${state.districts.length - 6} more</span>` : ''}
            </div>
          </div>
        </div>

        <div class="state-card-footer">
          <button class="btn-card-action btn-card-primary" onclick="openStateModal('${state.id}')">
            <span>Explore All ${state.districts.length} Districts</span>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
          </button>
          <button class="btn-card-action btn-card-secondary" style="flex: 0 0 46px; padding: 0;" title="Plan Yatra in ${state.name}" onclick="planYatraForState('${state.name}', '${state.capital}')">
            🧭
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function resetStatesFilters() {
  dashState.states.search = '';
  dashState.states.zone = 'all';
  dashState.states.type = 'all';
  const searchInput = document.getElementById('statesSearchInput');
  if (searchInput) searchInput.value = '';
  document.querySelectorAll('#statesZoneFilters .filter-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.zone === 'all');
  });
  renderStatesDashboard();
}

/* --------------------------------------------------------------------------
   State Deep Dive Modal
   -------------------------------------------------------------------------- */
function openStateModal(stateId) {
  const state = INDIA_STATES_DATA.find(s => s.id === stateId);
  if (!state) return;

  dashState.states.activeModalState = state;
  dashState.states.modalDistrictSearch = '';

  const modal = document.getElementById('stateDetailModal');
  if (!modal) return;

  renderStateModalContent();
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeStateModal() {
  const modal = document.getElementById('stateDetailModal');
  if (modal) modal.style.display = 'none';
  document.body.style.overflow = '';
  dashState.states.activeModalState = null;
  // Refresh main cards to show newly marked visited districts
  renderStatesDashboard();
  updateVisitedTrackerUI();
}

function handleModalDistrictSearch(query) {
  dashState.states.modalDistrictSearch = query.trim().toLowerCase();
  renderStateModalDistricts();
}

function renderStateModalContent() {
  const state = dashState.states.activeModalState;
  if (!state) return;

  // Title & Header
  document.getElementById('smStateName').textContent = state.name;
  document.getElementById('smCapital').textContent = state.capital;
  document.getElementById('smZone').textContent = `${state.zone} Zone • ${state.type.toUpperCase()}`;
  document.getElementById('smDesc').textContent = state.description;
  document.getElementById('smBestSeason').textContent = state.bestSeason;
  document.getElementById('smLanguages').textContent = state.officialLanguages.join(', ');
  document.getElementById('smTotalDistrictsBadge').textContent = `${state.districts.length} Districts Total`;

  // Transit Hubs – fill content
  document.getElementById('smAirports').textContent = state.transit.airports.join(' • ');
  document.getElementById('smRailways').textContent = state.transit.railwayJunctions.join(' • ');
  document.getElementById('smHighways').textContent = state.transit.highways.join(' • ');

  // Reset radio buttons on every modal open
  const radioTime = document.getElementById('smRadioTime');
  const radioMoney = document.getElementById('smRadioMoney');
  if (radioTime) radioTime.checked = false;
  if (radioMoney) radioMoney.checked = false;
  ['smLabelTime', 'smLabelMoney'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.style.background = 'transparent'; el.style.color = 'var(--text-secondary)'; }
  });
  // Reset card order to default (Flight, Train, Road)
  const grid = document.getElementById('smTransitGrid');
  if (grid) {
    const flight = document.getElementById('smTransitFlight');
    const train = document.getElementById('smTransitTrain');
    const road = document.getElementById('smTransitRoad');
    if (flight && train && road) {
      [flight, train, road].forEach(el => { el.style.order = ''; el.style.outline = ''; el.style.background = ''; });
    }
  }

  // Direct Plan Button Action
  const planBtn = document.getElementById('smPlanBtn');
  if (planBtn) {
    planBtn.onclick = () => {
      closeStateModal();
      planYatraForState(state.name, state.capital);
    };
  }

  // Render Districts List
  renderStateModalDistricts();
}

/**
 * Sort state modal transport cards by Time (fastest first: Flights > Trains > Road)
 * or by Money (cheapest first: Road > Trains > Flights).
 */
function setStateTransportSort(priority) {
  const flight = document.getElementById('smTransitFlight');
  const train  = document.getElementById('smTransitTrain');
  const road   = document.getElementById('smTransitRoad');
  const labelTime  = document.getElementById('smLabelTime');
  const labelMoney = document.getElementById('smLabelMoney');

  if (!flight || !train || !road) return;

  // Reset styles
  [flight, train, road].forEach(el => {
    el.style.outline = 'none';
    el.style.background = '';
  });

  if (priority === 'time') {
    // Fastest: Flights (1st) → Trains (2nd) → Road (3rd)
    flight.style.order = '1';
    train.style.order  = '2';
    road.style.order   = '3';
    flight.style.outline = '2px solid var(--accent-cyan)';
    flight.style.background = 'rgba(6,182,212,0.07)';

    if (labelTime)  { labelTime.style.background  = 'rgba(6,182,212,0.15)';  labelTime.style.color  = 'var(--accent-cyan)'; }
    if (labelMoney) { labelMoney.style.background = 'transparent'; labelMoney.style.color = 'var(--text-secondary)'; }

    showToast('⏱️ Sorted by Time — Fastest options first (Flights → Trains → Road)', 'info');

  } else if (priority === 'money') {
    // Cheapest: Road (1st) → Trains (2nd) → Flights (3rd)
    road.style.order   = '1';
    train.style.order  = '2';
    flight.style.order = '3';
    road.style.outline = '2px solid var(--accent-emerald)';
    road.style.background = 'rgba(16,185,129,0.07)';

    if (labelMoney) { labelMoney.style.background = 'rgba(16,185,129,0.15)'; labelMoney.style.color = 'var(--accent-emerald)'; }
    if (labelTime)  { labelTime.style.background  = 'transparent'; labelTime.style.color  = 'var(--text-secondary)'; }

    showToast('💰 Sorted by Money — Cheapest options first (Road → Trains → Flights)', 'info');
  }

  // Make grid a flex container so order works
  const grid = document.getElementById('smTransitGrid');
  if (grid) {
    grid.style.display = 'flex';
    grid.style.flexDirection = 'column';
    grid.style.gap = '0.75rem';
  }
}



function renderStateModalDistricts() {
  const state = dashState.states.activeModalState;
  const grid = document.getElementById('smDistrictsGrid');
  if (!state || !grid) return;

  const searchQuery = dashState.states.modalDistrictSearch;

  const filteredDistricts = state.districts.filter(d => 
    !searchQuery || d.toLowerCase().includes(searchQuery)
  );

  if (filteredDistricts.length === 0) {
    grid.innerHTML = `<div style="grid-column: 1 / -1; padding: 2rem; text-align: center; color: var(--text-muted);">No district matches "${searchQuery}"</div>`;
    return;
  }

  grid.innerHTML = filteredDistricts.map(dist => {
    const isVisited = dashState.visitedDistricts.includes(`${state.name}::${dist}`);
    const highlight = state.districtHighlights && state.districtHighlights[dist];

    return `
      <div class="interactive-district-card ${isVisited ? 'visited' : ''}" 
           onclick="toggleDistrictVisited('${state.name}', '${dist}', event)">
        <div class="interactive-dist-top">
          <span class="interactive-dist-name">${dist}</span>
          <span style="font-size: 1.1rem; color: ${isVisited ? 'var(--accent-emerald)' : 'var(--text-muted)'};" title="Click card to toggle Visited">
            ${isVisited ? '✅' : '⚪'}
          </span>
        </div>
        ${highlight ? `
          <div class="interactive-dist-highlight">
            ⭐ ${highlight}
          </div>
        ` : `
          <div style="font-size: 0.7rem; color: var(--text-muted);">District in ${state.zone} Zone</div>
        `}
        <div style="display: flex; gap: 0.4rem; margin-top: 0.45rem;">
          <button type="button" class="btn-card-action btn-card-primary" 
                  style="padding: 0.25rem 0.55rem; font-size: 0.725rem; border-radius: var(--radius-xs); width: 100%;"
                  onclick="setDistrictAsBlueprintDestination('${state.name}', '${dist}', event)">
            🎯 Plan as Destination
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function setDistrictAsBlueprintDestination(stateName, districtName, event) {
  if (event) event.stopPropagation();
  closeStateModal();
  switchMainView('planner');

  const destStr = `${districtName}, ${stateName}`;
  if (typeof selectDestination === 'function') {
    selectDestination(destStr, 'district', stateName);
  } else {
    state.trip.destination = destStr;
    const destInput = document.getElementById('destinationInput');
    if (destInput) destInput.value = destStr;
    if (typeof updateLiveBlueprint === 'function') updateLiveBlueprint();
  }

  showToast(`🎯 Destination set to ${destStr} in Blueprint Builder!`, 'success');
  if (typeof scrollToForm === 'function') {
    scrollToForm();
  }
}

function toggleDistrictVisited(stateName, districtName, event) {
  if (event) event.stopPropagation();
  const key = `${stateName}::${districtName}`;
  const idx = dashState.visitedDistricts.indexOf(key);

  if (idx > -1) {
    dashState.visitedDistricts.splice(idx, 1);
    showToast(`Unmarked ${districtName}`, 'info');
  } else {
    dashState.visitedDistricts.push(key);
    showToast(`Marked ${districtName} as Visited! 🚩`, 'success');
  }

  localStorage.setItem('bharatyatra_visited_districts', JSON.stringify(dashState.visitedDistricts));
  
  if (dashState.states.activeModalState) {
    renderStateModalDistricts();
  }
  updateVisitedTrackerUI();
}

function updateVisitedTrackerUI() {
  const count = dashState.visitedDistricts.length;
  const total = INDIA_STATS.totalDistricts; // ~780+
  const pct = Math.min(100, Math.round((count / total) * 100));

  const countEl = document.getElementById('visitedCountDisplay');
  const barEl = document.getElementById('visitedProgressBar');
  const pctEl = document.getElementById('visitedPctDisplay');

  if (countEl) countEl.textContent = `${count} / ${total} Districts`;
  if (barEl) barEl.style.width = `${pct}%`;
  if (pctEl) pctEl.textContent = `${pct}% of India`;
}

function exportVisitedDistricts() {
  if (dashState.visitedDistricts.length === 0) {
    showToast('You haven\'t marked any districts visited yet! Click on districts in any state to mark them.', 'info');
    return;
  }

  const text = `🇮🇳 MY BHARAT TRAVEL RECORD\n` +
    `Districts Explored: ${dashState.visitedDistricts.length} / ${INDIA_STATS.totalDistricts} (${Math.round((dashState.visitedDistricts.length / INDIA_STATS.totalDistricts) * 100)}% of India)\n\n` +
    dashState.visitedDistricts.map(item => `✓ ${item.replace('::', ' - ')}`).join('\n') +
    `\n\nGenerated by BharatYatra AI: Explore Incredible India`;

  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied your visited districts checklist to clipboard! 📋', 'success');
  }).catch(() => {
    alert(text);
  });
}

function copyAllStateDistricts() {
  const state = dashState.states.activeModalState;
  if (!state) return;

  const text = `${state.name} (Capital: ${state.capital}) - All ${state.districts.length} Districts:\n` +
    state.districts.map((d, i) => `${i + 1}. ${d}`).join('\n');

  navigator.clipboard.writeText(text).then(() => {
    showToast(`Copied all ${state.districts.length} districts of ${state.name}!`, 'success');
  });
}

/* ==========================================================================
   DASHBOARD 2: ALL TOURIST PLACES LOGIC
   ========================================================================== */

function populateStateFilterDropdowns() {
  const dropdown = document.getElementById('touristStateFilter');
  if (!dropdown) return;

  const states = [...new Set(TOURIST_PLACES_DATA.map(p => p.state))].sort();
  dropdown.innerHTML = `
    <option value="all">All States & UTs</option>
    ${states.map(s => `<option value="${s}">${s}</option>`).join('')}
  `;
}

function handleTouristSearch(query) {
  dashState.tourist.search = query.trim().toLowerCase();
  renderTouristPlacesDashboard();
}

function handleCategoryFilter(category) {
  dashState.tourist.category = category;
  document.querySelectorAll('#touristCategoryPills .filter-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.category === category);
  });
  renderTouristPlacesDashboard();
}

function handleTouristStateFilter(stateName) {
  dashState.tourist.state = stateName;
  renderTouristPlacesDashboard();
}

function handleTouristSeasonFilter(season) {
  dashState.tourist.season = season;
  renderTouristPlacesDashboard();
}

function handleTouristBudgetFilter(budgetTier) {
  dashState.tourist.budgetTier = budgetTier;
  renderTouristPlacesDashboard();
}

function toggleWishlistFilter() {
  dashState.tourist.wishlistOnly = !dashState.tourist.wishlistOnly;
  const btn = document.getElementById('wishlistFilterToggle');
  if (btn) {
    btn.classList.toggle('active', dashState.tourist.wishlistOnly);
  }
  renderTouristPlacesDashboard();
}

function renderTouristPlacesDashboard() {
  const container = document.getElementById('touristPlacesGridContainer');
  const countBadge = document.getElementById('touristPlacesCountBadge');
  if (!container) return;

  const { search, category, state, season, budgetTier, wishlistOnly } = dashState.tourist;

  let filtered = TOURIST_PLACES_DATA.filter(place => {
    // Category filter
    if (category !== 'all' && place.category !== category) return false;

    // State filter
    if (state !== 'all' && place.state !== state) return false;

    // Season filter
    if (season !== 'all') {
      if (!place.bestSeason.toLowerCase().includes(season.toLowerCase())) return false;
    }

    // Budget tier filter
    if (budgetTier !== 'all' && place.budgetTier !== budgetTier) return false;

    // Wishlist only
    if (wishlistOnly && !dashState.wishlist.includes(place.id)) return false;

    // Search query
    if (search) {
      const matchName = place.name.toLowerCase().includes(search);
      const matchState = place.state.toLowerCase().includes(search);
      const matchDistrict = place.district.toLowerCase().includes(search);
      const matchDesc = place.description.toLowerCase().includes(search);
      const matchTag = place.tagline.toLowerCase().includes(search);
      const matchHl = place.highlights.some(h => h.toLowerCase().includes(search));
      if (!matchName && !matchState && !matchDistrict && !matchDesc && !matchTag && !matchHl) {
        return false;
      }
    }

    return true;
  });

  if (countBadge) {
    countBadge.textContent = `${filtered.length} Tourist Destinations`;
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem; color: var(--text-muted);">
        <div style="font-size: 3rem; margin-bottom: 0.8rem;">🏖️</div>
        <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--text-main); margin-bottom: 0.4rem;">No tourist places match your filters</h3>
        <p>Try clearing your category, state or search query to see all places.</p>
        <button class="btn-card-action btn-card-secondary" style="max-width: 200px; margin: 1.25rem auto 0;" onclick="resetTouristFilters()">Reset Filters</button>
      </div>
    `;
    return;
  }

  // Category Icon Map
  const catIconMap = {
    'heritage': '🏛️ Heritage',
    'hill-station': '🏔️ Hill Station',
    'spiritual': '🛕 Spiritual',
    'beach': '🏖️ Beach',
    'wildlife': '🐅 Wildlife',
    'adventure': '🧗 Adventure'
  };

  container.innerHTML = filtered.map(place => {
    const isWishlisted = dashState.wishlist.includes(place.id);

    return `
      <div class="tourist-card" id="place-card-${place.id}">
        <div class="tourist-card-img-box">
          <img src="${place.image}" alt="${place.name}" class="tourist-card-img" loading="lazy" onerror="this.src='assets/images/jaipur.jpg'">
          <div class="tourist-card-overlay-gradient"></div>

          <div class="tourist-img-badges-top">
            <span class="cat-pill">${catIconMap[place.category] || place.category}</span>
            <button class="btn-wishlist-heart ${isWishlisted ? 'saved' : ''}" 
                    onclick="toggleWishlist('${place.id}', event)" 
                    title="${isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="${isWishlisted ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
              </svg>
            </button>
          </div>

          <div class="tourist-img-badges-bottom">
            <div class="tourist-loc-pin">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span>${place.district}, ${place.state}</span>
            </div>
            <div class="tourist-rating-tag">
              <span>★</span>
              <span>${place.rating}</span>
            </div>
          </div>
        </div>

        <div class="tourist-card-body">
          <h3 class="tourist-card-title">${place.name}</h3>
          <div class="tourist-card-tagline">${place.tagline}</div>
          <p class="tourist-card-desc">${place.description}</p>

          <div class="tourist-tags-row">
            <span class="tourist-spec-chip">⏱️ ${place.idealDuration}</span>
            <span class="tourist-spec-chip">☀️ ${place.bestSeason}</span>
            <span class="tourist-spec-chip">✨ ${place.zone} Zone</span>
          </div>

          <div class="tourist-card-bottom-bar">
            <div class="tourist-budget-block">
              <span class="tourist-budget-label">Est. Daily / Person</span>
              <span class="tourist-budget-val">₹${place.estimatedDailyBudget.toLocaleString('en-IN')}</span>
            </div>
            <button class="btn-card-action btn-card-primary" style="flex: 0 0 auto; padding: 0.55rem 1rem;" onclick="openTouristModal('${place.id}')">
              <span>Guide & Route</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function resetTouristFilters() {
  dashState.tourist.search = '';
  dashState.tourist.category = 'all';
  dashState.tourist.state = 'all';
  dashState.tourist.season = 'all';
  dashState.tourist.budgetTier = 'all';
  dashState.tourist.wishlistOnly = false;

  const searchInput = document.getElementById('touristSearchInput');
  if (searchInput) searchInput.value = '';
  const stateSel = document.getElementById('touristStateFilter');
  if (stateSel) stateSel.value = 'all';
  const seasonSel = document.getElementById('touristSeasonFilter');
  if (seasonSel) seasonSel.value = 'all';
  const budgetSel = document.getElementById('touristBudgetFilter');
  if (budgetSel) budgetSel.value = 'all';

  document.querySelectorAll('#touristCategoryPills .filter-pill-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.category === 'all');
  });

  const wishlistBtn = document.getElementById('wishlistFilterToggle');
  if (wishlistBtn) wishlistBtn.classList.remove('active');

  renderTouristPlacesDashboard();
}

/* --------------------------------------------------------------------------
   Tourist Place Detail Modal
   -------------------------------------------------------------------------- */
function openTouristModal(placeId) {
  const place = TOURIST_PLACES_DATA.find(p => p.id === placeId);
  if (!place) return;

  dashState.tourist.activeModalPlace = place;

  const modal = document.getElementById('touristDetailModal');
  if (!modal) return;

  // Fill in content
  document.getElementById('tmPlaceName').textContent = place.name;
  document.getElementById('tmLocation').textContent = `${place.district}, ${place.state} (${place.zone} Zone)`;
  document.getElementById('tmTagline').textContent = place.tagline;
  document.getElementById('tmDescription').textContent = place.description;
  document.getElementById('tmRating').textContent = `★ ${place.rating} (${place.reviewsCount} reviews)`;
  document.getElementById('tmDuration').textContent = place.idealDuration;
  document.getElementById('tmBestSeason').textContent = place.bestSeason;
  document.getElementById('tmBudget').textContent = `₹${place.estimatedDailyBudget.toLocaleString('en-IN')} / person daily (${place.budgetTier.toUpperCase()})`;

  // Transit
  document.getElementById('tmAirport').textContent = place.transit.nearestAirport;
  document.getElementById('tmRailway').textContent = place.transit.nearestRailway;
  document.getElementById('tmRoad').textContent = place.transit.roadRoute;

  // Practical details
  document.getElementById('tmEntryFee').textContent = place.entryFee;
  document.getElementById('tmTimings').textContent = place.timings;
  document.getElementById('tmTravelerTips').textContent = place.travelerTips;

  // Highlights list
  const hlContainer = document.getElementById('tmHighlightsList');
  if (hlContainer) {
    hlContainer.innerHTML = place.highlights.map(hl => `
      <div style="display: flex; align-items: flex-start; gap: 0.65rem; font-size: 0.9rem; line-height: 1.5;">
        <span style="color: var(--accent-cyan); font-weight: 700;">✓</span>
        <span>${hl}</span>
      </div>
    `).join('');
  }

  // Plan CTA
  const planBtn = document.getElementById('tmPlanBtn');
  if (planBtn) {
    planBtn.onclick = () => {
      closeTouristModal();
      planYatraForPlace(place);
    };
  }

  // Wishlist button state
  const wishBtn = document.getElementById('tmWishlistBtn');
  if (wishBtn) {
    const isSaved = dashState.wishlist.includes(place.id);
    wishBtn.textContent = isSaved ? '❤️ Saved in Wishlist' : '🤍 Add to Wishlist';
    wishBtn.onclick = () => {
      toggleWishlist(place.id);
      const nowSaved = dashState.wishlist.includes(place.id);
      wishBtn.textContent = nowSaved ? '❤️ Saved in Wishlist' : '🤍 Add to Wishlist';
    };
  }

  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeTouristModal() {
  const modal = document.getElementById('touristDetailModal');
  if (modal) modal.style.display = 'none';
  document.body.style.overflow = '';
  dashState.tourist.activeModalPlace = null;
}

/* --------------------------------------------------------------------------
   Wishlist Handling
   -------------------------------------------------------------------------- */
function toggleWishlist(placeId, event) {
  if (event) event.stopPropagation();
  const idx = dashState.wishlist.indexOf(placeId);

  if (idx > -1) {
    dashState.wishlist.splice(idx, 1);
    showToast('Removed from Wishlist', 'info');
  } else {
    dashState.wishlist.push(placeId);
    showToast('Saved to your Travel Wishlist! ❤️', 'success');
  }

  localStorage.setItem('bharatyatra_tourist_wishlist', JSON.stringify(dashState.wishlist));
  updateWishlistBadges();
  renderTouristPlacesDashboard();
}

function updateWishlistBadges() {
  const count = dashState.wishlist.length;
  const badges = document.querySelectorAll('.wishlist-counter-badge');
  badges.forEach(b => {
    b.textContent = count;
  });
}

function openWishlistModal() {
  const modal = document.getElementById('wishlistModalDrawer');
  const body = document.getElementById('wishlistModalBody');
  if (!modal || !body) return;

  const savedPlaces = TOURIST_PLACES_DATA.filter(p => dashState.wishlist.includes(p.id));

  if (savedPlaces.length === 0) {
    body.innerHTML = `
      <div style="text-align: center; padding: 3rem 1rem; color: var(--text-muted);">
        <div style="font-size: 3rem; margin-bottom: 0.5rem;">🤍</div>
        <h4 style="color: var(--text-main); font-weight: 700; margin-bottom: 0.4rem;">Your Travel Wishlist is Empty</h4>
        <p style="font-size: 0.85rem;">Click the heart icon on any tourist destination in India to save it here!</p>
        <button class="btn-card-action btn-card-primary" style="max-width: 220px; margin: 1.25rem auto 0;" onclick="closeWishlistModal(); switchMainView('tourist-places');">
          Explore Tourist Places
        </button>
      </div>
    `;
  } else {
    body.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 1rem;">
        ${savedPlaces.map(p => `
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: 0.85rem; border-radius: var(--radius-md); background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle);">
            <div>
              <div style="font-weight: 700; color: var(--text-main); font-size: 0.95rem;">${p.name}</div>
              <div style="font-size: 0.775rem; color: var(--accent-cyan);">${p.district}, ${p.state} • ${p.idealDuration}</div>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <button class="btn-card-action btn-card-primary" style="padding: 0.4rem 0.8rem; font-size: 0.75rem;" onclick="closeWishlistModal(); openTouristModal('${p.id}');">
                View
              </button>
              <button class="icon-btn-round" style="width: 32px; height: 32px; color: var(--accent-pink);" title="Remove" onclick="toggleWishlist('${p.id}'); openWishlistModal();">
                ✕
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }

  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeWishlistModal() {
  const modal = document.getElementById('wishlistModalDrawer');
  if (modal) modal.style.display = 'none';
  document.body.style.overflow = '';
}

/* --------------------------------------------------------------------------
   Integration: Send Destination Directly to Planner
   -------------------------------------------------------------------------- */
function planYatraForState(stateName, capital) {
  switchMainView('planner');
  const destStr = `${capital}, ${stateName}`;
  if (typeof selectDestination === 'function') {
    selectDestination(destStr, 'capital', stateName);
  } else {
    state.trip.destination = destStr;
    const destInput = document.getElementById('destinationInput');
    if (destInput) destInput.value = destStr;
    if (typeof updateLiveBlueprint === 'function') updateLiveBlueprint();
  }

  showToast(`Loaded ${capital}, ${stateName} into BharatYatra Planner!`, 'success');
  if (typeof scrollToForm === 'function') {
    scrollToForm();
  }
}

function planYatraForPlace(place) {
  switchMainView('planner');
  const destStr = `${place.name}, ${place.state}`;
  if (typeof selectDestination === 'function') {
    selectDestination(destStr, 'tourist', place.state);
  } else {
    state.trip.destination = destStr;
    const destInput = document.getElementById('destinationInput');
    if (destInput) destInput.value = destStr;
    if (typeof updateLiveBlueprint === 'function') updateLiveBlueprint();
  }

  // Pre-fill vibes based on category
  if (typeof setVibeState === 'function') {
    if (place.category === 'heritage') setVibeState('heritage', true);
    if (place.category === 'spiritual') setVibeState('spiritual', true);
    if (place.category === 'hill-station') setVibeState('hills', true);
    if (place.category === 'beach') setVibeState('beach', true);
    if (place.category === 'adventure') setVibeState('trekking', true);
  }

  showToast(`Loaded ${place.name} into BharatYatra Planner!`, 'success');
  if (typeof scrollToForm === 'function') {
    scrollToForm();
  }
}
