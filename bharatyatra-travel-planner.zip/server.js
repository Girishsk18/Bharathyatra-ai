require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { connectDB, getDBStatus } = require('./backend/config/db');
const errorHandler = require('./backend/middleware/errorHandler');

// Route Imports
const authRoutes = require('./backend/routes/authRoutes');
const destinationRoutes = require('./backend/routes/destinationRoutes');
const tripRoutes = require('./backend/routes/tripRoutes');
const aiRoutes = require('./backend/routes/aiRoutes');
const weatherRoutes = require('./backend/routes/weatherRoutes');
const mapRoutes = require('./backend/routes/mapRoutes');
const favouriteRoutes = require('./backend/routes/favouriteRoutes');

const app = express();

// Connect Database (MongoDB with automatic fallback)
connectDB();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// Serve Frontend Static Files
app.use(express.static(path.join(__dirname)));

// Health Check API
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    database: getDBStatus(),
    modules: {
      authentication: 'active',
      simpleTravel: 'active',
      destinationManagement: 'active',
      tripManagement: 'active',
      aiItinerary: 'active',
      budgetManager: 'active',
      mapIntegration: 'active',
      weatherIntegration: 'active',
      favourites: 'active'
    }
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/destinations', destinationRoutes);
app.use('/api/trips', tripRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/maps', mapRoutes);
app.use('/api/favourites', favouriteRoutes);

// Direct ZIP Download Endpoints
app.get('/download', (req, res) => {
  const zipPath = path.join(__dirname, 'bharatyatra-travel-planner.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'bharatyatra-travel-planner.zip');
  } else {
    res.status(404).send('ZIP file not found.');
  }
});

app.get('/download-zip', (req, res) => {
  res.redirect('/download');
});

// Fallback for SPA routing if needed
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Error Handling Middleware
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`\n======================================================`);
    console.log(`🚀 BharatYatra AI Backend Server running on port ${PORT}`);
    console.log(`📍 URL: http://localhost:${PORT}`);
    console.log(`📡 Health: http://localhost:${PORT}/api/health`);
    console.log(`✨ Modules: Auth, Trips, AI Itinerary, Budget, Weather, Maps`);
    console.log(`======================================================\n`);
  });
}

module.exports = app;

