# BharatYatra AI - Smart Travel Planner for Incredible India 🇮🇳

An AI-powered travel planning engine built exclusively for Indian tourist destinations across 28 states and union territories.

---

## 🏗️ System Architecture (As Per Specifications)

```
                     ┌────────────────────────────────────────┐
                     │                Frontend                │
                     │       React or HTML, CSS & JavaScript  │
                     └───────────────────┬────────────────────┘
                                         │ ▲
                                         ▼ │
                     ┌───────────────────┴────────────────────┐
                     │               Backend API              │
                     │            Node.js + Express.js        │
                     │  Authentication · Search · Trips · AI   │
                     └─────────┬────────────────────┬─────────┘
                               │ ▲                  │ ▲
                               ▼ │                  ▼ │
         ┌─────────────────────┴────────┐   ┌───────┴────────────────────┐
         │           MongoDB            │   │       External APIs        │
         │ Users · Trips · Favourites   │   │ AI (Gemini) · Maps ·       │
         │          Budgets             │   │ Weather · Travel Data      │
         └──────────────────────────────┘   └────────────────────────────┘
```

---

## 🌟 Main Modules & Responsibilities

| Module | Responsibility | Backend Endpoints |
|---|---|---|
| **Authentication** | Register, login and user profiles | `POST /api/auth/register`<br>`POST /api/auth/login`<br>`GET /api/auth/me`<br>`PUT /api/auth/profile` |
| **Simple Travel** | Search and explore destinations | `GET /api/destinations`<br>`GET /api/destinations/popular` |
| **Destination Management** | Store destination information | `GET /api/destinations/:id`<br>`GET /api/destinations/states-districts` |
| **Trip Management** | Create, edit and delete trips, share/export | `GET /api/trips`<br>`POST /api/trips`<br>`GET /api/trips/:id`<br>`PUT /api/trips/:id`<br>`DELETE /api/trips/:id`<br>`POST /api/trips/:id/share` |
| **AI Itinerary** | Generate day-wise schedules | `POST /api/ai/generate-itinerary` |
| **Budget Manager** | Estimate and record trip expenses | `GET /api/trips/:id/budget`<br>`POST /api/trips/:id/expenses`<br>`DELETE /api/trips/:id/expenses/:expenseId` |
| **Map Integration** | Display places, routes and transit options | `GET /api/maps/route` |
| **Weather Integration** | Weather forecast and seasonal advice | `GET /api/weather` |
| **Favourites** | Save destinations and trips | `GET /api/favourites`<br>`POST /api/favourites/toggle`<br>`GET /api/favourites/recent` |

---

## 🧭 Application Workflows

### 1. Simple Travel Dashboard Workflow
- **Open Simple Travel**
- Search destination or select a popular place
- Enter travel date and number of travellers
- Display destination details and travel options
- Explore hotels, attractions and transportation
- Save favourite places or open booking links

### 2. Trip Planner Dashboard Workflow
- **Open Trip Planner**
- Create a new trip
- Enter destination, start date and end date
- Set budget, travellers and interests
- Generate a day-wise itinerary using AI
- Add attractions, hotels and transportation
- View route map and estimated expenses
- Edit and save the itinerary
- Share or export the final trip plan

---

## 🛠️ How to Run Locally

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment (`.env`)
```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/bharatyatra
JWT_SECRET=bharatyatra_super_secret_jwt_key_2026_india
GEMINI_API_KEY=your_optional_gemini_api_key
```
> *Note: If a local MongoDB instance is not active, the backend automatically operates on an integrated high-speed zero-config JSON store, ensuring all endpoints and workflows function immediately.*

### 3. Run the Backend Server
```bash
npm start
```
Open **[http://localhost:5000](http://localhost:5000)** in your browser.

### 4. Run the Test Suite
```bash
npm test
```
Runs 8 automated end-to-end tests covering Auth, Simple Travel, Trips, AI Itinerary, Budgeting, Maps, Weather, and Favourites.
