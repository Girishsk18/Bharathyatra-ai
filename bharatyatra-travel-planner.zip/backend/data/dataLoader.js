const fs = require('fs');
const path = require('path');
const vm = require('vm');

let cachedDestinations = null;
let cachedStates = null;

function loadTouristPlaces() {
  if (cachedDestinations) return cachedDestinations;
  try {
    const filePath = path.join(__dirname, '..', '..', 'js', 'tourist-places-data.js');
    const code = fs.readFileSync(filePath, 'utf8').replace('const TOURIST_PLACES_DATA', 'globalThis.TOURIST_PLACES_DATA');
    const ctx = {};
    vm.runInNewContext(code, ctx);
    cachedDestinations = ctx.TOURIST_PLACES_DATA || [];
    return cachedDestinations;
  } catch (err) {
    console.error('Failed to load tourist-places-data.js:', err);
    return [];
  }
}

function loadStatesDistricts() {
  if (cachedStates) return cachedStates;
  try {
    const filePath = path.join(__dirname, '..', '..', 'js', 'states-districts-data.js');
    const code = fs.readFileSync(filePath, 'utf8').replace('const INDIA_STATES_DATA', 'globalThis.INDIA_STATES_DATA');
    const ctx = {};
    vm.runInNewContext(code, ctx);
    cachedStates = ctx.INDIA_STATES_DATA || [];
    return cachedStates;
  } catch (err) {
    console.error('Failed to load states-districts-data.js:', err);
    return [];
  }
}

module.exports = {
  loadTouristPlaces,
  loadStatesDistricts
};

