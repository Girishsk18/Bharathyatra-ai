const jwt = require('jsonwebtoken');
const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route. Please log in.'
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'bharatyatra_super_secret_jwt_key_2026_india');

    if (isUsingFallback()) {
      const users = store.getCollection('users');
      const user = users.find(u => u._id === decoded.id || u.id === decoded.id);
      if (!user) {
        return res.status(401).json({ success: false, message: 'User not found' });
      }
      req.user = user;
    } else {
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ success: false, message: 'User not found' });
      }
    }

    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Token is invalid or expired. Please log in again.'
    });
  }
};

// Optional auth for public routes that can be enhanced if logged in
const optionalAuth = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return next();
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'bharatyatra_super_secret_jwt_key_2026_india');
    if (isUsingFallback()) {
      const users = store.getCollection('users');
      req.user = users.find(u => u._id === decoded.id || u.id === decoded.id);
    } else {
      req.user = await User.findById(decoded.id).select('-password');
    }
  } catch (err) {
    // Ignore invalid token in optionalAuth
  }
  next();
};

module.exports = { protect, optionalAuth };

