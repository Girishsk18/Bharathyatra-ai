const mongoose = require('mongoose');

const dayActivitySchema = new mongoose.Schema({
  timeSlot: {
    type: String,
    enum: ['Morning', 'Afternoon', 'Evening', 'Night'],
    default: 'Morning'
  },
  time: String,
  title: { type: String, required: true },
  description: String,
  location: String,
  category: {
    type: String,
    enum: ['sightseeing', 'food', 'transit', 'activity', 'relaxation', 'shopping', 'other'],
    default: 'sightseeing'
  },
  cost: { type: Number, default: 0 },
  lat: Number,
  lng: Number,
  completed: { type: Boolean, default: false }
}, { _id: true });

const dayScheduleSchema = new mongoose.Schema({
  day: { type: Number, required: true },
  date: String,
  theme: String,
  activities: [dayActivitySchema],
  dailyNotes: String,
  estimatedCost: { type: Number, default: 0 }
}, { _id: true });

const expenseEntrySchema = new mongoose.Schema({
  title: { type: String, required: true },
  category: {
    type: String,
    enum: ['stay', 'transit', 'food', 'activities', 'shopping', 'misc'],
    default: 'misc'
  },
  amount: { type: Number, required: true },
  date: { type: String, default: () => new Date().toISOString().split('T')[0] },
  notes: String,
  paidBy: String,
  createdAt: { type: Date, default: Date.now }
}, { _id: true });

const tripSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: [true, 'Please provide a trip title']
  },
  destination: {
    type: String,
    required: [true, 'Please provide a destination']
  },
  destinationKey: {
    type: String,
    default: ''
  },
  state: String,
  origin: {
    type: String,
    default: 'New Delhi (DEL)'
  },
  startDate: {
    type: String,
    required: false
  },
  endDate: {
    type: String,
    required: false
  },
  durationDays: {
    type: Number,
    required: true,
    min: 1,
    max: 30,
    default: 4
  },
  party: {
    type: String,
    enum: ['solo', 'couple', 'family', 'friends', 'business'],
    default: 'couple'
  },
  adults: {
    type: Number,
    default: 2,
    min: 1
  },
  children: {
    type: Number,
    default: 0,
    min: 0
  },
  budgetTier: {
    type: String,
    enum: ['budget', 'mid-range', 'luxury'],
    default: 'mid-range'
  },
  budgetAmount: {
    type: Number,
    default: 30000
  },
  pace: {
    type: String,
    enum: ['relaxed', 'balanced', 'packed'],
    default: 'balanced'
  },
  vibes: [{
    type: String
  }],
  accommodation: {
    type: String,
    default: 'hotel'
  },
  transport: {
    type: String,
    default: 'cab'
  },
  dietary: [{
    type: String
  }],
  accessibility: [{
    type: String
  }],
  customNotes: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    enum: ['draft', 'planned', 'ongoing', 'completed', 'archived'],
    default: 'draft'
  },
  itinerary: {
    overview: String,
    totalEstimatedCost: Number,
    costBreakdown: {
      stay: { type: Number, default: 0 },
      transit: { type: Number, default: 0 },
      food: { type: Number, default: 0 },
      activities: { type: Number, default: 0 },
      buffer: { type: Number, default: 0 }
    },
    days: [dayScheduleSchema],
    weatherForecast: {
      summary: String,
      temperatureAvg: String,
      rainChance: String,
      packingTips: [String]
    },
    routeMap: {
      waypoints: [{
        name: String,
        lat: Number,
        lng: Number,
        type: String
      }],
      totalDistanceKm: Number,
      travelTimeHours: Number
    }
  },
  expenses: [expenseEntrySchema],
  isShared: {
    type: Boolean,
    default: false
  },
  shareId: {
    type: String,
    unique: true,
    sparse: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

tripSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.models.Trip || mongoose.model('Trip', tripSchema);

