const mongoose = require('mongoose');

const favouriteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  itemType: {
    type: String,
    enum: ['destination', 'trip'],
    default: 'destination'
  },
  itemId: {
    type: String,
    required: true
  },
  itemData: {
    type: Object,
    default: {}
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

favouriteSchema.index({ userId: 1, itemId: 1 }, { unique: true });

module.exports = mongoose.models.Favourite || mongoose.model('Favourite', favouriteSchema);

