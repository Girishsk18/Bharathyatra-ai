const mongoose = require('mongoose');

const destinationSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  state: {
    type: String,
    required: true
  },
  district: {
    type: String,
    required: true
  },
  zone: {
    type: String,
    enum: ['North', 'South', 'East', 'West', 'Central', 'North-East'],
    required: true
  },
  category: {
    type: String,
    enum: ['heritage', 'hill-station', 'spiritual', 'beach', 'wildlife', 'adventure'],
    required: true
  },
  image: {
    type: String,
    default: 'assets/images/jaipur.jpg'
  },
  rating: {
    type: Number,
    default: 4.5
  },
  reviewsCount: {
    type: String,
    default: '10k+'
  },
  idealDuration: {
    type: String,
    default: '2-3 Days'
  },
  bestSeason: {
    type: String,
    default: 'October to March'
  },
  budgetTier: {
    type: String,
    enum: ['budget', 'mid-range', 'luxury'],
    default: 'mid-range'
  },
  estimatedDailyBudget: {
    type: Number,
    default: 3000
  },
  tagline: String,
  description: String,
  highlights: [String],
  transit: {
    nearestAirport: String,
    nearestRailway: String,
    roadRoute: String
  },
  entryFee: String,
  timings: String,
  travelerTips: String,
  coordinates: {
    lat: Number,
    lng: Number
  },
  weather: {
    climate: String,
    currentTemp: String,
    condition: String,
    bestMonths: String
  },
  hotels: [{
    name: String,
    category: String,
    pricePerNight: Number,
    rating: Number,
    bookingLink: String
  }],
  attractions: [{
    name: String,
    timing: String,
    fee: String,
    description: String
  }]
}, {
  timestamps: true
});

module.exports = mongoose.models.Destination || mongoose.model('Destination', destinationSchema);

