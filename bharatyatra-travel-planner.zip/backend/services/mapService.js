const { loadTouristPlaces } = require('../data/dataLoader');

const CITY_COORDINATES = {
  delhi: { lat: 28.6139, lng: 77.2090, name: 'New Delhi', airport: 'DEL', station: 'New Delhi (NDLS)' },
  mumbai: { lat: 19.0760, lng: 72.8777, name: 'Mumbai', airport: 'BOM', station: 'Mumbai CSMT / Central' },
  bengaluru: { lat: 12.9716, lng: 77.5946, name: 'Bengaluru', airport: 'BLR', station: 'KSR Bengaluru (SBC)' },
  bangalore: { lat: 12.9716, lng: 77.5946, name: 'Bengaluru', airport: 'BLR', station: 'KSR Bengaluru (SBC)' },
  chennai: { lat: 13.0827, lng: 80.2707, name: 'Chennai', airport: 'MAA', station: 'Chennai Central (MAS)' },
  hyderabad: { lat: 17.3850, lng: 78.4867, name: 'Hyderabad', airport: 'HYD', station: 'Secunderabad Jn (SC)' },
  kolkata: { lat: 22.5726, lng: 88.3639, name: 'Kolkata', airport: 'CCU', station: 'Howrah Jn (HWH)' },
  pune: { lat: 18.5204, lng: 73.8567, name: 'Pune', airport: 'PNQ', station: 'Pune Jn (PUNE)' },
  ahmedabad: { lat: 23.0225, lng: 72.5714, name: 'Ahmedabad', airport: 'AMD', station: 'Ahmedabad Jn (ADI)' },
  jaipur: { lat: 26.9124, lng: 75.7873, name: 'Jaipur', airport: 'JAI', station: 'Jaipur Jn (JP)' },
  lucknow: { lat: 26.8467, lng: 80.9462, name: 'Lucknow', airport: 'LKO', station: 'Lucknow Charbagh (LKO)' },
  chandigarh: { lat: 30.7333, lng: 76.7794, name: 'Chandigarh', airport: 'IXC', station: 'Chandigarh Jn (CDG)' },
  kochi: { lat: 9.9312, lng: 76.2673, name: 'Kochi', airport: 'COK', station: 'Ernakulam Jn (ERS)' },
  goa: { lat: 15.2993, lng: 74.1240, name: 'Goa', airport: 'GOI', station: 'Madgaon Jn (MAO)' },
  manali: { lat: 32.2432, lng: 77.1892, name: 'Manali', airport: 'KUU', station: 'Chandigarh Jn (CDG)' },
  varanasi: { lat: 25.3176, lng: 82.9739, name: 'Varanasi', airport: 'VNS', station: 'Varanasi Jn (BSB)' },
  ladakh: { lat: 34.1526, lng: 77.5771, name: 'Leh-Ladakh', airport: 'IXL', station: 'Jammu Tawi (JAT)' },
  udaipur: { lat: 24.5854, lng: 73.7125, name: 'Udaipur', airport: 'UDR', station: 'Udaipur City (UDZ)' },
  rishikesh: { lat: 30.0869, lng: 78.2676, name: 'Rishikesh', airport: 'DED', station: 'Yog Nagari Rishikesh (YNRK)' },
  ooty: { lat: 11.4102, lng: 76.6950, name: 'Ooty', airport: 'CJB', station: 'Mettupalayam (MTP)' },
  hampi: { lat: 15.3350, lng: 76.4600, name: 'Hampi', airport: 'VDY', station: 'Hosapete Jn (HPT)' },
  darjeeling: { lat: 27.0410, lng: 88.2663, name: 'Darjeeling', airport: 'IXB', station: 'New Jalpaiguri (NJP)' },
  surat: { lat: 21.1702, lng: 72.8311, name: 'Surat', airport: 'STV', station: 'Surat (ST)' },
  nagpur: { lat: 21.1458, lng: 79.0882, name: 'Nagpur', airport: 'NAG', station: 'Nagpur Jn (NGP)' },
  indore: { lat: 22.7196, lng: 75.8577, name: 'Indore', airport: 'IDR', station: 'Indore Jn (INDB)' },
  bhopal: { lat: 23.2599, lng: 77.4126, name: 'Bhopal', airport: 'BHO', station: 'Rani Kamalapati (RKMP)' },
  patna: { lat: 25.5941, lng: 85.1376, name: 'Patna', airport: 'PAT', station: 'Patna Jn (PNBE)' },
  guwahati: { lat: 26.1445, lng: 91.7362, name: 'Guwahati', airport: 'GAU', station: 'Guwahati (GHY)' }
};

function getCoordsForPlace(nameStr, defaultLat = 28.6139, defaultLng = 77.2090) {
  if (!nameStr) return { lat: defaultLat, lng: defaultLng, name: 'Origin' };
  const s = nameStr.toLowerCase();

  for (const [key, hub] of Object.entries(CITY_COORDINATES)) {
    if (s.includes(key) || s.includes(hub.name.toLowerCase())) {
      return hub;
    }
  }
  return { lat: defaultLat, lng: defaultLng, name: nameStr.split(',')[0].trim() };
}

function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return Math.max(80, Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * 1.25));
}

function getRouteForDestination({ origin = 'New Delhi', destination = 'Jaipur', stops = [] }) {
  const places = loadTouristPlaces();
  const matchedPlace = places.find(p =>
    p.name.toLowerCase().includes(destination.toLowerCase()) ||
    (p.district && destination.toLowerCase().includes(p.district.toLowerCase()))
  ) || places[0];

  const destCoords = matchedPlace.coordinates || { lat: 26.9124, lng: 75.7873 };
  const originInfo = getCoordsForPlace(origin, 28.6139, 77.2090);

  const distanceKm = calculateDistanceKm(originInfo.lat, originInfo.lng, destCoords.lat, destCoords.lng);

  // Calculate approximate waypoints
  const waypoints = [
    {
      name: originInfo.name || origin,
      type: 'origin',
      lat: originInfo.lat,
      lng: originInfo.lng,
      description: `Starting departure hub: ${origin}`
    },
    {
      name: `${matchedPlace.name} Main Hub`,
      type: 'destination_primary',
      lat: destCoords.lat,
      lng: destCoords.lng,
      description: matchedPlace.tagline || 'Core historical & cultural center'
    }
  ];

  // Add highlights as route stops
  if (matchedPlace.highlights && matchedPlace.highlights.length) {
    matchedPlace.highlights.slice(0, 4).forEach((h, index) => {
      waypoints.push({
        name: h,
        type: 'attraction',
        lat: Number((destCoords.lat + (index * 0.015 - 0.02)).toFixed(4)),
        lng: Number((destCoords.lng + (index * 0.012 - 0.015)).toFixed(4)),
        description: `Highlight ${index + 1} on the circuit`
      });
    });
  }

  // Calculate transit durations and costs based on distance
  const flightMins = Math.round(Math.max(50, (distanceKm * 0.08) + 35));
  const flightDuration = `${Math.floor(flightMins / 60)}h ${flightMins % 60}m`;
  const flightPrice = `₹${(Math.round(2800 + distanceKm * 1.8)).toLocaleString('en-IN')} - ₹${(Math.round(4200 + distanceKm * 2.2)).toLocaleString('en-IN')}`;

  const isVandeBharat = distanceKm <= 750;
  const trainHours = (distanceKm / (isVandeBharat ? 90 : 70)).toFixed(1);
  const trainDuration = `${Math.floor(trainHours)} hrs ${Math.round((trainHours % 1) * 60)} mins`;
  const trainPrice = `₹${(Math.round(550 + distanceKm * 0.9)).toLocaleString('en-IN')} - ₹${(Math.round(1100 + distanceKm * 1.6)).toLocaleString('en-IN')}`;

  const roadHours = (distanceKm / 58).toFixed(1);
  const roadDuration = `${Math.floor(roadHours)} hrs ${Math.round((roadHours % 1) * 60)} mins`;
  const cabPrice = `₹${(Math.round(distanceKm * 11)).toLocaleString('en-IN')} - ₹${(Math.round(distanceKm * 15)).toLocaleString('en-IN')}`;

  return {
    origin,
    destination: matchedPlace.name,
    distanceKm,
    transitOptions: {
      flight: {
        duration: flightDuration,
        modes: ['IndiGo', 'Air India', 'Akasa Air'],
        approxPrice: flightPrice
      },
      train: {
        duration: trainDuration,
        modes: [isVandeBharat ? 'Vande Bharat Express' : 'Rajdhani / Superfast Express', 'Shatabdi / Express'],
        approxPrice: trainPrice
      },
      road: {
        duration: roadDuration,
        modes: ['Outstation AC Cab', `National Highway corridor (${originInfo.name} to ${matchedPlace.name})`],
        approxPrice: cabPrice
      }
    },
    waypoints
  };
}

module.exports = {
  getRouteForDestination
};
