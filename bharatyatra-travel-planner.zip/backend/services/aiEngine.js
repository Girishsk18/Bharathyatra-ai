const { loadTouristPlaces } = require('../data/dataLoader');

/**
 * Intelligent AI Travel Engine for Incredible India
 * Generates day-wise customized itineraries, budget breakdowns, route waypoints, and packing notes.
 */
async function generateItineraryPlan({
  destination,
  destinationKey,
  origin = 'New Delhi',
  durationDays = 3,
  budgetAmount = 30000,
  budgetTier = 'mid-range',
  party = 'couple',
  adults = 2,
  children = 0,
  pace = 'balanced',
  vibes = ['heritage', 'culture', 'food'],
  accommodation = 'hotel',
  transport = 'cab',
  dietary = ['vegetarian'],
  customNotes = ''
}) {
  const days = Math.max(1, Math.min(30, Number(durationDays) || 3));
  const totalTravelers = (Number(adults) || 1) + (Number(children) || 0);

  // If GEMINI_API_KEY is available, we can optionally call Gemini
  if (process.env.GEMINI_API_KEY) {
    try {
      const geminiResult = await callGeminiAPI({
        destination,
        days,
        budgetAmount,
        budgetTier,
        party,
        totalTravelers,
        pace,
        vibes,
        customNotes
      });
      if (geminiResult) return geminiResult;
    } catch (err) {
      console.warn('Gemini API call fell back to local AI engine:', err.message);
    }
  }

  // Find matching destination or closest match
  const places = loadTouristPlaces();
  const matchedPlace = places.find(p =>
    (destinationKey && p.id === destinationKey) ||
    p.name.toLowerCase().includes(destination.toLowerCase()) ||
    (p.district && destination.toLowerCase().includes(p.district.toLowerCase()))
  ) || places[0];

  // Budget calculations
  const totalBudget = Number(budgetAmount) || (matchedPlace?.estimatedDailyBudget || 4000) * days * totalTravelers;
  const stayCost = Math.round(totalBudget * 0.38);
  const transitCost = Math.round(totalBudget * 0.22);
  const foodCost = Math.round(totalBudget * 0.20);
  const activitiesCost = Math.round(totalBudget * 0.12);
  const bufferCost = totalBudget - (stayCost + transitCost + foodCost + activitiesCost);

  // Day themes based on vibes and destination
  const dayThemes = [
    `Arrival, Old Quarter Heritage & Local Welcome`,
    `Iconic Monuments, Royal Architecture & Photo Walks`,
    `Hidden Treasures, Cultural Bazaars & Traditional Dining`,
    `Nature Scenic Escapes, Sunrise Viewpoint & Outskirts`,
    `Artisan Villages, Spiritual Ghats & Evening Ceremonies`,
    `Leisure, Local Crafts Shopping & Grand Farewell Feast`
  ];

  const CITY_COORDS = {
    delhi: { lat: 28.6139, lng: 77.2090 },
    mumbai: { lat: 19.0760, lng: 72.8777 },
    bengaluru: { lat: 12.9716, lng: 77.5946 },
    bangalore: { lat: 12.9716, lng: 77.5946 },
    chennai: { lat: 13.0827, lng: 80.2707 },
    hyderabad: { lat: 17.3850, lng: 78.4867 },
    kolkata: { lat: 22.5726, lng: 88.3639 },
    pune: { lat: 18.5204, lng: 73.8567 },
    ahmedabad: { lat: 23.0225, lng: 72.5714 },
    jaipur: { lat: 26.9124, lng: 75.7873 },
    lucknow: { lat: 26.8467, lng: 80.9462 },
    chandigarh: { lat: 30.7333, lng: 76.7794 },
    kochi: { lat: 9.9312, lng: 76.2673 },
    goa: { lat: 15.2993, lng: 74.1240 }
  };

  const oKey = Object.keys(CITY_COORDS).find(k => (origin || '').toLowerCase().includes(k));
  const origCoords = oKey ? CITY_COORDS[oKey] : { lat: 28.6139, lng: 77.2090 };

  // Build day-wise schedule
  const scheduleDays = [];
  const waypoints = [
    { name: `${origin} (Departure)`, lat: origCoords.lat, lng: origCoords.lng, type: 'origin' }
  ];

  // Base coordinates for destination
  const baseLat = matchedPlace?.coordinates?.lat || 26.9124;
  const baseLng = matchedPlace?.coordinates?.lng || 75.7873;

  for (let i = 1; i <= days; i++) {
    const theme = dayThemes[(i - 1) % dayThemes.length];
    const dailyEst = Math.round(totalBudget / days);

    const latOffset = (Math.sin(i) * 0.05);
    const lngOffset = (Math.cos(i) * 0.05);
    const currentLat = Number((baseLat + latOffset).toFixed(4));
    const currentLng = Number((baseLng + lngOffset).toFixed(4));

    waypoints.push({
      name: `Day ${i}: ${matchedPlace.name} Circuit ${i}`,
      lat: currentLat,
      lng: currentLng,
      type: 'attraction'
    });

    const activities = [
      {
        timeSlot: 'Morning',
        time: '08:30 AM - 11:30 AM',
        title: i === 1 ? `Check-in & Morning Heritage Exploration` : `Iconic Landmark Sunrise Visit`,
        description: `Explore the morning golden hour at ${matchedPlace.name}. Enjoy fresh regional breakfast and guided historical walkthrough.`,
        location: matchedPlace.district || destination,
        category: 'sightseeing',
        cost: Math.round(dailyEst * 0.25),
        lat: currentLat,
        lng: currentLng,
        completed: false
      },
      {
        timeSlot: 'Afternoon',
        time: '01:00 PM - 04:00 PM',
        title: `Authentic Regional Gastronomy & Museum Tour`,
        description: `Relish traditional ${matchedPlace.state} thali meal (${dietary.join(', ')} friendly). Visit local museum and cultural exhibition.`,
        location: matchedPlace.name,
        category: 'food',
        cost: Math.round(dailyEst * 0.3),
        lat: currentLat + 0.01,
        lng: currentLng + 0.01,
        completed: false
      },
      {
        timeSlot: 'Evening',
        time: '05:30 PM - 08:00 PM',
        title: `Sunset Viewpoint & Bazaars Exploration`,
        description: `Scenic sunset overlooking the valley/monument. Stroll through bustling bazaars for spices, textiles and handicrafts.`,
        location: `${matchedPlace.name} High Point`,
        category: 'shopping',
        cost: Math.round(dailyEst * 0.25),
        lat: currentLat - 0.01,
        lng: currentLng - 0.01,
        completed: false
      },
      {
        timeSlot: 'Night',
        time: '08:30 PM - 10:30 PM',
        title: `Cultural Folk Music & Rooftop Dinner`,
        description: `Relax with live Rajasthani/regional folk instruments under starlit skies with curated chef specialties.`,
        location: `${destination} Heritage Rooftop`,
        category: 'relaxation',
        cost: Math.round(dailyEst * 0.2),
        lat: currentLat,
        lng: currentLng,
        completed: false
      }
    ];

    scheduleDays.push({
      day: i,
      date: `Day ${i}`,
      theme,
      activities,
      dailyNotes: `Tip: Wear comfortable walking shoes. Keep hydrated and carry cash for local street vendors.`,
      estimatedCost: dailyEst
    });
  }

  return {
    overview: `A tailor-made ${days}-day ${pace} itinerary crafted for ${totalTravelers} traveller(s) visiting ${destination}. Focusing on ${vibes.join(', ')} with ${accommodation} stay and ${transport} transit.`,
    totalEstimatedCost: totalBudget,
    costBreakdown: {
      stay: stayCost,
      transit: transitCost,
      food: foodCost,
      activities: activitiesCost,
      buffer: bufferCost
    },
    days: scheduleDays,
    weatherForecast: {
      summary: matchedPlace.bestSeason ? `Best season to visit: ${matchedPlace.bestSeason}` : 'Moderate and pleasant weather',
      temperatureAvg: '22°C - 31°C',
      rainChance: '10% (Clear skies)',
      packingTips: [
        'Light cotton clothes for daytime',
        'Light shawl or jacket for evenings/temple visits',
        'Power bank and comfortable walking footwear',
        'Valid ID proofs for monument entry'
      ]
    },
    routeMap: {
      waypoints,
      totalDistanceKm: days * 45,
      travelTimeHours: days * 2.5
    }
  };
}

async function callGeminiAPI({ destination, days, budgetAmount, budgetTier, party, totalTravelers, pace, vibes, customNotes }) {
  // Safe Gemini REST call when API key is provided
  const apiKey = process.env.GEMINI_API_KEY;
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
  
  const prompt = `You are BharatYatra AI, an expert Indian travel planner.
Generate a strictly valid JSON itinerary for a ${days}-day trip to ${destination}, India.
Details:
- Travelers: ${totalTravelers} (${party})
- Budget: INR ${budgetAmount} (${budgetTier})
- Pace: ${pace}
- Vibes: ${vibes.join(', ')}
- Custom Notes: ${customNotes}

Respond ONLY with valid JSON with keys:
"overview" (string),
"totalEstimatedCost" (number),
"costBreakdown" (object with stay, transit, food, activities, buffer numbers),
"days" (array of ${days} objects with day number, theme string, and activities array with timeSlot, time, title, description, location, category, cost),
"weatherForecast" (summary, temperatureAvg, rainChance, packingTips array),
"routeMap" (waypoints array, totalDistanceKm, travelTimeHours).`;

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: "application/json" }
    })
  });

  if (!response.ok) {
    throw new Error(`Gemini API returned status ${response.status}`);
  }

  const json = await response.json();
  const text = json.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) return null;
  return JSON.parse(text);
}

module.exports = {
  generateItineraryPlan
};

