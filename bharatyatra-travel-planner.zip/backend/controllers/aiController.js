const { generateItineraryPlan } = require('../services/aiEngine');

// @route   POST /api/ai/generate-itinerary
// @desc    Generate AI day-wise itinerary
// @access  Public (or authenticated)
exports.generateItinerary = async (req, res, next) => {
  try {
    const {
      destination,
      destinationKey,
      origin,
      startDate,
      endDate,
      durationDays,
      budgetAmount,
      budgetTier,
      party,
      adults,
      children,
      pace,
      vibes,
      accommodation,
      transport,
      dietary,
      accessibility,
      customNotes
    } = req.body;

    if (!destination) {
      return res.status(400).json({
        success: false,
        message: 'Destination is required for itinerary generation'
      });
    }

    const itinerary = await generateItineraryPlan({
      destination,
      destinationKey,
      origin,
      durationDays: Number(durationDays) || 3,
      budgetAmount: Number(budgetAmount) || 30000,
      budgetTier: budgetTier || 'mid-range',
      party: party || 'couple',
      adults: Number(adults) || 2,
      children: Number(children) || 0,
      pace: pace || 'balanced',
      vibes: Array.isArray(vibes) ? vibes : ['heritage', 'culture'],
      accommodation: accommodation || 'hotel',
      transport: transport || 'cab',
      dietary: Array.isArray(dietary) ? dietary : ['vegetarian'],
      accessibility: Array.isArray(accessibility) ? accessibility : [],
      customNotes: customNotes || ''
    });

    res.status(200).json({
      success: true,
      message: 'Itinerary generated successfully',
      data: itinerary
    });
  } catch (err) {
    next(err);
  }
};

