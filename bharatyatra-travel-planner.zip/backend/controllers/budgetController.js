const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const Trip = require('../models/Trip');

// @route   GET /api/trips/:id/budget
// @desc    Get budget estimation, category distribution, and total expenses
// @access  Private
exports.getTripBudget = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;

    let trip;
    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      trip = trips.find(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));
    } else {
      trip = await Trip.findOne({ _id: id, userId });
    }

    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    const totalBudget = trip.budgetAmount || 30000;
    const expenses = trip.expenses || [];
    const totalSpent = expenses.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    const remaining = totalBudget - totalSpent;

    // Breakdown of expenses by category
    const categoryTotals = {
      stay: 0,
      transit: 0,
      food: 0,
      activities: 0,
      shopping: 0,
      misc: 0
    };

    expenses.forEach(item => {
      const cat = item.category || 'misc';
      if (categoryTotals[cat] !== undefined) {
        categoryTotals[cat] += Number(item.amount) || 0;
      } else {
        categoryTotals.misc += Number(item.amount) || 0;
      }
    });

    const plannedBreakdown = trip.itinerary?.costBreakdown || {
      stay: Math.round(totalBudget * 0.38),
      transit: Math.round(totalBudget * 0.22),
      food: Math.round(totalBudget * 0.20),
      activities: Math.round(totalBudget * 0.12),
      buffer: Math.round(totalBudget * 0.08)
    };

    res.status(200).json({
      success: true,
      data: {
        totalBudget,
        totalSpent,
        remaining,
        percentSpent: Math.min(100, Math.round((totalSpent / totalBudget) * 100)),
        isOverBudget: totalSpent > totalBudget,
        plannedBreakdown,
        categoryTotals,
        expenses
      }
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/trips/:id/expenses
// @desc    Add a new expense to a trip
// @access  Private
exports.addTripExpense = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;
    const { title, category, amount, date, notes, paidBy } = req.body;

    if (!title || amount === undefined || isNaN(amount)) {
      return res.status(400).json({
        success: false,
        message: 'Expense title and a valid amount are required'
      });
    }

    const newExpense = {
      _id: 'exp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      title: title.trim(),
      category: category || 'misc',
      amount: Number(amount),
      date: date || new Date().toISOString().split('T')[0],
      notes: notes || '',
      paidBy: paidBy || req.user.name || 'User',
      createdAt: new Date().toISOString()
    };

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const index = trips.findIndex(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));

      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      if (!trips[index].expenses) trips[index].expenses = [];
      trips[index].expenses.push(newExpense);
      trips[index].updatedAt = new Date().toISOString();
      store.saveCollection('trips', trips);

      return res.status(201).json({
        success: true,
        message: 'Expense recorded successfully',
        data: newExpense
      });
    }

    const trip = await Trip.findOne({ _id: id, userId });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    trip.expenses.push(newExpense);
    await trip.save();

    res.status(201).json({
      success: true,
      message: 'Expense recorded successfully',
      data: newExpense
    });
  } catch (err) {
    next(err);
  }
};

// @route   DELETE /api/trips/:id/expenses/:expenseId
// @desc    Remove an expense from a trip
// @access  Private
exports.deleteTripExpense = async (req, res, next) => {
  try {
    const { id, expenseId } = req.params;
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const index = trips.findIndex(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));

      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      const initialLen = (trips[index].expenses || []).length;
      trips[index].expenses = (trips[index].expenses || []).filter(e => e._id !== expenseId && e.id !== expenseId);

      if (trips[index].expenses.length === initialLen) {
        return res.status(404).json({ success: false, message: 'Expense entry not found' });
      }

      trips[index].updatedAt = new Date().toISOString();
      store.saveCollection('trips', trips);

      return res.status(200).json({
        success: true,
        message: 'Expense removed successfully'
      });
    }

    const trip = await Trip.findOne({ _id: id, userId });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    const initialLen = trip.expenses.length;
    trip.expenses = trip.expenses.filter(e => e._id.toString() !== expenseId);

    if (trip.expenses.length === initialLen) {
      return res.status(404).json({ success: false, message: 'Expense entry not found' });
    }

    await trip.save();

    res.status(200).json({
      success: true,
      message: 'Expense removed successfully'
    });
  } catch (err) {
    next(err);
  }
};

