const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const User = require('../models/User');

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'bharatyatra_super_secret_jwt_key_2026_india', {
    expiresIn: '30d'
  });
};

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
exports.register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email and password'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters'
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (isUsingFallback()) {
      const users = store.getCollection('users');
      const existing = users.find(u => u.email === cleanEmail);
      if (existing) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email already exists'
        });
      }

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      const newUser = {
        _id: 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
        name: name.trim(),
        email: cleanEmail,
        password: hashedPassword,
        avatar: name.trim().charAt(0).toUpperCase(),
        role: 'user',
        preferredDashboard: null,
        preferences: { currency: 'INR', theme: 'dark', travelStyle: 'balanced' },
        createdAt: new Date().toISOString()
      };

      users.push(newUser);
      store.saveCollection('users', users);

      const token = generateToken(newUser._id);
      const { password: _, ...userWithoutPassword } = newUser;

      return res.status(201).json({
        success: true,
        message: 'User registered successfully',
        token,
        user: userWithoutPassword
      });
    }

    // MongoDB Mode
    const userExists = await User.findOne({ email: cleanEmail });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists'
      });
    }

    const user = await User.create({
      name,
      email: cleanEmail,
      password,
      avatar: name.charAt(0).toUpperCase()
    });

    const token = generateToken(user._id);

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        role: user.role,
        preferredDashboard: user.preferredDashboard,
        preferences: user.preferences
      }
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/auth/login
// @desc    Authenticate user & get token
// @access  Public
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (isUsingFallback()) {
      const users = store.getCollection('users');
      const user = users.find(u => u.email === cleanEmail);

      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials. User not found.'
        });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password'
        });
      }

      const token = generateToken(user._id);
      const { password: _, ...userWithoutPassword } = user;

      return res.status(200).json({
        success: true,
        message: 'Logged in successfully',
        token,
        user: userWithoutPassword
      });
    }

    // MongoDB Mode
    const user = await User.findOne({ email: cleanEmail }).select('+password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. User not found.'
      });
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const token = generateToken(user._id);

    res.status(200).json({
      success: true,
      message: 'Logged in successfully',
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        role: user.role,
        preferredDashboard: user.preferredDashboard,
        preferences: user.preferences
      }
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/auth/me
// @desc    Get current user profile
// @access  Private
exports.getMe = async (req, res, next) => {
  try {
    const user = req.user;
    if (user.password) {
      delete user.password;
    }
    res.status(200).json({
      success: true,
      user
    });
  } catch (err) {
    next(err);
  }
};

// @route   PUT /api/auth/profile
// @desc    Update user profile & preferences
// @access  Private
exports.updateProfile = async (req, res, next) => {
  try {
    const { name, avatar, preferredDashboard, preferences } = req.body;
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const users = store.getCollection('users');
      const index = users.findIndex(u => u._id === userId || u.id === userId);
      if (index === -1) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      if (name) users[index].name = name;
      if (avatar) users[index].avatar = avatar;
      if (preferredDashboard !== undefined) users[index].preferredDashboard = preferredDashboard;
      if (preferences) users[index].preferences = { ...users[index].preferences, ...preferences };

      store.saveCollection('users', users);
      const { password: _, ...userWithoutPassword } = users[index];

      return res.status(200).json({
        success: true,
        message: 'Profile updated successfully',
        user: userWithoutPassword
      });
    }

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        ...(name && { name }),
        ...(avatar && { avatar }),
        ...(preferredDashboard !== undefined && { preferredDashboard }),
        ...(preferences && { preferences })
      },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      user: updatedUser
    });
  } catch (err) {
    next(err);
  }
};

