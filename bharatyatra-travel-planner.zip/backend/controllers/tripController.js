const crypto = require('crypto');
const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const Trip = require('../models/Trip');
const { generateItineraryPlan } = require('../services/aiEngine');

// Helper to generate a clean share ID
const generateShareId = () => crypto.randomBytes(6).toString('hex');

// @route   GET /api/trips
// @desc    Get all trips for current logged-in user
// @access  Private
exports.getUserTrips = async (req, res, next) => {
  try {
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const userTrips = trips
        .filter(t => t.userId === userId || t.userId?.toString() === userId.toString())
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      return res.status(200).json({
        success: true,
        count: userTrips.length,
        data: userTrips
      });
    }

    const trips = await Trip.find({ userId }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: trips.length,
      data: trips
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/trips
// @desc    Create a new trip
// @access  Private
exports.createTrip = async (req, res, next) => {
  try {
    const userId = req.user._id || req.user.id;
    const {
      title,
      destination,
      destinationKey,
      state,
      origin,
      startDate,
      endDate,
      durationDays,
      party,
      adults,
      children,
      budgetTier,
      budgetAmount,
      pace,
      vibes,
      accommodation,
      transport,
      dietary,
      accessibility,
      customNotes,
      autoGenerateItinerary = true
    } = req.body;

    if (!destination) {
      return res.status(400).json({
        success: false,
        message: 'Destination is required'
      });
    }

    const tripTitle = title || `${destination} Yatra (${durationDays || 4} Days)`;

    let itineraryData = req.body.itinerary || null;

    // Auto-generate itinerary if requested and not provided
    if (autoGenerateItinerary && !itineraryData) {
      itineraryData = await generateItineraryPlan({
        destination,
        destinationKey,
        origin,
        durationDays: durationDays || 4,
        budgetAmount: budgetAmount || 30000,
        budgetTier: budgetTier || 'mid-range',
        party: party || 'couple',
        adults: adults || 2,
        children: children || 0,
        pace: pace || 'balanced',
        vibes: vibes || ['heritage', 'culture', 'food'],
        accommodation: accommodation || 'hotel',
        transport: transport || 'cab',
        dietary: dietary || ['vegetarian'],
        customNotes: customNotes || ''
      });
    }

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const newTrip = {
        _id: 'trip_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
        userId,
        title: tripTitle,
        destination,
        destinationKey: destinationKey || '',
        state: state || '',
        origin: origin || 'New Delhi (DEL)',
        startDate: startDate || '',
        endDate: endDate || '',
        durationDays: Number(durationDays) || 4,
        party: party || 'couple',
        adults: Number(adults) || 2,
        children: Number(children) || 0,
        budgetTier: budgetTier || 'mid-range',
        budgetAmount: Number(budgetAmount) || 30000,
        pace: pace || 'balanced',
        vibes: vibes || ['heritage', 'food'],
        accommodation: accommodation || 'hotel',
        transport: transport || 'cab',
        dietary: dietary || ['vegetarian'],
        accessibility: accessibility || [],
        customNotes: customNotes || '',
        status: itineraryData ? 'planned' : 'draft',
        itinerary: itineraryData,
        expenses: [],
        isShared: false,
        shareId: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      trips.unshift(newTrip);
      store.saveCollection('trips', trips);

      return res.status(201).json({
        success: true,
        message: 'Trip created successfully',
        data: newTrip
      });
    }

    const trip = await Trip.create({
      userId,
      title: tripTitle,
      destination,
      destinationKey,
      state,
      origin,
      startDate,
      endDate,
      durationDays: Number(durationDays) || 4,
      party,
      adults: Number(adults) || 2,
      children: Number(children) || 0,
      budgetTier,
      budgetAmount: Number(budgetAmount) || 30000,
      pace,
      vibes,
      accommodation,
      transport,
      dietary,
      accessibility,
      customNotes,
      status: itineraryData ? 'planned' : 'draft',
      itinerary: itineraryData,
      expenses: []
    });

    res.status(201).json({
      success: true,
      message: 'Trip created successfully',
      data: trip
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/trips/:id
// @desc    Get trip by ID
// @access  Private
exports.getTripById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const trip = trips.find(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));

      if (!trip) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      return res.status(200).json({ success: true, data: trip });
    }

    const trip = await Trip.findOne({ _id: id, userId });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    res.status(200).json({ success: true, data: trip });
  } catch (err) {
    next(err);
  }
};

// @route   PUT /api/trips/:id
// @desc    Update/edit trip & itinerary
// @access  Private
exports.updateTrip = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const index = trips.findIndex(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));

      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      const updatedTrip = {
        ...trips[index],
        ...req.body,
        _id: trips[index]._id,
        userId: trips[index].userId,
        updatedAt: new Date().toISOString()
      };

      trips[index] = updatedTrip;
      store.saveCollection('trips', trips);

      return res.status(200).json({
        success: true,
        message: 'Trip updated successfully',
        data: updatedTrip
      });
    }

    const trip = await Trip.findOneAndUpdate(
      { _id: id, userId },
      { ...req.body, updatedAt: Date.now() },
      { new: true, runValidators: true }
    );

    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    res.status(200).json({
      success: true,
      message: 'Trip updated successfully',
      data: trip
    });
  } catch (err) {
    next(err);
  }
};

// @route   DELETE /api/trips/:id
// @desc    Delete trip
// @access  Private
exports.deleteTrip = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const filtered = trips.filter(t => !((t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString())));

      if (filtered.length === trips.length) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      store.saveCollection('trips', filtered);
      return res.status(200).json({
        success: true,
        message: 'Trip deleted successfully'
      });
    }

    const trip = await Trip.findOneAndDelete({ _id: id, userId });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    res.status(200).json({
      success: true,
      message: 'Trip deleted successfully'
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/trips/:id/share
// @desc    Enable sharing and get shareable link
// @access  Private
exports.shareTrip = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user._id || req.user.id;

    const shareId = generateShareId();

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const index = trips.findIndex(t => (t._id === id || t.id === id) && (t.userId === userId || t.userId?.toString() === userId.toString()));

      if (index === -1) {
        return res.status(404).json({ success: false, message: 'Trip not found' });
      }

      trips[index].isShared = true;
      trips[index].shareId = trips[index].shareId || shareId;
      store.saveCollection('trips', trips);

      return res.status(200).json({
        success: true,
        shareId: trips[index].shareId,
        shareUrl: `/shared-trip.html?shareId=${trips[index].shareId}`
      });
    }

    const trip = await Trip.findOne({ _id: id, userId });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Trip not found' });
    }

    if (!trip.shareId) {
      trip.shareId = shareId;
    }
    trip.isShared = true;
    await trip.save();

    res.status(200).json({
      success: true,
      shareId: trip.shareId,
      shareUrl: `/shared-trip.html?shareId=${trip.shareId}`
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/trips/shared/:shareId
// @desc    Get publicly shared trip
// @access  Public
exports.getSharedTrip = async (req, res, next) => {
  try {
    const { shareId } = req.params;

    if (isUsingFallback()) {
      const trips = store.getCollection('trips');
      const trip = trips.find(t => t.shareId === shareId && t.isShared);
      if (!trip) {
        return res.status(404).json({ success: false, message: 'Shared trip not found or inactive' });
      }
      return res.status(200).json({ success: true, data: trip });
    }

    const trip = await Trip.findOne({ shareId, isShared: true });
    if (!trip) {
      return res.status(404).json({ success: false, message: 'Shared trip not found or inactive' });
    }

    res.status(200).json({ success: true, data: trip });
  } catch (err) {
    next(err);
  }
};

