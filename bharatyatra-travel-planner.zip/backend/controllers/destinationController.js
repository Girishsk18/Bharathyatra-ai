const { loadTouristPlaces, loadStatesDistricts } = require('../data/dataLoader');
const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const Destination = require('../models/Destination');

// @route   GET /api/destinations
// @desc    Get destinations with search, filter, pagination
// @access  Public
exports.getDestinations = async (req, res, next) => {
  try {
    const {
      search = '',
      category = 'all',
      state = 'all',
      season = 'all',
      budgetTier = 'all',
      zone = 'all',
      limit = 100,
      page = 1
    } = req.query;

    let items = loadTouristPlaces();

    // Search filter (name, district, state, highlights, description)
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      items = items.filter(d =>
        (d.name && d.name.toLowerCase().includes(q)) ||
        (d.district && d.district.toLowerCase().includes(q)) ||
        (d.state && d.state.toLowerCase().includes(q)) ||
        (d.tagline && d.tagline.toLowerCase().includes(q)) ||
        (d.highlights && d.highlights.some(h => h.toLowerCase().includes(q)))
      );
    }

    // Category filter
    if (category !== 'all') {
      items = items.filter(d => d.category && d.category.toLowerCase() === category.toLowerCase());
    }

    // State filter
    if (state !== 'all') {
      items = items.filter(d => d.state && d.state.toLowerCase() === state.toLowerCase());
    }

    // Season filter
    if (season !== 'all') {
      items = items.filter(d => d.bestSeason && d.bestSeason.toLowerCase().includes(season.toLowerCase()));
    }

    // Budget Tier filter
    if (budgetTier !== 'all') {
      items = items.filter(d => d.budgetTier && d.budgetTier.toLowerCase() === budgetTier.toLowerCase());
    }

    // Zone filter
    if (zone !== 'all') {
      items = items.filter(d => d.zone && d.zone.toLowerCase() === zone.toLowerCase());
    }

    const total = items.length;
    const startIndex = (Number(page) - 1) * Number(limit);
    const paginatedItems = items.slice(startIndex, startIndex + Number(limit));

    res.status(200).json({
      success: true,
      count: paginatedItems.length,
      total,
      data: paginatedItems
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/destinations/popular
// @desc    Get curated popular destinations with high ratings
// @access  Public
exports.getPopularDestinations = async (req, res, next) => {
  try {
    const items = loadTouristPlaces();
    // Return sorted by rating
    const popular = [...items]
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, 12);

    res.status(200).json({
      success: true,
      count: popular.length,
      data: popular
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/destinations/:id
// @desc    Get single destination detail with attractions, hotels, transit, weather
// @access  Public
exports.getDestinationById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const items = loadTouristPlaces();
    const destination = items.find(d => d.id === id || (d._id && d._id.toString() === id));

    if (!destination) {
      return res.status(404).json({
        success: false,
        message: `Destination not found with id ${id}`
      });
    }

    // Add hotels, transit, and weather info if not already attached
    const enriched = {
      ...destination,
      weather: destination.weather || {
        climate: 'Pleasant & Moderate',
        currentTemp: '24°C',
        condition: 'Clear Sky ☀️',
        bestMonths: destination.bestSeason || 'October to March',
        rainfall: 'Low'
      },
      hotels: destination.hotels || [
        {
          name: `Heritage Palace Stay ${destination.district || destination.name}`,
          category: 'Luxury Heritage',
          pricePerNight: Math.round((destination.estimatedDailyBudget || 3500) * 0.9),
          rating: 4.8,
          bookingLink: 'https://www.makemytrip.com/hotels/'
        },
        {
          name: `Comfort Inn & Suites ${destination.district || destination.name}`,
          category: 'Mid-Range Boutique',
          pricePerNight: Math.round((destination.estimatedDailyBudget || 3500) * 0.5),
          rating: 4.3,
          bookingLink: 'https://www.booking.com/'
        },
        {
          name: `Traveller Backpacker Hostel ${destination.district || destination.name}`,
          category: 'Budget Friendly',
          pricePerNight: Math.round((destination.estimatedDailyBudget || 3500) * 0.25),
          rating: 4.1,
          bookingLink: 'https://www.hostelworld.com/'
        }
      ],
      travelOptions: {
        flight: destination.transit?.nearestAirport || 'Major Airport connectivity',
        train: destination.transit?.nearestRailway || 'IRCTC Superfast / Vande Bharat connectivity',
        road: destination.transit?.roadRoute || 'National Highway route'
      }
    };

    // If user is logged in, track recent view
    if (req.user) {
      const userId = req.user._id || req.user.id;
      const recentViews = store.getCollection('recentViews') || [];
      const updated = [
        {
          userId,
          destinationId: destination.id,
          destinationName: destination.name,
          image: destination.image,
          viewedAt: new Date().toISOString()
        },
        ...recentViews.filter(v => !(v.userId === userId && v.destinationId === destination.id))
      ].slice(0, 10);
      store.saveCollection('recentViews', updated);
    }

    res.status(200).json({
      success: true,
      data: enriched
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/states-districts
// @desc    Get all 28 states & 8 UTs with 780+ districts and connectivity
// @access  Public
exports.getStatesDistricts = async (req, res, next) => {
  try {
    const states = loadStatesDistricts();
    res.status(200).json({
      success: true,
      count: states.length,
      data: states
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/states-districts/:id
// @desc    Get state details and districts
// @access  Public
exports.getStateById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const states = loadStatesDistricts();
    const state = states.find(s => s.id === id || s.name.toLowerCase() === id.toLowerCase());

    if (!state) {
      return res.status(404).json({
        success: false,
        message: `State not found: ${id}`
      });
    }

    res.status(200).json({
      success: true,
      data: state
    });
  } catch (err) {
    next(err);
  }
};

