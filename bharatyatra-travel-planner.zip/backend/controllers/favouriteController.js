const { isUsingFallback } = require('../config/db');
const store = require('../config/store');
const Favourite = require('../models/Favourite');
const { loadTouristPlaces } = require('../data/dataLoader');

// @route   GET /api/favourites
// @desc    Get user favourites
// @access  Private
exports.getUserFavourites = async (req, res, next) => {
  try {
    const userId = req.user._id || req.user.id;

    if (isUsingFallback()) {
      const favourites = store.getCollection('favourites');
      const userFavs = favourites.filter(f => f.userId === userId || f.userId?.toString() === userId.toString());

      return res.status(200).json({
        success: true,
        count: userFavs.length,
        data: userFavs
      });
    }

    const favourites = await Favourite.find({ userId }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: favourites.length,
      data: favourites
    });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/favourites/toggle
// @desc    Add or remove an item from favourites
// @access  Private
exports.toggleFavourite = async (req, res, next) => {
  try {
    const userId = req.user._id || req.user.id;
    const { itemId, itemType = 'destination' } = req.body;

    if (!itemId) {
      return res.status(400).json({
        success: false,
        message: 'itemId is required'
      });
    }

    // Lookup destination data if it's a destination
    let itemData = {};
    if (itemType === 'destination') {
      const places = loadTouristPlaces();
      itemData = places.find(p => p.id === itemId) || { id: itemId };
    }

    if (isUsingFallback()) {
      const favourites = store.getCollection('favourites');
      const index = favourites.findIndex(f =>
        (f.userId === userId || f.userId?.toString() === userId.toString()) &&
        f.itemId === itemId
      );

      let isSaved = false;
      if (index > -1) {
        favourites.splice(index, 1);
        isSaved = false;
      } else {
        favourites.push({
          _id: 'fav_' + Date.now(),
          userId,
          itemType,
          itemId,
          itemData,
          createdAt: new Date().toISOString()
        });
        isSaved = true;
      }

      store.saveCollection('favourites', favourites);

      return res.status(200).json({
        success: true,
        isSaved,
        message: isSaved ? 'Added to favourites ❤️' : 'Removed from favourites'
      });
    }

    const existing = await Favourite.findOne({ userId, itemId });

    if (existing) {
      await Favourite.deleteOne({ _id: existing._id });
      return res.status(200).json({
        success: true,
        isSaved: false,
        message: 'Removed from favourites'
      });
    }

    await Favourite.create({
      userId,
      itemType,
      itemId,
      itemData
    });

    res.status(200).json({
      success: true,
      isSaved: true,
      message: 'Added to favourites ❤️'
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/recent-destinations
// @desc    Get recently viewed destinations
// @access  Private
exports.getRecentDestinations = async (req, res, next) => {
  try {
    const userId = req.user._id || req.user.id;
    const recent = store.getCollection('recentViews') || [];
    const userRecent = recent
      .filter(r => r.userId === userId || r.userId?.toString() === userId.toString())
      .slice(0, 8);

    res.status(200).json({
      success: true,
      count: userRecent.length,
      data: userRecent
    });
  } catch (err) {
    next(err);
  }
};

