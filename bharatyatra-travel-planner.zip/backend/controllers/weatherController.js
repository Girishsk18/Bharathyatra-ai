const { getWeatherForDestination } = require('../services/weatherService');

// @route   GET /api/weather
// @desc    Get live & 5-day weather forecast for destination
// @access  Public
exports.getWeather = async (req, res, next) => {
  try {
    const { destination = 'jaipur' } = req.query;
    const weatherData = await getWeatherForDestination(destination);

    res.status(200).json({
      success: true,
      data: weatherData
    });
  } catch (err) {
    next(err);
  }
};

