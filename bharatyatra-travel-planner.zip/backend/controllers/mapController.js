const { getRouteForDestination } = require('../services/mapService');

// @route   GET /api/maps/route
// @desc    Get circuit waypoints, distances, and transit modes
// @access  Public
exports.getRoute = (req, res, next) => {
  try {
    const { origin = 'New Delhi', destination = 'Jaipur' } = req.query;
    const route = getRouteForDestination({ origin, destination });

    res.status(200).json({
      success: true,
      data: route
    });
  } catch (err) {
    next(err);
  }
};

