const express = require('express');
const router = express.Router();
const { generateItinerary } = require('../controllers/aiController');
const { optionalAuth } = require('../middleware/auth');

router.post('/generate-itinerary', optionalAuth, generateItinerary);

module.exports = router;

