const express = require('express');
const router = express.Router();
const {
  getUserTrips,
  createTrip,
  getTripById,
  updateTrip,
  deleteTrip,
  shareTrip,
  getSharedTrip
} = require('../controllers/tripController');
const {
  getTripBudget,
  addTripExpense,
  deleteTripExpense
} = require('../controllers/budgetController');
const { protect } = require('../middleware/auth');

// Public shared trip route
router.get('/shared/:shareId', getSharedTrip);

// Protected trip routes
router.use(protect);

router.route('/')
  .get(getUserTrips)
  .post(createTrip);

router.route('/:id')
  .get(getTripById)
  .put(updateTrip)
  .delete(deleteTrip);

router.post('/:id/share', shareTrip);

// Budget & Expenses sub-routes
router.get('/:id/budget', getTripBudget);
router.post('/:id/expenses', addTripExpense);
router.delete('/:id/expenses/:expenseId', deleteTripExpense);

module.exports = router;

