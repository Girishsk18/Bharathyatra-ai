const express = require('express');
const router = express.Router();
const {
  getUserFavourites,
  toggleFavourite,
  getRecentDestinations
} = require('../controllers/favouriteController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.get('/', getUserFavourites);
router.post('/toggle', toggleFavourite);
router.get('/recent', getRecentDestinations);

module.exports = router;

