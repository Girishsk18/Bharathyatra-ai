const express = require('express');
const router = express.Router();
const {
  getDestinations,
  getPopularDestinations,
  getDestinationById,
  getStatesDistricts,
  getStateById
} = require('../controllers/destinationController');
const { optionalAuth } = require('../middleware/auth');

router.get('/', getDestinations);
router.get('/popular', getPopularDestinations);
router.get('/states-districts', getStatesDistricts);
router.get('/states-districts/:id', getStateById);
router.get('/:id', optionalAuth, getDestinationById);

module.exports = router;

