const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'database.json');

const defaultData = {
  users: [],
  trips: [],
  destinations: [],
  favourites: [],
  expenses: [],
  recentViews: []
};

// Ensure data folder and file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2), 'utf-8');
}

function readData() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading database.json:', err);
    return defaultData;
  }
}

function writeData(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database.json:', err);
  }
}

module.exports = {
  readData,
  writeData,
  getCollection: (name) => {
    const data = readData();
    return data[name] || [];
  },
  saveCollection: (name, items) => {
    const data = readData();
    data[name] = items;
    writeData(data);
  }
};

