const mongoose = require('mongoose');

let isConnected = false;
let connectPromise = null;

const connectDB = async () => {
  if (connectPromise) return connectPromise;

  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/bharatyatra';
  
  connectPromise = (async () => {
    try {
      mongoose.set('strictQuery', false);
      mongoose.set('bufferCommands', false);

      await mongoose.connect(uri, {
        serverSelectionTimeoutMS: 1500,
        connectTimeoutMS: 1500
      });
      isConnected = true;
      console.log(`✅ MongoDB connected successfully to ${uri}`);
    } catch (err) {
      isConnected = false;
      console.warn(`⚠️  MongoDB connection error: ${err.message}`);
      console.log(`ℹ️  Activating high-speed persistent local JSON store fallback (zero-config, all endpoints functional).`);
    }
  })();

  return connectPromise;
};

const isUsingFallback = () => {
  return mongoose.connection.readyState !== 1;
};

const getDBStatus = () => ({
  connected: mongoose.connection.readyState === 1,
  type: mongoose.connection.readyState === 1 ? 'mongodb' : 'file-fallback',
  readyState: mongoose.connection.readyState,
  uri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/bharatyatra'
});

module.exports = {
  connectDB,
  getDBStatus,
  isUsingFallback
};
