const assert = require('node:assert/strict');
const test = require('node:test');

process.env.NODE_ENV = 'test';
process.env.PORT = '5001';
const app = require('../server');

const { connectDB } = require('../backend/config/db');

let server;
let baseUrl;
let authToken = '';
let createdTripId = '';

test.before(async () => {
  await connectDB();
  await new Promise((resolve) => {
    server = app.listen(5001, () => {
      baseUrl = 'http://127.0.0.1:5001';
      resolve();
    });
  });
});

test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

test('1. Health Check Endpoint', async () => {
  const res = await fetch(`${baseUrl}/api/health`);
  assert.equal(res.status, 200);
  const data = await res.json();
  assert.equal(data.status, 'healthy');
  assert.equal(data.modules.authentication, 'active');
  assert.equal(data.modules.simpleTravel, 'active');
  assert.equal(data.modules.tripManagement, 'active');
  assert.equal(data.modules.aiItinerary, 'active');
});

test('2. Authentication - Register and Login', async () => {
  const testEmail = `test_${Date.now()}@bharatyatra.ai`;
  
  // Register
  const regRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Priya Sharma',
      email: testEmail,
      password: 'password123'
    })
  });

  assert.equal(regRes.status, 201);
  const regData = await regRes.json();
  assert.equal(regData.success, true);
  assert.ok(regData.token);
  assert.equal(regData.user.name, 'Priya Sharma');

  // Login
  const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: testEmail,
      password: 'password123'
    })
  });

  assert.equal(loginRes.status, 200);
  const loginData = await loginRes.json();
  assert.equal(loginData.success, true);
  authToken = loginData.token;
  assert.ok(authToken);

  // Get Me profile
  const meRes = await fetch(`${baseUrl}/api/auth/me`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  assert.equal(meRes.status, 200);
  const meData = await meRes.json();
  assert.equal(meData.user.email, testEmail);
});

test('3. Simple Travel & Destination Search', async () => {
  // Search destinations
  const searchRes = await fetch(`${baseUrl}/api/destinations?search=Jaipur`);
  assert.equal(searchRes.status, 200);
  const searchData = await searchRes.json();
  assert.equal(searchData.success, true);
  assert.ok(searchData.data.length > 0);

  // Filter by category
  const catRes = await fetch(`${baseUrl}/api/destinations?category=heritage`);
  assert.equal(catRes.status, 200);
  const catData = await catRes.json();
  assert.ok(catData.data.length > 0);

  // Destination Details
  const detailRes = await fetch(`${baseUrl}/api/destinations/hawa-mahal-amer`);
  assert.equal(detailRes.status, 200);
  const detailData = await detailRes.json();
  assert.equal(detailData.success, true);
  assert.ok(detailData.data.hotels.length > 0);
  assert.ok(detailData.data.weather);

  // States & Districts
  const statesRes = await fetch(`${baseUrl}/api/destinations/states-districts`);
  assert.equal(statesRes.status, 200);
  const statesData = await statesRes.json();
  assert.equal(statesData.count, 36);
});

test('4. AI Itinerary Generation', async () => {
  const aiRes = await fetch(`${baseUrl}/api/ai/generate-itinerary`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      destination: 'Jaipur, Rajasthan',
      destinationKey: 'jaipur',
      durationDays: 3,
      budgetAmount: 25000,
      party: 'couple',
      pace: 'balanced',
      vibes: ['heritage', 'food']
    })
  });

  assert.equal(aiRes.status, 200);
  const aiData = await aiRes.json();
  assert.equal(aiData.success, true);
  assert.equal(aiData.data.days.length, 3);
  assert.ok(aiData.data.costBreakdown.stay > 0);
  assert.ok(aiData.data.weatherForecast);
});

test('5. Trip Management - CRUD & Share', async () => {
  // Create Trip
  const createRes = await fetch(`${baseUrl}/api/trips`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`
    },
    body: JSON.stringify({
      title: 'Romantic Udaipur Palace Getaway',
      destination: 'Udaipur, Rajasthan',
      durationDays: 4,
      budgetAmount: 45000,
      budgetTier: 'luxury',
      party: 'couple'
    })
  });

  assert.equal(createRes.status, 201);
  const createData = await createRes.json();
  assert.equal(createData.success, true);
  createdTripId = createData.data._id || createData.data.id;
  assert.ok(createdTripId);

  // List User Trips
  const listRes = await fetch(`${baseUrl}/api/trips`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  assert.equal(listRes.status, 200);
  const listData = await listRes.json();
  assert.ok(listData.data.length >= 1);

  // Update Trip
  const updateRes = await fetch(`${baseUrl}/api/trips/${createdTripId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`
    },
    body: JSON.stringify({
      customNotes: 'Book sunset boat ride at Lake Pichola'
    })
  });
  assert.equal(updateRes.status, 200);

  // Share Trip
  const shareRes = await fetch(`${baseUrl}/api/trips/${createdTripId}/share`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${authToken}` }
  });
  assert.equal(shareRes.status, 200);
  const shareData = await shareRes.json();
  assert.ok(shareData.shareId);

  // Fetch Public Shared Trip
  const sharedFetchRes = await fetch(`${baseUrl}/api/trips/shared/${shareData.shareId}`);
  assert.equal(sharedFetchRes.status, 200);
});

test('6. Budget Manager & Expenses Tracking', async () => {
  // Add Expense
  const expRes = await fetch(`${baseUrl}/api/trips/${createdTripId}/expenses`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`
    },
    body: JSON.stringify({
      title: 'Heritage Haveli Night 1',
      category: 'stay',
      amount: 6500
    })
  });

  assert.equal(expRes.status, 201);
  const expData = await expRes.json();
  assert.ok(expData.data._id);

  // Get Trip Budget
  const budgetRes = await fetch(`${baseUrl}/api/trips/${createdTripId}/budget`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  assert.equal(budgetRes.status, 200);
  const budgetData = await budgetRes.json();
  assert.equal(budgetData.data.totalSpent, 6500);
  assert.equal(budgetData.data.remaining, 45000 - 6500);
  assert.equal(budgetData.data.categoryTotals.stay, 6500);
});

test('7. Weather & Map APIs', async () => {
  // Weather
  const weatherRes = await fetch(`${baseUrl}/api/weather?destination=manali`);
  assert.equal(weatherRes.status, 200);
  const weatherData = await weatherRes.json();
  assert.ok(weatherData.data.currentTemperature);

  // Map Routes
  const mapRes = await fetch(`${baseUrl}/api/maps/route?origin=Delhi&destination=Jaipur`);
  assert.equal(mapRes.status, 200);
  const mapData = await mapRes.json();
  assert.ok(mapData.data.waypoints.length > 0);
  assert.ok(mapData.data.transitOptions.train);
});

test('8. Favourites & Wishlist', async () => {
  // Toggle Favourite
  const favToggleRes = await fetch(`${baseUrl}/api/favourites/toggle`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`
    },
    body: JSON.stringify({
      itemId: 'hawa-mahal-amer',
      itemType: 'destination'
    })
  });
  assert.equal(favToggleRes.status, 200);
  const favToggleData = await favToggleRes.json();
  assert.equal(favToggleData.isSaved, true);

  // List Favourites
  const favListRes = await fetch(`${baseUrl}/api/favourites`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  assert.equal(favListRes.status, 200);
  const favListData = await favListRes.json();
  assert.equal(favListData.data.length, 1);
});
